# JP Core Procedure Profile - HL7 FHIR JP Core ImplementationGuide v1.3.0-dev

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **JP Core Procedure Profile**

## Resource Profile: JP Core Procedure Profile 

* **項目**: *定義URL*
  * **内容**: http://jpfhir.jp/fhir/core/StructureDefinition/JP_Procedure
* **項目**: *Version*
  * **内容**: 1.3.0-dev
* **項目**: *Name*
  * **内容**: JP_Procedure
* **項目**: *Title*
  * **内容**: JP Core Procedure Profile
* **項目**: *Status*
  * **内容**: Active ( 2025-07-30 )
* **項目**: *Copyright*
  * **内容**: Copyright Japan FHIR Implementation Infrastructure Study Group in Japan Association of Medical Informatics (JAMI) 一般社団法人日本医療情報学会FHIR国内実装基盤研究会

 
このプロファイルはProcedureリソースに対して、患者に対する医療的な処置のデータを送受信するための共通の制約と拡張を定めたものである。 

本プロファイルは、患者に対する医療的な処置に関する情報の登録や検索、取得のためにJP_Procedureリソースを使用するにあたり、本プロファイルに準拠する場合に必須となる要素や、サポートすべき拡張、用語、検索パラメータを定義する。

## スコープ

対象とする処置は以下を想定する。

* 外科手術（歯科手術を含む）
* 医科処置・歯科処置
* 放射線治療
* 精神療法
* リハビリテーション
* 各種指導管理
* 看護実施

## 想定シナリオ

本プロファイルは、以下のようなユースケースを想定している。

* 患者に実施された処置行為の検索
* 患者に行われた処置の記録または更新
* 他の記述仕様書からの参照
 （例：退院時サマリ、診療情報提供書における、処置実施項目の参照）

JP_Procedureリソースは、患者に対して実施されたもしくは実施が予定されていた処置の詳細を記録するために使用される。処置とは、ケアの一環として、患者に対して、患者とともに、または患者のために行われる活動のことである。例えば、外科的処置、診断処置、内視鏡的処置、生検、カウンセリング、理学療法、パーソナルサポートサービス、成人のデイケアサービス、緊急ではない交通手段、住宅改修、運動などがある。手続きは、医療従事者、サービス提供者、友人や親戚、場合によっては患者自身が行うこともある。

JP_Procedureリソースは、処置の発生に関する要約情報を提供するものであり、処置行為が進行する際のリアルタイムのスナップショットを提供することを意図したものではないが、心理療法のような長期にわたる治療の場合は、全体的な進捗状況に関する要約レベルの情報を表すことができる。詳細なリアルタイムの処置情報をサポートするリソースの作成は、そのような情報を共有するための具体的な実装のユースケースの特定後に行うことになる。

## プロファイル定義

**Usages:**

* Refer to this Profile: [JP Core Encounter Profile](StructureDefinition-jp-encounter.md), [JP Core ImagingStudy Endoscopy Profile](StructureDefinition-jp-imagingstudy-endoscopy.md), [JP Core ImagingStudy Radiology Profile](StructureDefinition-jp-imagingstudy-radiology.md), [JP Core MedicationDispenseBase Profile](StructureDefinition-jp-medicationdispensebase.md)...Show 2 more,[JP Core Observation Common Profile](StructureDefinition-jp-observation-common.md)and[JP Core Procedure Profile](StructureDefinition-jp-procedure.md)
* Examples for this Profile: [Procedure/jp-procedure-example-1](Procedure-jp-procedure-example-1.md)
* CapabilityStatements using this Profile: [JP Core Client CapabilityStatement](CapabilityStatement-jp-client-capabilitystatement.md) and [JP Core Server CapabilityStatement](CapabilityStatement-jp-server-capabilitystatement.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/jpfhir.jp.core|current/StructureDefinition/jp-procedure)

### プロファイル詳細

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-jp-procedure.csv), [Excel](StructureDefinition-jp-procedure.xlsx), [Schematron](StructureDefinition-jp-procedure.sch) 

### 必須要素

本プロファイルに準拠するためには、次の項目の値が存在しなければならない。

* status : 処置のステータス
* subject : 処置が実施された対象の人

### Extensions定義

本プロファイルで追加定義された拡張はない。

## 利用方法

### OperationおよびSearch Parameter 一覧

#### Search Parameter一覧

| | | | |
| :--- | :--- | :--- | :--- |
| SHALL | identifier | token | GET [base]/Procedure?identifier=http://myhospital.com/fhir/procedure|123 |
| SHOULD | patient | reference | GET [base]/Procedure?patient=123 |
| MAY | patient,date | reference,date | GET [base]/Procedure?patient=123&date=ge2021-08-24 |

##### 必須検索パラメータ

本プロファイルに準拠するためには、以下の検索パラメータをサポートしなければならない（SHALL）

1. 検索パラメータidentifierを指定し、レコードIDなどの識別子によりProcedureを検索

```
GET [base]/Procedure?identifier={system|}[token]

```

例：

```
GET [base]/Procedure?identifier=http://myhospital.com/fhir/procedure|123

```

指定された識別子に一致するProcedureリソースを含むBundleを検索する。

##### 推奨検索パラメータ

本プロファイルに準拠するためには、以下の検索パラメータをサポートすることが推奨される（**SHOULD**）

1. 検索パラメータpatientとdateを指定し、該当するすべてのProcedureを検索
* dateに対する次の比較演算子のサポートを含む: gt,lt,ge,le
* AND検索のオプションのサポートを含む (例えば.date=[date]&date=[date]]&…)

```
   GET [base]/Procedure?patient={reference}&date={gt|lt|ge|le}[date]{&date={gt|lt|ge|le}[date]&...}

```

例：

```
   GET [base]/Procedure?patient=Patient/123&date=ge2021-08-24

```

指定された患者および日付のすべてのProcedureを含むBundleを検索する。

##### 追加検索パラメータ

オプションとして次の検索パラメータをサポートすることができる（MAY）

1. 検索パラメータpatientとstatusを指定し、該当するすべてのProcedureを検索
* OR検索のサポートを含む(例えば status=[token],[token],…)

```
   GET [base]/Procedure?patient={reference}&status=[token]{,[token],...}

```

例：

```
   GET [base]/Procedure?patient=Patient/123&status=completed

```

指定された患者およびステータスのすべてのProcedureを含むBundleを検索する。
1. 検索パラメータpatientとcodeとdateを指定し、該当するすべてのProcedureを検索
* OR検索のオプションのサポートを含む (例えば code={system|}[token],{system|}[token],…)
* dateに対する次の比較演算子のサポートを含む:gt,lt,ge,le
* AND検索のオプションのサポートを含む (例えばdate=[date]&date=[date]]&…)

```
   GET [base]/Procedure?patient={reference}&code={system|}[token]{,{system|}[token],...}&date={gt|lt|ge|le}[date]{&date={gt|lt|ge|le}[date]&...}

```

例：

```
   GET [base]/Procedure?patient=Patient/123&date=ge2019-01-14T00:00:00Z&code=http://jpfhir.jp/fhir/core/ValueSet/JP_ProcedureCodesMedical_VS|140000610

```

指定された患者および日付およびプロシージャコードのすべてのProcedureを含むBundleを検索する。

##### オプション検索パラメータ

本プロファイルで追加定義されたオプション検索パラメータはない。

#### サンプル

* [**処置（抜糸）**](Procedure-jp-procedure-example-1.md)

## その他、参考文献・リンク等

1. ICHI(International Classification of Health Interventions)[https://icd.who.int/dev11/l-ichi/en](https://icd.who.int/dev11/l-ichi/en)

本実装ガイドへのご質問・ご指摘については、
[GitHub Issue](https://github.com/jami-fhir-jp-wg/jp-core-v1x/issues)および
[GitHub PullRequest](https://github.com/jami-fhir-jp-wg/jp-core-v1x/pulls)にて受け付けている。

## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "jp-procedure",
  "url" : "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Procedure",
  "version" : "1.3.0-dev",
  "name" : "JP_Procedure",
  "title" : "JP Core Procedure Profile",
  "status" : "active",
  "date" : "2025-07-30",
  "publisher" : "FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI)",
  "contact" : [
    {
      "name" : "FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI)",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://jpfhir.jp"
        },
        {
          "system" : "email",
          "value" : "office@hlfhir.jp"
        }
      ]
    }
  ],
  "description" : "このプロファイルはProcedureリソースに対して、患者に対する医療的な処置のデータを送受信するための共通の制約と拡張を定めたものである。",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "JP",
          "display" : "Japan"
        }
      ]
    }
  ],
  "copyright" : "Copyright Japan FHIR Implementation Infrastructure Study Group in Japan Association of Medical Informatics (JAMI) 一般社団法人日本医療情報学会FHIR国内実装基盤研究会",
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "workflow",
      "uri" : "http://hl7.org/fhir/workflow",
      "name" : "Workflow Pattern"
    },
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    },
    {
      "identity" : "w5",
      "uri" : "http://hl7.org/fhir/fivews",
      "name" : "FiveWs Pattern Mapping"
    },
    {
      "identity" : "v2",
      "uri" : "http://hl7.org/v2",
      "name" : "HL7 v2 Mapping"
    }
  ],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Procedure",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Procedure",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "Procedure",
        "path" : "Procedure",
        "short" : "Procedureリソース",
        "definition" : "患者に対して、または患者のために実行されているか実行されたアクション。これは、手術のような身体的介入、または長期サービス、カウンセリング、催眠療法のような低侵襲性である可能性がある。"
      },
      {
        "id" : "Procedure.id",
        "path" : "Procedure.id",
        "short" : "Logical id of this artifact"
      },
      {
        "id" : "Procedure.text",
        "path" : "Procedure.text",
        "short" : "このリソースを人間が解釈するためのテキスト要約"
      },
      {
        "id" : "Procedure.contained",
        "path" : "Procedure.contained",
        "short" : "Contained, inline Resources"
      },
      {
        "id" : "Procedure.identifier",
        "path" : "Procedure.identifier",
        "definition" : "これは、ビジネスプロセスによって定義され、リソース自体への直接のURL参照が適切でない場合に参照するために使用される、このProcedureに関連する識別子を記録する。",
        "comment" : "これはビジネス識別子であり、リソース識別子ではない（議論参照）。識別子は1つのリソースインスタンスにのみ表示されることがベストだが、ビジネス上の慣習により、同じ識別子を持つ複数のリソースインスタンスが存在することがあるかもしれない。例えば、複数のPatientとPersonリソースインスタンスが同じ社会保険番号を共有しているかもしれない。"
      },
      {
        "id" : "Procedure.instantiatesCanonical",
        "path" : "Procedure.instantiatesCanonical",
        "definition" : "本Procedureの全部または一部を遵守するFHIR定義のプロトコル、ガイドライン、オーダセット、その他の定義を指すURL。"
      },
      {
        "id" : "Procedure.instantiatesUri",
        "path" : "Procedure.instantiatesUri",
        "definition" : "本Procedure全体または一部を遵守する、外部で管理されているプロトコル、ガイドライン、オーダセット、またはその他の定義を指すURL。"
      },
      {
        "id" : "Procedure.basedOn",
        "path" : "Procedure.basedOn",
        "short" : "このプロシージャの依頼情報",
        "definition" : "このプロシージャの依頼情報の詳細を含むリソースへの参照。",
        "comment" : "参照は、実際のFHIRリソースへの参照であり、解決可能でなければならない（アクセス制御、一時的な利用不能などを可能にする）。解決には、URLからの検索、またはリソースタイプによって該当する場合は、絶対参照を正規のURLとして扱い、ローカルレジストリ/リポジトリで検索することができる。   \n【JP Core仕様】Observation_LabResultにならい、任意。"
      },
      {
        "id" : "Procedure.partOf",
        "path" : "Procedure.partOf",
        "short" : "このプロシジャーが構成要素やステップとなるより大きな医療行為",
        "definition" : "【JP Core仕様】https://www.hl7.org/fhir/R4/procedure.htmlを参照",
        "comment" : "MedicationAdministrationリソースにはProcedureへのpartOf参照があるが、これは循環参照ではない。たとえば、麻酔MedicationAdministrationは外科的処置の一部である（MedicationAdministration.partOf = Procedure）。  \nまた、たとえば、IV投薬管理用にIVポートを挿入する手順は、投薬管理の一部である（Procedure.partOf = MedicationAdministration）。  \n【JP Core仕様】Observation_LabResultにならい、任意。",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : [
              "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Procedure",
              "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Common",
              "http://jpfhir.jp/fhir/core/StructureDefinition/JP_MedicationAdministration"
            ]
          }
        ]
      },
      {
        "id" : "Procedure.status",
        "path" : "Procedure.status",
        "definition" : "プロシージャの状態を指定するコードである。一般的には、進行中または完了した状態になる。【JP Core仕様】http://hl7.org/fhir/us/core/STU3.1/StructureDefinition-us-core-procedure.htmlを参照",
        "comment" : "「不明な」コードは、他のステータスを伝えるために使用されるべきではない。ステータスの1つが当てはまる場合、「不明」コードを使用する必要があるが、オーサリングシステムはプロシージャの現在の状態を認識していない。  \nステータスにリソースを現在無効としてマークするコードが含まれているため、この要素は修飾子としてラベル付けされる。"
      },
      {
        "id" : "Procedure.statusReason",
        "path" : "Procedure.statusReason",
        "short" : "このプロシジャーの進捗の理由（未完了であったり中止されたことの理由）",
        "definition" : "プロシージャの現在の進捗の理由を設定する。",
        "comment" : "これは通常、「未完了」、「一時停止」、「中止」などの「例外」ステータスにのみ使用される。イベントを実行する理由は、ここではなく、reasonCodeに設定する。",
        "binding" : {
          "strength" : "example",
          "valueSet" : "http://jpfhir.jp/fhir/core/ValueSet/JP_ProcedureNotPerformedReason_VS"
        }
      },
      {
        "id" : "Procedure.category",
        "path" : "Procedure.category",
        "short" : "このプロシジャーの分類カテゴリ",
        "binding" : {
          "strength" : "example",
          "valueSet" : "http://jpfhir.jp/fhir/core/ValueSet/JP_ProcedureCategory_VS"
        }
      },
      {
        "id" : "Procedure.code",
        "path" : "Procedure.code",
        "short" : "このプロシジャーの識別子",
        "definition" : "行われた具体的な手順。手技の正確な性質がコード化できない場合はテキストを使用する（例：「腹腔鏡下虫垂切除術」）",
        "comment" : "すべての用語の使用がこの一般的なパターンに当てはまるわけではない。場合によっては、モデルはCodeableConceptを使用せず、`Coding`を直接使用し、テキスト、`Coding`、翻訳、要素間の関係や事前・事後の調整を管理するための独自の構造を提供すべきである。",
        "binding" : {
          "strength" : "example",
          "valueSet" : "http://jpfhir.jp/fhir/core/ValueSet/JP_ProcedureCodesMedical_VS"
        }
      },
      {
        "id" : "Procedure.code.coding",
        "path" : "Procedure.code.coding",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "value",
              "path" : "system"
            }
          ],
          "rules" : "open"
        }
      },
      {
        "id" : "Procedure.code.coding:medical",
        "path" : "Procedure.code.coding",
        "sliceName" : "medical",
        "short" : "医科診療行為マスタ ValueSet",
        "min" : 0,
        "max" : "1",
        "binding" : {
          "strength" : "required",
          "valueSet" : "http://jpfhir.jp/fhir/core/ValueSet/JP_ProcedureCodesMedical_VS"
        }
      },
      {
        "id" : "Procedure.code.coding:medical.system",
        "path" : "Procedure.code.coding.system",
        "min" : 1,
        "fixedUri" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_ProcedureCodesMedical_CS"
      },
      {
        "id" : "Procedure.code.coding:stem7",
        "path" : "Procedure.code.coding",
        "sliceName" : "stem7",
        "short" : "STEM7 外保連手術基幹コード ValueSet",
        "min" : 0,
        "max" : "1",
        "binding" : {
          "strength" : "required",
          "valueSet" : "http://jpfhir.jp/fhir/core/ValueSet/JP_ProcedureCodesSTEM7_VS"
        }
      },
      {
        "id" : "Procedure.code.coding:stem7.system",
        "path" : "Procedure.code.coding.system",
        "min" : 1,
        "fixedUri" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_ProcedureCodesSTEM7_CS"
      },
      {
        "id" : "Procedure.code.coding:dental",
        "path" : "Procedure.code.coding",
        "sliceName" : "dental",
        "short" : "歯科診療行為マスタ ValueSet",
        "min" : 0,
        "max" : "1",
        "binding" : {
          "strength" : "required",
          "valueSet" : "http://jpfhir.jp/fhir/core/ValueSet/JP_ProcedureCodesDental_VS"
        }
      },
      {
        "id" : "Procedure.code.coding:dental.system",
        "path" : "Procedure.code.coding.system",
        "min" : 1,
        "fixedUri" : "http://jpfhir.jp/fhir/core/mhlw/CodeSystem/masterH-dentalProcedure"
      },
      {
        "id" : "Procedure.code.coding:nurse",
        "path" : "Procedure.code.coding",
        "sliceName" : "nurse",
        "short" : "看護行為マスタ ValueSet",
        "min" : 0,
        "max" : "1",
        "binding" : {
          "strength" : "required",
          "valueSet" : "http://jpfhir.jp/fhir/core/ValueSet/JP_ProcedureCodesNurse_VS"
        }
      },
      {
        "id" : "Procedure.code.coding:nurse.system",
        "path" : "Procedure.code.coding.system",
        "min" : 1,
        "fixedUri" : "http://medis.or.jp/CodeSystem/master-nursingAction-16digits"
      },
      {
        "id" : "Procedure.code.coding:ichi",
        "path" : "Procedure.code.coding",
        "sliceName" : "ichi",
        "short" : "WHO ICHI (International Classification of Health Interventions) ValueSet",
        "min" : 0,
        "max" : "1",
        "binding" : {
          "strength" : "required",
          "valueSet" : "http://jpfhir.jp/fhir/core/ValueSet/JP_ProcedureCodesICHI_VS"
        }
      },
      {
        "id" : "Procedure.code.coding:ichi.system",
        "path" : "Procedure.code.coding.system",
        "min" : 1,
        "fixedUri" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_Undefined_CS"
      },
      {
        "id" : "Procedure.subject",
        "path" : "Procedure.subject",
        "short" : "誰にこのプロシジャーが実施されたか",
        "definition" : "プロシジャーが実行された対象の人、動物、またはグループ。",
        "comment" : "参照は、実際のFHIRリソースへの参照であり、解決可能でなければならない（アクセス制御、一時的な利用不能などを可能にする）。解決は、URLからの検索、またはリソースタイプによって該当する場合は、絶対参照を正規のURLとして扱い、ローカルレジストリ/リポジトリで検索することによって行うことができる。",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://jpfhir.jp/fhir/core/StructureDefinition/JP_Patient"]
          }
        ]
      },
      {
        "id" : "Procedure.encounter",
        "path" : "Procedure.encounter",
        "short" : "このプロシジャーの記録が作成されたEncounterの状況",
        "definition" : "プロシジャーが作成または実行されたEncounterの状況、またはこの記録の作成が緊密に関連している受療の状況。",
        "comment" : "これは通常、イベントが発生したEncounterの中で行われるが、活動によっては、Encounterの公式な終了前または終了後に開始されても、Encounterの文脈と結びついている場合がある。",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : [
              "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Encounter"
            ]
          }
        ]
      },
      {
        "id" : "Procedure.performed[x]",
        "path" : "Procedure.performed[x]",
        "short" : "いつこのプロシジャーが実施されたか",
        "definition" : "Procedureが行われた推定または実際の日付、日時、期間、または年齢。複数の日付にまたがる複雑なProcedureをサポートするために期間を許可し、Procedureの長さを把握することも可能。",
        "comment" : "年齢は一般的に、患者が手技が行われた年齢を報告するときに使用される。  \n範囲は、一般的に、患者が手順が実行されたときに年齢範囲を報告する場合に使用される。たとえば、20〜25歳の間など。  \ndateTimeは、ミリ秒の精度を持たない可能性がある過去の手順として報告される一部の手順と、Encounterの期間において実施され文書化された他の手順が、タイムゾーンでより正確なUTCタイムスタンプを持つ可能性があるため、さまざまな精度をサポートする。"
      },
      {
        "id" : "Procedure.recorder",
        "path" : "Procedure.recorder",
        "short" : "このプロシジャーを記録した人",
        "definition" : "記録を記録し、その内容に責任を負う個人。",
        "comment" : "参照は、実際のFHIRリソースへの参照である必要があり、内容に辿り着ける（解決できる）必要がある（アクセス制御、一時的な使用不可などを考慮に入れる）。解決は、URLから取得するか、リソースタイプによって該当する場合は、絶対参照を正規URLとして扱い、ローカルレジストリ/リポジトリで検索することによって行うことができる。",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : [
              "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Patient",
              "http://hl7.org/fhir/StructureDefinition/RelatedPerson",
              "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Practitioner",
              "http://jpfhir.jp/fhir/core/StructureDefinition/JP_PractitionerRole"
            ]
          }
        ]
      },
      {
        "id" : "Procedure.asserter",
        "path" : "Procedure.asserter",
        "short" : "このプロシジャーの実施の記録者",
        "definition" : "プロシジャーの実施記録を作成した個人。",
        "comment" : "参照は、実際のFHIRリソースへの参照である必要があり、内容に辿り着ける（解決できる）必要がある（アクセス制御、一時的な使用不可などを考慮に入れる）。解決は、URLから取得するか、リソースタイプによって該当する場合は、絶対参照を正規URLとして扱い、ローカルレジストリ/リポジトリで検索することによって行うことができる。",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : [
              "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Patient",
              "http://hl7.org/fhir/StructureDefinition/RelatedPerson",
              "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Practitioner",
              "http://jpfhir.jp/fhir/core/StructureDefinition/JP_PractitionerRole"
            ]
          }
        ]
      },
      {
        "id" : "Procedure.performer",
        "path" : "Procedure.performer",
        "short" : "このプロシジャーの実施者",
        "definition" : "医療機器ではなく「生身の人間」に限定。"
      },
      {
        "id" : "Procedure.performer.function",
        "path" : "Procedure.performer.function",
        "short" : "実施者の役割（ロール）",
        "definition" : "プロシジャーへの実施者の関与のタイプを区別する。たとえば、外科医、麻酔科医、内視鏡医。",
        "comment" : "すべての用語の使用がこの一般的なパターンに当てはまるわけではない。場合によっては、モデルはCodeableConceptを使用せず、`Coding`を直接使用し、テキスト、`Coding`、翻訳、要素間の関係や事前・事後の調整を管理するための独自の構造を提供するべきである。  \n 【JP Core仕様】当面利用しない。",
        "binding" : {
          "strength" : "example",
          "valueSet" : "http://jpfhir.jp/fhir/core/ValueSet/JP_ProcedurePerformerRole_VS"
        }
      },
      {
        "id" : "Procedure.performer.actor",
        "path" : "Procedure.performer.actor",
        "short" : "医療従事者への参照",
        "definition" : "プロシジャーに関わった医療従事者。",
        "comment" : "参照は、実際のFHIRリソースへの参照であり、解決可能でなければならない（アクセス制御、一時的な利用不可などを可能にする）。解決には、URLからの検索、またはリソースタイプによって適用可能な場合は、絶対参照を正規のURLとして扱い、ローカルレジストリ/リポジトリで検索することができる。",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : [
              "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Practitioner",
              "http://jpfhir.jp/fhir/core/StructureDefinition/JP_PractitionerRole",
              "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Organization",
              "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Patient",
              "http://hl7.org/fhir/StructureDefinition/RelatedPerson",
              "http://hl7.org/fhir/StructureDefinition/Device"
            ]
          }
        ]
      },
      {
        "id" : "Procedure.performer.onBehalfOf",
        "path" : "Procedure.performer.onBehalfOf",
        "short" : "従事した組織",
        "definition" : "従事した組織。",
        "comment" : "参照は、実際のFHIRリソースへの参照であり、解決可能でなければならない（アクセス制御、一時的な利用不能などを可能にする）。解決には、URLからの検索によるものと、リソースタイプによって該当する場合は、絶対参照を正規のURLとして扱い、ローカルレジストリ/リポジトリで検索するものがある。",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : [
              "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Organization"
            ]
          }
        ]
      },
      {
        "id" : "Procedure.location",
        "path" : "Procedure.location",
        "short" : "このプロシジャーが実施された場所",
        "definition" : "プロシジャーが実施された場所。  \n例:自宅での出生、レストランで気管切開など。",
        "comment" : "参照は、実際のFHIRリソースへの参照である必要があり、内容に辿り着ける（解決できる）必要がある（アクセス制御、一時的な使用不可などを考慮に入れる）。解決は、URLから取得するか、リソースタイプによって該当する場合は、絶対参照を正規URLとして扱い、ローカルレジストリ/リポジトリで検索することによって行うことができる。",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://jpfhir.jp/fhir/core/StructureDefinition/JP_Location"]
          }
        ]
      },
      {
        "id" : "Procedure.reasonCode",
        "path" : "Procedure.reasonCode",
        "short" : "このプロシジャーが実施された理由コード",
        "definition" : "処置が行われたコード化された理由。  \nこれはある種のコード化された実体であるかもしれないし、単にテキストとして存在するかもしれない。",
        "comment" : "ひとつのコードが理由を十分に説明している場合は、Procedure.reasonCodeを使用する。  \nリソースを参照する場合は、Procedure.reasonReferenceを使用する。これにより、開始日など、より多くの情報を伝達できる。  \nProcedure.reasonCodeとProcedure.reasonReferenceは、重複することを意図したものではない。単一の理由で、Procedure.reasonCodeまたはProcedure.reasonReferenceのいずれかだけを使用できる。  \nProcedure.reasonCodeは要約コードの場合もあれば、Procedure.reasonReferenceを使用して、Condition | Observation | Procedure | DiagnosticReport | DocumentReference のいずれかにより、非常に精緻な理由の定義を参照することもできる。  \nもしプロシージャの異なる理由を説明しているのであれば、Procedure.reasonCodeとProcedure.reasonReferenceの両方を使用できる。",
        "binding" : {
          "strength" : "example",
          "valueSet" : "http://jpfhir.jp/fhir/core/ValueSet/JP_ProcedureReason_VS"
        }
      },
      {
        "id" : "Procedure.reasonReference",
        "path" : "Procedure.reasonReference",
        "short" : "このプロシジャーが実施された正当性",
        "definition" : "なぜそのようなProcedureを行ったのか、その正当性を示す。",
        "comment" : "ある手順が別の手順（硬膜外など）の理由（帝王切開など）になる可能性がある。他の例には、拡張および生検（診断および治療用途の組み合わせ）のための内視鏡検査が含まれる。  \nコードが理由を十分に説明している場合は、Procedure.reasonCodeを使用する。  \nリソースを参照する場合は、Procedure.reasonReferenceを使用する。これにより、開始日など、より多くの情報を伝達できる。  \nProcedure.reasonCodeとProcedure.reasonReferenceは、重複することを意図したものではない。単一の理由で、Procedure.reasonCodeまたはProcedure.reasonReferenceのいずれかだけを使用できる。  \nProcedure.reasonReferenceを使用して、Condition | Observation | Procedure | DiagnosticReport | DocumentReference等のリソースを利用することも可能である。",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : [
              "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Condition",
              "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Common",
              "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Procedure",
              "http://jpfhir.jp/fhir/core/StructureDefinition/JP_DiagnosticReport_Common",
              "http://hl7.org/fhir/StructureDefinition/DocumentReference"
            ]
          }
        ]
      },
      {
        "id" : "Procedure.bodySite",
        "path" : "Procedure.bodySite",
        "short" : "このプロシジャーの対象となった人体部位",
        "definition" : "詳細かつ構造化された解剖学的な位置情報。複数の場所を指定することができる。例えば、1つの病変に対して複数のパンチングバイオプシーを行うことができる。",
        "comment" : "ユースケースでBodySiteリソースの属性が必要な場合（たとえば、個別に識別して追跡するため）、標準の拡張extension [procedure-targetbodystructure]（extension-procedure-targetbodystructure.html）を使用する。"
      },
      {
        "id" : "Procedure.outcome",
        "path" : "Procedure.outcome",
        "short" : "このプロシジャーのアウトカム",
        "definition" : "Procedureの結果 - Procedureが行われた理由が解決されたか？",
        "comment" : "結果に叙述的記述トのみが含まれている場合は、CodeableConcept.textを使用してその情報を格納できる。",
        "binding" : {
          "strength" : "example",
          "valueSet" : "http://jpfhir.jp/fhir/core/ValueSet/JP_ProcedureOutcome_VS"
        }
      },
      {
        "id" : "Procedure.report",
        "path" : "Procedure.report",
        "short" : "このプロシジャーの結果報告",
        "definition" : "これは、組織学的結果、病理学的報告書、手術報告書などであろう。",
        "comment" : "複数のレポートが存在する可能性がある  \n例：これが複数の生検を行ったプロシジャーであって、いくつもの解剖病理学報告が得られた場合。",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : [
              "http://jpfhir.jp/fhir/core/StructureDefinition/JP_DiagnosticReport_Common",
              "http://hl7.org/fhir/StructureDefinition/DocumentReference",
              "http://hl7.org/fhir/StructureDefinition/Composition"
            ]
          }
        ]
      },
      {
        "id" : "Procedure.complication",
        "path" : "Procedure.complication",
        "short" : "このプロシジャーによる合併症",
        "definition" : "プロシジャー中、またはその実施直後の期間に発生した合併症。これらは通常、note要素とは別に記録される。note要素は通常、「プロシジャー後」の問題ではなく、プロシジャー自体を説明するものである。",
        "comment" : "合併症が叙述的なテキストによってのみ表現されている場合は、CodeableConcept.textに格納できる。",
        "binding" : {
          "strength" : "example",
          "valueSet" : "http://jpfhir.jp/fhir/core/ValueSet/JP_ProcedureCondition_VS"
        }
      },
      {
        "id" : "Procedure.complicationDetail",
        "path" : "Procedure.complicationDetail",
        "short" : "このプロシジャーの合併症の結果生じた患者状態",
        "definition" : "Procedureの実施中、または実施直後に発生した全ての合併症。",
        "comment" : "参照は、実際のFHIRリソースへの参照である必要があり、内容に辿り着ける（解決できる）必要がある（アクセス制御、一時的な使用不可などを考慮に入れる）。解決は、URLから取得するか、リソースタイプによって該当する場合は、絶対参照を正規URLとして扱い、ローカルレジストリ/リポジトリで検索することによって行うことができる。",
        "requirements" : "これは、プロシジャーの理由であった状態ではなく、プロシジャーの結果である状態を文書化するために使用される。",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : [
              "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Condition"
            ]
          }
        ]
      },
      {
        "id" : "Procedure.followUp",
        "path" : "Procedure.followUp",
        "short" : "今後の処置が特別なフォローアップを必要とする場合（例：抜糸）、フォローアップはシンプルなnote として表現してもよいが、より複雑になる可能性もあり、その場合はケアプランリソースを使用することができる。",
        "binding" : {
          "strength" : "example",
          "valueSet" : "http://jpfhir.jp/fhir/core/ValueSet/JP_ProcedureFollowUp_VS"
        }
      },
      {
        "id" : "Procedure.note",
        "path" : "Procedure.note",
        "short" : "このプロシジャーの関する追加情報",
        "definition" : "このプロシジャーに関する注意点やコメントなど。",
        "comment" : "構造化された注釈（アノテーション）を持たないシステムの場合、作成者や時間なしで単一の注釈を簡単に伝達できる。情報を変更する可能性があるため、この要素をナラティブに含める必要がある場合がある。   \n*注釈は、計算機処理れきる「変更」情報を伝達するために使用されるべきではない*。 （ユーザーの行動を強制することはほとんど不可能であるため、これはSHOULDとする）。"
      },
      {
        "id" : "Procedure.focalDevice",
        "path" : "Procedure.focalDevice",
        "short" : "このプロシジャーの際に操作、埋め込み、または削除されたデバイス",
        "definition" : "Procedureが行われる局所に、あるいは、そこから、埋め込まれる、取り外される、またはその他の操作（キャリブレーション、バッテリー交換、プロテーゼの装着、陰圧ドレインバックの装着など）が行われるデバイス。"
      },
      {
        "id" : "Procedure.focalDevice.action",
        "path" : "Procedure.focalDevice.action",
        "definition" : "Procedure中にデバイスに起こった変化の種類。【JP Core仕様】https://www.hl7.org/fhir/R4/procedure.htmlを参照",
        "binding" : {
          "strength" : "preferred",
          "valueSet" : "http://jpfhir.jp/fhir/core/ValueSet/JP_ProcedureDeviceAction_VS"
        }
      },
      {
        "id" : "Procedure.focalDevice.manipulated",
        "path" : "Procedure.focalDevice.manipulated",
        "definition" : "Procedure中に操作（変更）されたデバイス。【JP Core仕様】https://www.hl7.org/fhir/R4/procedure.htmlを参照"
      },
      {
        "id" : "Procedure.usedReference",
        "path" : "Procedure.usedReference",
        "short" : "プロシジャー中に使用されるアイテム",
        "definition" : "プロシジャーの一部として使用される薬剤、機器およびその他の物質を特定する。",
        "comment" : "実際に埋め込まれた、または取り外されたデバイスについては、Procedure.deviceを使用すること。",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : [
              "http://hl7.org/fhir/StructureDefinition/Device",
              "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Medication",
              "http://hl7.org/fhir/StructureDefinition/Substance"
            ]
          }
        ]
      },
      {
        "id" : "Procedure.usedCode",
        "path" : "Procedure.usedCode",
        "short" : "プロシジャー中に使用したアイテムのコード",
        "definition" : "Procedureの一部として使用されたコード化されたアイテムを識別する。",
        "comment" : "実際に埋め込まれた、または取り外されたデバイスについては、Procedure.deviceを使用すること。",
        "binding" : {
          "strength" : "example",
          "valueSet" : "http://jpfhir.jp/fhir/core/ValueSet/JP_ProcedureDeviceKind_VS"
        }
      }
    ]
  }
}

```
