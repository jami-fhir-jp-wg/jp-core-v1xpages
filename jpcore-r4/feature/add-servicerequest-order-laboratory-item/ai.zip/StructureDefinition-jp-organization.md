# JP Core Organization Profile - HL7 FHIR JP Core ImplementationGuide v1.3.0-dev

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **JP Core Organization Profile**

## Resource Profile: JP Core Organization Profile 

* **項目**: *定義URL*
  * **内容**: http://jpfhir.jp/fhir/core/StructureDefinition/JP_Organization
* **項目**: *Version*
  * **内容**: 1.3.0-dev
* **項目**: *Name*
  * **内容**: JP_Organization
* **項目**: *Title*
  * **内容**: JP Core Organization Profile
* **項目**: *Status*
  * **内容**: Active ( 2025-07-30 )
* **項目**: *Copyright*
  * **内容**: Copyright Japan FHIR Implementation Infrastructure Study Group in Japan Association of Medical Informatics (JAMI) 一般社団法人日本医療情報学会FHIR国内実装基盤研究会

 
このプロファイルはOrganizationリソースに対して、組織情報のデータを送受信するための基礎となる制約と拡張を定めたものである。 

何らかの形で集団行動をとることを目的に結成された、公式または非公式に認められた人や組織の集まり。企業、機関、法人、部署、コミュニティグループ、医療行為グループ、支払者／保険者などを含む。

## 背景および想定シナリオ

本プロファイルは、以下のようなユースケースを想定している。

* 組織名または医療機関コードによる検索

## スコープ

本プロファイルは、様々な組織の連絡先やその他の情報を共有するレジストリとして使用することができる。 また参照される組織に必要とするサポート、ドキュメント、メッセージ、またはcontained resourceとして使用することもできる。レジストリを使用する場合、複数のレジストリが存在し、それぞれが異なるタイプやレベルの組織に対応することは十分可能である。


## プロファイル定義

**Usages:**

* Refer to this Profile: [JP Core Coverage Profile](StructureDefinition-jp-coverage.md), [JP Core DiagnosticReport Common Profile](StructureDefinition-jp-diagnosticreport-common.md), [JP Core DiagnosticReport Endoscopy Profile](StructureDefinition-jp-diagnosticreport-endoscopy.md), [JP Core Encounter Profile](StructureDefinition-jp-encounter.md)...Show 17 more,[JP Core ImagingStudy Radiology Profile](StructureDefinition-jp-imagingstudy-radiology.md),[JP Core Immunization Profile](StructureDefinition-jp-immunization.md),[JP Core Location Profile](StructureDefinition-jp-location.md),[JP Core Medication Profile](StructureDefinition-jp-medication.md),[JP Core MedicationDispenseBase Profile](StructureDefinition-jp-medicationdispensebase.md),[JP Core MedicationRequest Injection Profile](StructureDefinition-jp-medicationrequest-injection.md),[JP Core MedicationRequest Profile](StructureDefinition-jp-medicationrequest.md),[JP Core Observation Common Profile](StructureDefinition-jp-observation-common.md),[JP Core Observation Radiology Findings Profile](StructureDefinition-jp-observation-radiology-findings.md),[JP Core Observation Radiology Impression Profile](StructureDefinition-jp-observation-radiology-impression.md),[JP Core Organization Department Profile](StructureDefinition-jp-organization-department.md),[JP Core Organization Profile](StructureDefinition-jp-organization.md),[JP Core Patient Profile](StructureDefinition-jp-patient.md),[JP Core Practitioner Profile](StructureDefinition-jp-practitioner.md),[JP Core PractitionerRole Profile](StructureDefinition-jp-practitionerrole.md),[JP Core Procedure Profile](StructureDefinition-jp-procedure.md)and[JP Core ServiceRequest Common Profile](StructureDefinition-jp-servicerequest-common.md)
* Examples for this Profile: [太郎花子クリニック](Organization-jp-organization-example-clinic.md), [健康第一病院](Organization-jp-organization-example-hospital.md), [ＡＢＣ検査株式会社](Organization-jp-organization-example-inspection.md) and [ひまわり健康保険組合](Organization-jp-organization-example-payer.md)
* CapabilityStatements using this Profile: [JP Core Client CapabilityStatement](CapabilityStatement-jp-client-capabilitystatement.md) and [JP Core Server CapabilityStatement](CapabilityStatement-jp-server-capabilitystatement.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/jpfhir.jp.core|current/StructureDefinition/jp-organization)

### プロファイル詳細

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-jp-organization.csv), [Excel](StructureDefinition-jp-organization.xlsx), [Schematron](StructureDefinition-jp-organization.sch) 

### 必須要素

本プロファイルで定義された必須項目はない。

### Extensions定義

本プロファイルで使用される拡張は次の通りである。

* [JP_OrganizationCategory](StructureDefinition-jp-organization-insuranceorganizationcategory.md)
* [JP_OrganizationNo](StructureDefinition-jp-organization-insuranceorganizationno.md)
* [JP_PrefectureNo](StructureDefinition-jp-organization-prefectureno.md)

### その他

Organization.identifierには、以下のOrganization(組織)に関連したidentifier(ID情報)を格納できるようスライシングによる定義が追加されている。

| | | |
| :--- | :--- | :--- |
| medicalInstitutionCode | 医療機関コードを格納する | identifier.system = "http://jpfhir.jp/fhir/core/CodeSystem/medicalInstitutionCode" を指定し、医療機関コード(10桁)を同valueに格納する。*医療機関コード(7桁)は異なるURIとなるので注意すること。 |
| insurerNumber | 健康保険組合などの保険者の保険者番号を表現する | identifier.system = "http://jpfhir.jp/fhir/core/mhlw/IdSystem/InsurerNumber" を指定し、保険者番号を同valueに格納する。 |

## 医療機関コード（１０桁）

JP Coreでの医療機関コード（１０桁）のエリアに格納する値を説明する。
 保険医療施設以外の利用等も考慮しているため、正式な医療機関コード（１０桁）の説明でないことに注意すること。

### 保険医療機関・保険薬局の場合

医療機関コードは10桁の数値で表現され、以下の記載様式を取る。

```
 都道府県コード（２桁） + 点数表番号（１桁） + 医療機関コード（７桁）

```

* 都道府県コード（ISO 3166-2:JP）：２桁
 全国地方公共団体コードにより都道府県ごとに割り当てられた番号、左詰ゼロを含む２桁で記載される。
* 点数表番号 : １桁
 医科は「1」、歯科は「3」、調剤「4」、訪問看護ステーション「6」が割り当たる。
 同一の病院または診療所に医科と歯科が併存する場合など１施設にあたり２つ以上のコードが割り振られるケースが存在する。施設の主要な役割に応じて単一の点数表番号を割り当てることが望ましい(**SHOULD**)。派生する実装ガイドの利用用途（例えば診療報酬点数に関係するデータ収集など）によっては１施設に複数コードを扱わないといけないケースも存在する。１施設に対し複数の医療機関コードを扱う場合にはシステム上の考慮が多くなる点について注意が必要である。ストレージ上は１医療機関コードとしデータ出力時にコードを変換するなど、ＦＨＩＲサーバーが複雑にならないような検討を行なうこと。
* 医療機関コード（７桁）：７桁
 コードの内部構成は、`都市区番号（２桁）＋医療機関等番号（４桁）＋検証番号（１桁）` となっている。


  医療機関番号等は、「医科」、「歯科」は医療機関番号、「調剤薬局」は保険薬局コード、「訪問看護ステーション」はステーションコードが該当する。

### 保険医療機関を除く特定健診・特定保健指導機関の場合

健診等機関コード（１０桁）を利用する。

```
都道府県コード(２桁) + 区分コード(１桁) + 機関コード（７桁）

```

* 都道府県コード（ISO 3166-2:JP）：２桁
 保険医療機関の説明に同じ。
* 区分コード：１桁
 保険医療機関に該当しない特定健診・特定保健指導機関は「2」固定となる。ちなみに保険医療機関の場合は「1」であるが、該当しないため利用しない。
* 機関コード（７桁）：７桁
 特定健診・特定保健指導機関コードを割り当てる。

### 上記に該当しない施設の場合

「[9]＋当該施設の電話番号下９桁」を医療機関コードとして代用する。

## 利用方法

### OperationおよびSearch Parameter 一覧

#### Search Parameter一覧

| | | | |
| :--- | :--- | :--- | :--- |
| SHALL | identifier | token | GET [base]/Organization?identifier=12345 |
| SHOULD | name | string | GET [base]/Organization?name=Health |
| SHOULD | address | string | GET [base]/Organization?address=Arbor |

##### 必須検索パラメータ

1. identifier 検索パラメータを使用して、識別子によるOrganizationの検索をサポートしなければならない（**SHALL**）

```
GET [base]/Organization?identifier={system|}[token]

```

例：

```
GET [base]/Organization?identifier=http://hl7.org/fhir/sid/jpsys|123456

```

指定された識別子に一致するOrganizationリソースを含むBundleを検索する。

##### 推奨検索パラメータ

次の検索パラメータをサポートすることが望ましい。

1. name 検索パラメータを使用して、言語コードによるOrganizationの検索をサポートすることが望ましい（**SHOULD**）

```
GET [base]/Organization?name={string}

```

例：

```
GET [base]/Organization?name=Health

```


1. address 検索パラメータを使用して、addressによるOrganizationの検索をサポートすることが望ましい（**SHOULD**）

```
GET [base]/Organization?address={string}

```

例：

```
GET [base]/Organization?address=Arbor

```


##### オプション検索パラメータ

本プロファイルで追加定義されたオプション検索パラメータはない。

### サンプル

* [**太郎花子クリニック**](Organization-jp-organization-example-clinic.md)
* [**健康第一病院**](Organization-jp-organization-example-hospital.md)
* [**ひまわり健康保険組合**](Organization-jp-organization-example-payer.md)

## 注意事項

連絡先情報は2箇所に記載がある。1つはOrganization自体にあり、一般的な公的組織の連絡先として使用される。もう1つはContactEntity構造を使用した場所であり、特定の目的のために連絡を受けるように組織が指定した人物や関係者に連絡を取るために使用される。

## その他、参考文献、リンク等

1. 退院時サマリー規約[http://www.hl7.jp/library/item/HL7J-CDA-007.pdf](http://www.hl7.jp/library/item/HL7J-CDA-007.pdf)
1. 診療情報提供書規格[http://www.hl7.jp/intro/std/HL7J-CDA-005.pdf](http://www.hl7.jp/intro/std/HL7J-CDA-005.pdf)
1. 特定健診情報ファイル仕様[https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000165280.html](https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000165280.html)
1. SS-MIX2 標準化ストレージ 仕様書 Ver.1.2h[https://www.jami.jp/jamistd/docs/SS-MIX2/h/SS-MIX2_StndrdStrgSpecVer.1.2h.pdf](https://www.jami.jp/jamistd/docs/SS-MIX2/h/SS-MIX2_StndrdStrgSpecVer.1.2h.pdf)
1. ICSR E2B(R3)[https://www.pmda.go.jp/int-activities/int-harmony/ich/0093.html](https://www.pmda.go.jp/int-activities/int-harmony/ich/0093.html)

本実装ガイドへのご質問・ご指摘については、
[GitHub Issue](https://github.com/jami-fhir-jp-wg/jp-core-v1x/issues)および
[GitHub PullRequest](https://github.com/jami-fhir-jp-wg/jp-core-v1x/pulls)にて受け付けている。

## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "jp-organization",
  "url" : "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Organization",
  "version" : "1.3.0-dev",
  "name" : "JP_Organization",
  "title" : "JP Core Organization Profile",
  "status" : "active",
  "date" : "2025-07-30",
  "publisher" : "FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI)",
  "contact" : [
    {
      "name" : "FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI)",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://jpfhir.jp"
        },
        {
          "system" : "email",
          "value" : "office@hlfhir.jp"
        }
      ]
    }
  ],
  "description" : "このプロファイルはOrganizationリソースに対して、組織情報のデータを送受信するための基礎となる制約と拡張を定めたものである。",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "JP",
          "display" : "Japan"
        }
      ]
    }
  ],
  "copyright" : "Copyright Japan FHIR Implementation Infrastructure Study Group in Japan Association of Medical Informatics (JAMI) 一般社団法人日本医療情報学会FHIR国内実装基盤研究会",
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "v2",
      "uri" : "http://hl7.org/v2",
      "name" : "HL7 v2 Mapping"
    },
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    },
    {
      "identity" : "servd",
      "uri" : "http://www.omg.org/spec/ServD/1.0/",
      "name" : "ServD"
    },
    {
      "identity" : "w5",
      "uri" : "http://hl7.org/fhir/fivews",
      "name" : "FiveWs Pattern Mapping"
    }
  ],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Organization",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Organization",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "Organization",
        "path" : "Organization",
        "short" : "共通の目的を持った人や組織の集まり【詳細参照】",
        "definition" : "集団行動の何らかの形での達成を目的として結成された、正式または非公式に認められた人々または組織のグループ。企業、機関、企業、部門、コミュニティグループ、医療実践グループ、支払者/保険者などが含まれる。"
      },
      {
        "id" : "Organization.extension",
        "path" : "Organization.extension",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "value",
              "path" : "url"
            }
          ],
          "rules" : "open"
        }
      },
      {
        "id" : "Organization.extension:prefectureNo",
        "path" : "Organization.extension",
        "sliceName" : "prefectureNo",
        "short" : "都道府県番号２桁を表現するExtension",
        "comment" : "都道府県番号２桁。Identifier型の拡張を使用する。  \nvalueには都道府県番号2桁の値を格納し、systemには都道府県番号を表すOID「1.2.392.100495.20.3.21」を指定する。",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Extension",
            "profile" : [
              "http://jpfhir.jp/fhir/core/Extension/StructureDefinition/JP_Organization_PrefectureNo"
            ]
          }
        ]
      },
      {
        "id" : "Organization.extension:organizationCategory",
        "path" : "Organization.extension",
        "sliceName" : "organizationCategory",
        "short" : "点数表コード１桁（医科１、非保険検診施設２、歯科３、調剤４、訪問看護ステーション６）を表現するExtension【詳細参照】",
        "comment" : "点数表コード１桁（医科１、非保険検診施設２、歯科３、調剤４、訪問看護ステーション６）。systemには点数表番号を表すOID「1.2.392.100495.20.3.22」を指定する。",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Extension",
            "profile" : [
              "http://jpfhir.jp/fhir/core/Extension/StructureDefinition/JP_Organization_InsuranceOrganizationCategory"
            ]
          }
        ]
      },
      {
        "id" : "Organization.extension:organizationNo",
        "path" : "Organization.extension",
        "sliceName" : "organizationNo",
        "short" : "医療機関コード（７桁）を表現するExtension【詳細参照】",
        "comment" : "医療機関コード（７桁）。Identifier型の拡張「InsuranceOrganizationNo」を使用する。  \nsystemには医療機関コードを表すOID「http://jpfhir.jp/fhir/core/mhlw/IdSystem/MedicalOrganizationID」を指定する。  \nvalueには下記の値を格納する。  \n　- 保険医療機関・保険薬局 : `医療機関コード（７桁）`  \n　- 非保険の特定健診・特定保健指導機関 : `機関コード（７桁）`  \n　  \n医療機関コードの詳しい説明は、Organizationプロファイルの医療機関コード１０桁の説明を参照すること。  \nなお上記に該当しない施設は、本拡張は使用しない。",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Extension",
            "profile" : [
              "http://jpfhir.jp/fhir/core/Extension/StructureDefinition/JP_Organization_InsuranceOrganizationNo"
            ]
          }
        ]
      },
      {
        "id" : "Organization.identifier",
        "path" : "Organization.identifier",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "value",
              "path" : "system"
            }
          ],
          "rules" : "open"
        },
        "short" : "複数のシステムでこの組織を識別【詳細参照】",
        "definition" : "複数の異種システムにまたがって組織を識別するための識別子",
        "comment" : "福祉医療関連施設と保険者組織はSlicingについてはJP Coreにて定義を行なっているため、定義に従いデータを格納すること。それ以外の組織については、利用する際には必要に応じて識別子を定義を行なうこと。",
        "requirements" : "組織は様々な ID で知られている。いくつかの機関では複数のIDを保持しており、ほとんどの機関では、組織に関する他の組織との交換のためにIDを収集している。"
      },
      {
        "id" : "Organization.identifier.assigner",
        "path" : "Organization.identifier.assigner",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : [
              "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Organization"
            ]
          }
        ]
      },
      {
        "id" : "Organization.identifier:medicalInstitutionCode",
        "path" : "Organization.identifier",
        "sliceName" : "medicalInstitutionCode",
        "short" : "施設が福祉医療関連機関である場合に利用する識別子【詳細参照】",
        "definition" : "福祉医療施設を区別するため医療機関コード（１０桁）を格納するためのIdentifier/Slicing定義。",
        "comment" : "systemはFixed Valueの```http://jpfhir.jp/fhir/core/IdSystem/insurance-medical-institution-no```を使用する。  \nvalue : ```医療機関コード（１０桁）```を使用する。  \n医療機関コード（１０桁）の詳細はOrganizationプロファイルの医療機関コード１０桁の説明を参照すること。 ",
        "min" : 0,
        "max" : "*"
      },
      {
        "id" : "Organization.identifier:medicalInstitutionCode.system",
        "path" : "Organization.identifier.system",
        "min" : 1,
        "fixedUri" : "http://jpfhir.jp/fhir/core/IdSystem/insurance-medical-institution-no"
      },
      {
        "id" : "Organization.identifier:insurerNumber",
        "path" : "Organization.identifier",
        "sliceName" : "insurerNumber",
        "comment" : "健康保険組合などの保険者の保険者番号を表現する際のIdentifier表現に使用する  \nsystem要素には保険者番号を示す\"http://jpfhir.jp/fhir/core/mhlw/IdSystem/InsurerNumber\"を指定する。",
        "min" : 0,
        "max" : "*"
      },
      {
        "id" : "Organization.identifier:insurerNumber.system",
        "path" : "Organization.identifier.system",
        "min" : 1,
        "fixedUri" : "http://jpfhir.jp/fhir/core/mhlw/IdSystem/InsurerNumber"
      },
      {
        "id" : "Organization.identifier:insurerNumber.value",
        "path" : "Organization.identifier.value",
        "comment" : "保険者番号。英数字 券面記載の保険者番号。"
      },
      {
        "id" : "Organization.active",
        "path" : "Organization.active",
        "short" : "組織の記録がまだ有効に使われているかどうか【詳細参照】",
        "definition" : "このアクティブフラグは、組織を一時的に閉鎖したり、工事中であることを示すために使用されることを意図していない。代わりに、組織内の場所(複数可)は、中断されたステータスを持っている必要がある。一時停止の理由の詳細が必要な場合は、この要素の拡張子を使用する必要がある。  \nこの要素は、リソースがエラーで作成されたことをマークするために使用される可能性があるため、修飾子としてラベル付けされている。",
        "requirements" : "レコードが使用されなくなったことを示すためのフラグが必要で、一般的にUIではユーザーのために非表示にする必要がある。"
      },
      {
        "id" : "Organization.type",
        "path" : "Organization.type",
        "short" : "組織の種類【詳細参照】",
        "definition" : "その種類の組織。",
        "comment" : "n組織は、企業、病棟、セクション、臨床チーム、政府部門などにすることができる。多くのアプリケーションでは、コードは、特定の組織を識別するために使用されている（と言う、病棟）別の同じタイプのものとは対照的に - これらは識別子ではなく、コードである。  \n複数のタイプが適切かどうかを検討する際には、異なるタイプが組織の異なるサブ領域に存在する可能性が高いため、子どもの組織の方がより適切な使用法であるかどうかを評価する必要がある。これは、宗教、学術、医療センターのように、タイプの価値観が直交する場合に使用される可能性が高い。  \nいくつかの法域では、このオプション性を単一のカーディナリティとしてプロファイルすると予想される。",
        "requirements" : "これがある組織の種類を追跡することができる必要がある - 異なる組織の種類は、異なる用途を持っている。"
      },
      {
        "id" : "Organization.name",
        "path" : "Organization.name",
        "short" : "組織に使用されている名称【詳細参照】",
        "definition" : "組織に関連付けられた名前。",
        "comment" : "組織名が変更された場合は、旧名称をエイリアス欄に入れて検索で見つけられるようにすることを検討すべきである。",
        "requirements" : "組織のラベルとして名前を使用する必要がある。"
      },
      {
        "id" : "Organization.alias",
        "path" : "Organization.alias",
        "short" : "組織が知られている、または過去に知られていた別名のリスト【詳細参照】",
        "definition" : "組織がその名で知られている、または過去にその名で知られていた代替名のリスト。",
        "comment" : "これは、名前がいつ使用されたかを追跡することを目的としたものではなく、古い名前でも組織を特定できるように検索を支援することを目的としているため、別名や歴史的な名前に関連付けられた日付はない。",
        "requirements" : "時間の経過とともに、場所や組織はさまざまな変化を経て、さまざまな名前で知ることができる。  \n組織が知っている前の名前を知るための検索には、非常に便利なことができる。"
      },
      {
        "id" : "Organization.telecom",
        "path" : "Organization.telecom",
        "short" : "組織の連絡先詳細【詳細参照】",
        "definition" : "組織の連絡先詳細",
        "comment" : "使用コード「home」は使用しないこと。これらの連絡先は、組織に雇用されている人や組織を代表する人の連絡先ではなく、組織自体の公式な連絡先であることに注意すること。",
        "requirements" : "組織のヒューマンコンタクト。"
      },
      {
        "id" : "Organization.telecom.system",
        "path" : "Organization.telecom.system",
        "short" : "phone | fax | email | pager | url | sms | other 【JP_Patient.telecomを参照。】",
        "comment" : "連絡先の種別をValueSet(ContactPointSystem)より選択する。  　- phone : 電話　- fax : Fax 　- email : 電子メール　- pager : ポケットベル　- url : 電話、ファックス、ポケットベル、または電子メールアドレスではなく、URLとして表される連絡先。これはWebサイト、ブログ、Skype、Twitter、Facebookなどのさまざまな機関または個人の連絡先を対象としている。電子メールアドレスには使用しないこと。　- sms : SMSメッセージの送信に使用できる連絡先（携帯電話、一部の固定電話など）  　- other : 電話、Fax、ポケットベル、または電子メールアドレスではなく、URLとして表現できない連絡先。例：内部メールアドレス。これは、URLとして表現できる連絡先（Skype、Twitter、Facebookなど）には使用しないこと。"
      },
      {
        "id" : "Organization.telecom.value",
        "path" : "Organization.telecom.value",
        "comment" : "連絡先の番号やメールアドレス"
      },
      {
        "id" : "Organization.telecom.use",
        "path" : "Organization.telecom.use",
        "short" : "work | temp | old | mobile - 連絡先の用途等 【JP_Patient.telecomを参照。】homeは使用しないこと。",
        "comment" : "患者の連絡先の種別をValueSet(ContactPointUse)より選択する。  一時的なものまたは古いものであると明示しない限り、連絡先が最新とみなされる。  \n　- work : 職場  \n　- temp : 一時的  \n　- old : 以前の  \n　- mobile : モバイル機器"
      },
      {
        "id" : "Organization.telecom.rank",
        "path" : "Organization.telecom.rank",
        "comment" : "連絡先の使用順序（1 = 最高）"
      },
      {
        "id" : "Organization.telecom.period",
        "path" : "Organization.telecom.period",
        "comment" : "連絡先が使用されていた/されている期間"
      },
      {
        "id" : "Organization.address",
        "path" : "Organization.address",
        "short" : "組織の住所【詳細参照】",
        "definition" : "組織の住所",
        "comment" : "組織は、用途や適用期間が異なる複数の住所を持っている場合がある。使用コード「home」は使用しないこと。",
        "requirements" : "連絡、請求、または報告のために、組織のアドレスを追跡する必要がある場合がある。"
      },
      {
        "id" : "Organization.address.use",
        "path" : "Organization.address.use",
        "short" : "work | temp | old | billing - purpose of this address　住所の用途 【JP_Patient.address参照】使用コード「home」は使用しない。",
        "definition" : "The purpose of this address.  \n住所の用途",
        "comment" : "住所の用途をValueSet(AddressUse)より選択する。  \n　- work : 職場  \n　- temp : 一時的  \n　- old : 以前の  \n　- billing : 請求書、インボイス、領収書などの送付用"
      },
      {
        "id" : "Organization.address.type",
        "path" : "Organization.address.type",
        "short" : "postal | physical | both 【JP_Patient.address参照】",
        "definition" : "住所（訪問できる住所）と郵送先住所（私書箱や気付住所など）を区別する。ほとんどのアドレスは両方。",
        "comment" : "住所の種類をValueSet(AddressType)より選択する。  \n　- postal : 郵送先 - 私書箱、気付の住所  \n　- physical : 訪れることのできる物理的な住所  \n　- both : postalとphysicalの両方"
      },
      {
        "id" : "Organization.address.text",
        "path" : "Organization.address.text",
        "short" : "住所のテキスト表現 【JP_Patient.address参照】",
        "definition" : "表示するアドレス全体を指定する  \n例：郵便ラベル。これは、特定の部品の代わりに、または特定の部品と同様に提供される場合がある。",
        "comment" : "テキスト表現とパーツの両方を提供できる。アドレスを更新するアプリケーションは、テキストとパーツの両方が存在する場合、パーツにないコンテンツはテキストに含まれないようにする必要がある。  \n　- 住所を(都道府県や市町村などに)分離して管理していない場合は、textに入れる。  \n　- 住所を(都道府県や市町村などに)分離して管理している場合でも、まとめてtextに入れること。  \n　- 郵便番号は含めない。  \n　  \n例：東京都文京区本郷7-3-1"
      },
      {
        "id" : "Organization.address.line",
        "path" : "Organization.address.line",
        "short" : "ストリート名や番地など 【JP_Patient.address参照】",
        "definition" : "このコンポーネントには、家番号、アパート番号、通りの名前、通りの方向、P.O。が含まれる。ボックス番号、配達のヒント、および同様の住所情報など。",
        "comment" : "【JP Core仕様】state要素とcity要素で表現しなかったそのあとの住所部分を番地以降の部分も含めてすべていれる。  \n英数字は半角でも全角でもよい。文字列の前後および途中に空白文字を含めないこと。  \n繰り返し要素が許されているので、区切りを表現したい場合には、複数要素に分けて格納してもよい。  \n　  \n例：本郷7-3-1  \n例：大字石神９７６  \n例：藤崎町大字藤崎字西村1-2 春山荘201号室"
      },
      {
        "id" : "Organization.address.city",
        "path" : "Organization.address.city",
        "short" : "市区町村名 【JP_Patient.address参照】",
        "definition" : "n市、町、郊外、村、その他のコミュニティまたは配達センターの名前。",
        "comment" : "１MBを超えないこと。  【JP Core仕様】郡市区町村部分だけを「郡」「市」「区」「町」「村」などの文字を含めて設定する。 例：文京区"
      },
      {
        "id" : "Organization.address.district",
        "path" : "Organization.address.district",
        "short" : "地区名 【JP_Patient.address参照】",
        "comment" : "【JP Core仕様】日本の住所では使用しない。"
      },
      {
        "id" : "Organization.address.state",
        "path" : "Organization.address.state",
        "short" : "国の次の地区単位 【JP_Patient.address参照】",
        "definition" : "国の主権が制限されている国のサブユニット。日本の場合、都道府県名。",
        "comment" : "１MBを超えないこと。  都道府県名。「都」「道」「府」「県」のそれぞれの文字を含める。 例：東京都"
      },
      {
        "id" : "Organization.address.postalCode",
        "path" : "Organization.address.postalCode",
        "short" : "郵便番号 【JP_Patient.address参照】",
        "comment" : "郵便番号。日本の郵便番号の場合には3桁数字とハイフン1文字と4桁数字からなる半角８文字、または最初の3桁だけの3文字のいずれかとする。 例：113-8655"
      },
      {
        "id" : "Organization.address.country",
        "path" : "Organization.address.country",
        "short" : "国名またはISO 3166コード　(ISO 3166 2 or 3文字こーど)",
        "definition" : "国-一般的に理解されている、または一般的に受け入れられている国の国名かコード。",
        "comment" : "ISO 3166 3文字コードは、人間が読める国名の代わりに使用する。  ISO 3166の2文字または3文字のコード.  日本であれば、jpまたはjpn"
      },
      {
        "id" : "Organization.address.period",
        "path" : "Organization.address.period",
        "short" : "住所が使用されていた（いる）期間",
        "definition" : "住所が使用されていた（いる）期間",
        "comment" : "住所が使用されていた/されている期間。 期間は時間の範囲を指定する。使用状況はその期間全体に適用されるか、範囲から1つの値が適用される。  期間は、時間間隔（経過時間の測定値）には使用されない。"
      },
      {
        "id" : "Organization.partOf",
        "path" : "Organization.partOf",
        "short" : "【詳細参照】",
        "definition" : "この組織が一部を構成する組織",
        "comment" : "参照は、実際のFHIRリソースへの参照である必要があり、内容に辿り着ける（解決できる）必要がある（アクセス制御、一時的な使用不可などを考慮に入れる）。解決は、URLから取得するか、リソースタイプによって該当する場合は、絶対参照を正規URLとして扱い、ローカルレジストリ/リポジトリで検索することによって行うことができる。",
        "type" : [
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-hierarchy",
                "valueBoolean" : true
              }
            ],
            "code" : "Reference",
            "targetProfile" : [
              "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Organization"
            ]
          }
        ]
      },
      {
        "id" : "Organization.contact",
        "path" : "Organization.contact",
        "short" : "特定の目的のための組織の連絡先【詳細参照】",
        "definition" : "特定の目的のための組織の連絡先",
        "comment" : "同じ目的で複数の連絡先が提供されている場合、どの連絡先を使用するのが好ましいかを判断するために使用できる標準の拡張extension がある。",
        "requirements" : "より大きな組織内で割り当てられた連絡先を追跡する必要がある。"
      },
      {
        "id" : "Organization.contact.name",
        "path" : "Organization.contact.name",
        "type" : [
          {
            "code" : "HumanName",
            "profile" : [
              "http://jpfhir.jp/fhir/core/StructureDefinition/JP_HumanName"
            ]
          }
        ]
      },
      {
        "id" : "Organization.endpoint",
        "path" : "Organization.endpoint",
        "short" : "組織のために運営されているサービスへのアクセスを提供する技術的エンドポイント【詳細参照】",
        "definition" : "組織のために運営されているサービスへのアクセスを提供する技術的エンドポイント",
        "comment" : "参照は、実際のFHIRリソースへの参照である必要があり、内容に辿り着ける（解決できる）必要がある（アクセス制御、一時的な使用不可などを考慮に入れる）。解決は、URLから取得するか、リソースタイプによって該当する場合は、絶対参照を正規URLとして扱い、ローカルレジストリ/リポジトリで検索することによって行うことができる。",
        "requirements" : "組織にはさまざまなサービスを提供する複数のシステムがあり、それらに接続する方法と目的について、技術的な接続の詳細を定義できる必要がある。"
      }
    ]
  }
}

```
