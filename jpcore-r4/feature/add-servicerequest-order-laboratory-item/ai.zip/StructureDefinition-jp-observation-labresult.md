# JP Core Observation LabResult Profile - HL7 FHIR JP Core ImplementationGuide v1.3.0-dev

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **JP Core Observation LabResult Profile**

## Resource Profile: JP Core Observation LabResult Profile 

* **項目**: *定義URL*
  * **内容**: http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_LabResult
* **項目**: *Version*
  * **内容**: 1.3.0-dev
* **項目**: *Name*
  * **内容**: JP_Observation_LabResult
* **項目**: *Title*
  * **内容**: JP Core Observation LabResult Profile
* **項目**: *Status*
  * **内容**: Active ( 2025-07-30 )
* **項目**: *Copyright*
  * **内容**: Copyright Japan FHIR Implementation Infrastructure Study Group in Japan Association of Medical Informatics (JAMI) 一般社団法人日本医療情報学会FHIR国内実装基盤研究会

 
このプロファイルはObservationリソースに対して、検体検査結果のデータを送受信するための制約と拡張を定めたものである。 

本プロファイル説明は、患者に関連付けられた検体検査結果を記録、検索、および取得のために、FHIR Observationリソースを使用するにあたっての、最低限の制約を記述したものである。

Observationリソースに対して本プロファイルに準拠する場合に必須となる要素や、サポートすべき拡張、用語、検索パラメータを定義する。

なお、検査結果は、Observationリソースを参照するDiagnosticReportリソースを使用してグループ化および要約されたものである。各Observationリソースは、個々の検体検査と結果値、他の観察結果を参照する。

## 背景および想定シナリオ

本プロファイルは、以下のようなユースケースを想定している。

* Patientリソースから指定された（患者の）検体採取日、検査項目、検査オーダの依頼科での検体検査情報の参照
* Patientリソースから指定された（患者の）検体採取日、検査項目、検査結果値（範囲、または範囲外）検査オーダの依頼科での検体検査情報の参照
* Patientリソースから指定された（患者の）検体採取日、検査項目、検査結果値（特定のコード）検査オーダの依頼科での検体検査情報の参照
* Patientリソースから指定された（患者の）検体採取日、検査項目、検査結果値（特定の文字列）検査オーダの依頼科での検体検査情報の参照
* 検査項目、検査結果値に対し条件に合致する検体検査情報、または関連する他のリソース（Observationリソースや、Patientリソース等）の参照

## スコープ

Observationはヘルスケアの中心的な要素であり、診断の支援、進捗状況の監視、ベースラインやパターンの決定、さらには基本情報の把握に使用される。ほとんどのObservationは、いくつかのメタデータを持つ単純な名前/値のペアのアサーションであるが、いくつかのObservationは、他の Observationを論理的にグループ化したり、あるいはマルチコンポーネントのObservationであったりする。

本プロファイルでは上記想定シナリオにて用いられるObservationの用途がスコープであり、患者基本情報の中でも特に検体検査に該当する情報項目の１つを取り扱う際に、必要な要件を定義している。

## プロファイル定義

**Usages:**

* Refer to this Profile: [JP Core DiagnosticReport LabResult Profile](StructureDefinition-jp-diagnosticreport-labresult.md)
* Examples for this Profile: [Observation/jp-observation-labresult-example-1](Observation-jp-observation-labresult-example-1.md)
* CapabilityStatements using this Profile: [JP Core Client CapabilityStatement](CapabilityStatement-jp-client-capabilitystatement.md) and [JP Core Server CapabilityStatement](CapabilityStatement-jp-server-capabilitystatement.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/jpfhir.jp.core|current/StructureDefinition/jp-observation-labresult)

### プロファイル詳細

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-jp-observation-labresult.csv), [Excel](StructureDefinition-jp-observation-labresult.xlsx), [Schematron](StructureDefinition-jp-observation-labresult.sch) 

### 必須要素

本プロファイルでは、次の要素を持たなければならない。

* status：検体検査情報項目の状態は必須である
* category：このリソースが示す検体検査情報項目を分類するための区分であり、このプロファイルでは必須とする
* code：このリソースは何の検体検査情報項目であるかを示すため必須である
* subject：このリソースが示す検体検査情報項目が、どの患者のものかを示すため、このプロファイルでは参照するpatientリソースの定義を必須とする
* effective[x]：検体採取日時、このリソースが示す検体検査情報項目が、いつ発生したかを示すためこのプロファイルでは必須とする
* specimen：このリソースが示す検体検査情報項目が、どの検体で検査されるのかを示すため、このプロファイルでは参照するspecimenリソースの定義を必須とする

### Extensions定義

本プロファイルで追加定義された拡張はない。

## 利用方法

### OperationおよびSearch Parameter 一覧

#### Search Parameter一覧

検体検査結果ユースケースのSearch Parameter一覧は共通情報プロファイルとは異なり以下の通りである。

| | | | |
| :--- | :--- | :--- | :--- |
| SHOULD | patient,code,date,based-on | reference,token,date,reference | GET [base]/Observation?patient=123&code=http://medis.or.jp/CodeSystem/master-JLAC10-17digits|9A610000000000000&date=le2020-12-31&based-on=ServiceRequest/456 |
| SHOULD | patient,code,date,value-quantity,based-on | reference,token,date,quantity,reference | GET [base]/Observation?patient=123&code=http://medis.or.jp/CodeSystem/master-JLAC10-17digits|9A610000000000000&date=le2020-12-31&value-quantity=gt40&based-on=ServiceRequest/456 |
| SHOULD | patient,code,date,value-concept,based-on | reference,token,date,token,reference | GET [base]/Observation?patient=123&code=http://medis.or.jp/CodeSystem/master-JLAC10-17digits|9A610000000000000&date=le2020-12-31&value-concept=http://jpfhir.jp/fhir/example|1082004&based-on=ServiceRequest/456 |
| SHOULD | patient,code,date,value-string,based-on | reference,token,date,string,reference | GET [base]/Observation?patient=123&code=http://medis.or.jp/CodeSystem/master-JLAC10-17digits|9A610000000000000&date=le2020-12-31&value-string=positive&based-on=ServiceRequest/456 |
| SHOULD | code,value-quantity,patient | token,quantity,reference | GET [base]/Observation?code=http://medis.or.jp/CodeSystem/master-JLAC10-17digits|9A610000000000000&value-quantity=gt40&patient=123 |
| SHOULD | code,value-concept,patient | token,token,reference | GET [base]/Observation?code=http://medis.or.jp/CodeSystem/master-JLAC10-17digits|9A610000000000000&value-concept=http://jpfhir.jp/fhir/example|1082004&patient=123 |
| SHOULD | code,value-string,patient | token,string,reference | GET [base]/Observation?code=http://medis.or.jp/CodeSystem/master-JLAC10-17digits|9A610000000000000&value-string=positive&patient=123 |

#### 操作詳細

##### 必須検索パラメータ

必須（**SHALL**）としての検索項目は定義しない。

##### 推奨検索パラメータ

次の検索パラメータはサポートすることが推奨される。（**SHOULD**）

1. 臨床での検索：`subject = Patient`（対象患者）、検体採取日、検査項目、`basedOn = ServiceRequest`（検査オーダの依頼科）を指定した検索をサポートすることが望ましい。（**SHOULD**）
patient,code,date,based-on の各検索パラメータに一致するObservationリソースを含むBundleを取得することができる。

```
GET [base]/Observation?patient={reference}&code={token}&date={date}&based-on={reference}

```

例：

```
GET [base]/Observation?patient=123&code=http://medis.or.jp/CodeSystem/master-JLAC10-17digits|9A610000000000000&date=le2020-12-31&based-on=ServiceRequest/456

```


1. 臨床（NST）での検索：`subject = Patient`（対象患者）、検査項目、検査値（数値、条件：基準値から外れている、等）、`basedOn = ServiceRequest`（検査オーダの依頼科）を指定した検索をサポートすることが望ましい。(**SHOULD**)
patient,code,date,value-quantity,based-on の各検索パラメータに一致するObservationリソースを含むBundleを取得することができる。

```
GET [base]/Observation?patient={reference}&code={token}&date={date}&value-quantity={quantity}&based-on={reference}

```

例：

```
GET [base]/Observation?patient=123&code=http://medis.or.jp/CodeSystem/master-JLAC10-17digits|9A610000000000000&date=le2020-12-31&value-quantity=gt40&based-on=ServiceRequest/456

```


1. 臨床（NST）での検索：`subject = Patient`（対象患者）、検査項目、検査値（コード）、`basedOn = ServiceRequest`（検査オーダの依頼科）を指定した検索をサポートすることが望ましい。(**SHOULD**)
patient,code,date,value-concept,based-on の各検索パラメータに一致するObservationリソースを含むBundleを取得することができる。

```
GET [base]/Observation?patient={reference}&code={token}&date={date}&value-concept={token}&based-on={reference}

```

例：

```
GET [base]/Observation?patient=123&code=http://medis.or.jp/CodeSystem/master-JLAC10-17digits|9A610000000000000&date=le2020-12-31&value-concept=http://jpfhir.jp/fhir/example|1082004&based-on=ServiceRequest/456

```


1. 臨床（NST）での検索：`subject = Patient`（対象患者）、検査項目、検査値（文字列）、`basedOn = ServiceRequest`（検査オーダの依頼科）を指定した検索をサポートすることが望ましい。(**SHOULD**)
patient,code,date,value-string,based-on の各検索パラメータに一致するObservationリソースを含むBundleを取得することができる。

```
GET [base]/Observation?patient={reference}&code={token}&date={date}&value-string={string}&based-on={reference}

```

例：

```
GET [base]/Observation?patient=123&code=http://medis.or.jp/CodeSystem/master-JLAC10-17digits|9A610000000000000&date=le2020-12-31&value-string=positive&based-on=ServiceRequest/456  

```


1. 研究での検索：検査項目、検査値（数値、条件：ある値以上／以下、等）、`subject = Patient`（対象患者で絞る場合あり）を指定した検索をサポートすることが望ましい。(**SHOULD**)
code,value-quantity,patient の各検索パラメータに一致するObservationリソースを含むBundleを取得することができる。

```
GET [base]/Observation?code={token}}&value-quantity={quantity}&patient={reference}

```

例：

```
GET [base]/Observation?code=http://medis.or.jp/CodeSystem/master-JLAC10-17digits|9A610000000000000&value-quantity=gt40&patient=123

```


1. 研究での検索：検査項目、検査値（コード）、`subject = Patient`（対象患者で絞る場合あり）を指定した検索をサポートすることが望ましい。(**SHOULD**)
code,value-concept,patient の各検索パラメータに一致するObservationリソースを含むBundleを取得することができる。

```
GET [base]/Observation?code={token}&value-concept={token}&patient={reference}

```

例：

```
GET [base]/Observation?code=http://medis.or.jp/CodeSystem/master-JLAC10-17digits|9A610000000000000&value-concept=http://jpfhir.jp/fhir/example|1082004&patient=123

```


1. 研究での検索：検査項目、検査値（文字列）、`subject = Patient`（対象患者で絞る場合あり）を指定した検索をサポートすることが望ましい。(**SHOULD**)
code,value-string,patient の各検索パラメータに一致するObservationリソースを含むBundleを取得することができる。

```
GET [base]/Observation?code={token}}&value-string={string}&patient={reference}

```

例：

```
GET [base]/Observation?code=http://medis.or.jp/CodeSystem/master-JLAC10-17digits|9A610000000000000&value-string=positive&patient=123

```


##### オプション検索パラメータ

本プロファイルで追加定義されたオプション検索パラメータはない。

#### Operation一覧

ObservationリソースのOperation一覧の定義はユースケースに依存せず共通であるため、共通情報プロファイルに記載されている。

[Observation共通情報プロファイル#Operation一覧](StructureDefinition-jp-observation-common.md#operation一覧)

### サンプル

* [**検体検査（尿酸）**](Observation-jp-observation-labresult-example-1.md)

本実装ガイドへのご質問・ご指摘については、
[GitHub Issue](https://github.com/jami-fhir-jp-wg/jp-core-v1x/issues)および
[GitHub PullRequest](https://github.com/jami-fhir-jp-wg/jp-core-v1x/pulls)にて受け付けている。

## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "jp-observation-labresult",
  "url" : "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_LabResult",
  "version" : "1.3.0-dev",
  "name" : "JP_Observation_LabResult",
  "title" : "JP Core Observation LabResult Profile",
  "status" : "active",
  "date" : "2025-07-30",
  "publisher" : "FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI)",
  "contact" : [
    {
      "name" : "FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI)",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://jpfhir.jp"
        },
        {
          "system" : "email",
          "value" : "office@hlfhir.jp"
        }
      ]
    }
  ],
  "description" : "このプロファイルはObservationリソースに対して、検体検査結果のデータを送受信するための制約と拡張を定めたものである。",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "JP",
          "display" : "Japan"
        }
      ]
    }
  ],
  "copyright" : "Copyright Japan FHIR Implementation Infrastructure Study Group in Japan Association of Medical Informatics (JAMI) 一般社団法人日本医療情報学会FHIR国内実装基盤研究会",
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "workflow",
      "uri" : "http://hl7.org/fhir/workflow",
      "name" : "Workflow Pattern"
    },
    {
      "identity" : "sct-concept",
      "uri" : "http://snomed.info/conceptdomain",
      "name" : "SNOMED CT Concept Domain Binding"
    },
    {
      "identity" : "v2",
      "uri" : "http://hl7.org/v2",
      "name" : "HL7 v2 Mapping"
    },
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    },
    {
      "identity" : "w5",
      "uri" : "http://hl7.org/fhir/fivews",
      "name" : "FiveWs Pattern Mapping"
    },
    {
      "identity" : "sct-attr",
      "uri" : "http://snomed.org/attributebinding",
      "name" : "SNOMED CT Attribute Binding"
    }
  ],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Observation",
  "baseDefinition" : "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Common",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "Observation",
        "path" : "Observation",
        "short" : "検体検査結果",
        "definition" : "検体検査結果の格納に使用する。",
        "comment" : "すべてのObservation（検査測定や観察事実）の制約プロファイル"
      },
      {
        "id" : "Observation.identifier",
        "path" : "Observation.identifier",
        "short" : "当該検査項目に対して、施設内で割り振られる一意の識別子",
        "definition" : "この検査項目に割り当てられた一意の識別子。リソースの識別子やシステム的なシーケンスではなく、ビジネスID。",
        "comment" : "【JP Core仕様】当該検査項目に対して、施設内で割り振られる一意の識別子があればそれを使用する。なければ次のルールを参考に一意となる識別子を生成し設定する。  \nアプリケーション側のデータベースにおけるフィールド長の定義については、最低64バイトを確保すること。  \n--- 参考 ---  \n次の項目を順にセパレータ「_(アンダースコア)」で連結し、 identifier.value に設定する。グループ項目でない場合など、該当コード／番号がない場合はセパレータを連続で連結する。各コードはローカルコードを使用し、必ず設定できること。  \n　１、ORC-2(依頼者オーダ番号)　SS-MIX2の15桁前ゼロ形式の番号  \n　２、OBR-4(検査項目ID)　検査セットの識別コード  \n　３、SPM-4(検体タイプ)  \n　４、OBX-3(検査項目)  \n　５、OBX-4(検査副ID)・・・オプション。必要に応じて使用。  \n形式：[ORC-2]_[OBR-4]_[SPM-4]_[OBX-3]（_[OBX-4]）"
      },
      {
        "id" : "Observation.identifier.use",
        "path" : "Observation.identifier.use",
        "definition" : "この識別子の目的。",
        "comment" : "アプリケーションは、identifierが一時的であると明示的に述べられない限り、永続的であると想定できる。"
      },
      {
        "id" : "Observation.identifier.system",
        "path" : "Observation.identifier.system"
      },
      {
        "id" : "Observation.identifier.value",
        "path" : "Observation.identifier.value",
        "definition" : "システムのコンテキスト内で一意の識別子となる文字列を設定。"
      },
      {
        "id" : "Observation.basedOn",
        "path" : "Observation.basedOn",
        "definition" : "このプロファイルでは、検体検査オーダに関する情報。",
        "comment" : "【JP Core仕様】オーダ情報がある場合、このプロファイルでは ServiceRequest のリソースを参照する。オーダIDの情報はここで使用する。",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/ServiceRequest"]
          }
        ]
      },
      {
        "id" : "Observation.partOf",
        "path" : "Observation.partOf",
        "definition" : "このリソースが一部として、あるいは手順の一つとして含まれるより大きなイベント。",
        "comment" : "【JP Core仕様】当面は使用しない。"
      },
      {
        "id" : "Observation.status",
        "path" : "Observation.status",
        "definition" : "結果値の状態。",
        "comment" : "【JP Core仕様】v2.5の「F」に相当する値は「final」であるが、ここでは 必須コード表「ObservationStatus」より、全てのコード値を使用可とする。  \n(registered | preliminary | final | amended |   corrected | cancelled | entered-in-error | unknown)"
      },
      {
        "id" : "Observation.category",
        "path" : "Observation.category"
      },
      {
        "id" : "Observation.category.coding",
        "path" : "Observation.category.coding",
        "short" : "コード化されたカテゴリー",
        "definition" : "コード化されたカテゴリー"
      },
      {
        "id" : "Observation.category:first",
        "path" : "Observation.category",
        "sliceName" : "first",
        "short" : "検体検査では、http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS のコード表から\"laboratory\"を設定する。",
        "definition" : "検体検査では、http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS のコード表から\"laboratory\"を設定する。",
        "comment" : "【JP Core仕様】推奨コード表「JP Core Simple Observation Category CodeSystem」より、このプロファイルでは「laboratory」固定とする。  \n(social-history | vital-signs | imaging | laboratory | procedure | survey | exam | therapy | activity)",
        "max" : "1",
        "patternCodeableConcept" : {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory"
            }
          ]
        }
      },
      {
        "id" : "Observation.category:first.coding",
        "path" : "Observation.category.coding",
        "comment" : "【JP Core仕様】推奨コード表「JP Core Simple Observation Category CodeSystem」より、このプロファイルでは「laboratory」固定とする。"
      },
      {
        "id" : "Observation.category:first.coding.system",
        "path" : "Observation.category.coding.system",
        "short" : "検体検査では、http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS のコード表を使用する。",
        "definition" : "検体検査では、http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS のコード表を使用する。",
        "min" : 1
      },
      {
        "id" : "Observation.category:first.coding.code",
        "path" : "Observation.category.coding.code",
        "short" : "検体検査を表すコード laboratory を設定する。",
        "definition" : "検体検査を表すコード laboratory を設定する。"
      },
      {
        "id" : "Observation.code",
        "path" : "Observation.code",
        "definition" : "検査の内容の説明。検査名称。",
        "comment" : "*JLAC10",
        "binding" : {
          "strength" : "preferred",
          "description" : "MEDIS 臨床検査マスター",
          "valueSet" : "http://jpfhir.jp/fhir/core/ValueSet/JP_ObservationLabResultCode_VS"
        }
      },
      {
        "id" : "Observation.code.coding",
        "path" : "Observation.code.coding",
        "definition" : "コード体系によって定義されたコードへの参照。",
        "comment" : "【JP Core仕様】SS-MIX2にならい、標準コード、ローカルコードの2つを設定可能とし、いずれか一方は必須とする。さらにJLAC10とJLAC11などの複数の標準コードも設定できるよう、上限は設けない。  \n標準コード、ローカルコードの2つまで格納可。順不同。  \nSS-MIX2だとCWE.1 ～CWE.3に標準コード、CWE.4～CWE.6にローカルコード、など（順不同）。",
        "min" : 1
      },
      {
        "id" : "Observation.code.coding.system",
        "path" : "Observation.code.coding.system",
        "definition" : "コード体系。",
        "comment" : "【JP Core仕様】標準コードの場合、JLAC10を表すURIを設定。  \nURIは本WGで定義する。"
      },
      {
        "id" : "Observation.code.coding.version",
        "path" : "Observation.code.coding.version",
        "comment" : "Where the terminology does not clearly define what string should be used to identify code system versions, the recommendation is to use the date (expressed in FHIR date format) on which that version was officially published as the version date."
      },
      {
        "id" : "Observation.code.coding.code",
        "path" : "Observation.code.coding.code"
      },
      {
        "id" : "Observation.code.coding.display",
        "path" : "Observation.code.coding.display"
      },
      {
        "id" : "Observation.code.coding.userSelected",
        "path" : "Observation.code.coding.userSelected",
        "definition" : "このコードが利用者によって、例えば利用可能なコードの選択リストから、など、直接選択されたものであることを示す。",
        "comment" : "【JP Core仕様】当面は未使用とする。"
      },
      {
        "id" : "Observation.code.text",
        "path" : "Observation.code.text",
        "definition" : "コードの表示名。報告書などに記載する場合に使用する表示名。コードを複数指定した場合(標準コード、ローカルコード)、その一般的な表現。",
        "comment" : "【JP Core仕様】このプロファイルでは、表示名として必須とする。  \n多くの場合、coding.display と同一になるが、coding.display に異なる複数の表現が格納される場合を想定し、code間で共通の表現として必須とする。",
        "min" : 1
      },
      {
        "id" : "Observation.subject",
        "path" : "Observation.subject",
        "definition" : "検体検査の対象となる患者。",
        "comment" : "【JP Core仕様】このプロファイルでは、Patient 限定、かつ必須とする。",
        "min" : 1,
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://jpfhir.jp/fhir/core/StructureDefinition/JP_Patient"]
          }
        ]
      },
      {
        "id" : "Observation.focus",
        "path" : "Observation.focus",
        "definition" : "患者当人ではなく、患者の胎児、親、ドナーなどの検査、観察の場合、その対象を示す。",
        "comment" : "【JP Core仕様】当面は未使用とする。"
      },
      {
        "id" : "Observation.encounter",
        "path" : "Observation.encounter",
        "definition" : "この検査が行われる診療イベント。医療提供者と患者の接点。",
        "comment" : "【JP Core仕様】入院外来の区別や所在場所、担当診療科の情報に使用する。  \n※このプロファイルの用途では通常は必須と考えられるが、ユースケースにより使用されない場合を考慮し、1..1に制約しない。"
      },
      {
        "id" : "Observation.effective[x]",
        "path" : "Observation.effective[x]",
        "short" : "検体を採取した日時または期間",
        "definition" : "検体検査の場合は、検体採取日時。",
        "comment" : "【JP Core仕様】このプロファイルでは、検体採取日時を設定し、必須とする。  \neffectiveInstant  \ninstant型はイベント発生のログ時間であり、未使用とする。",
        "min" : 1,
        "type" : [
          {
            "code" : "dateTime"
          },
          {
            "code" : "Period"
          },
          {
            "code" : "Timing"
          }
        ]
      },
      {
        "id" : "Observation.issued",
        "path" : "Observation.issued",
        "definition" : "この情報の発生日時。システム時刻であり、人が報告する時刻ではないことに注意。このリソースの発生時間と同じになる場合がある。",
        "comment" : "【JP Core仕様】検査結果が**システムにより**Observationリソースに格納または更新された日時。"
      },
      {
        "id" : "Observation.performer",
        "path" : "Observation.performer",
        "definition" : "検査値を確認した責任者。検査実施責任者情報。",
        "comment" : "【JP Core仕様】検査に直接責任を負う個人(つまり検査を実行、もしくは検証した人)の識別子。"
      },
      {
        "id" : "Observation.value[x]",
        "path" : "Observation.value[x]",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "type",
              "path" : "$this"
            }
          ],
          "ordered" : false,
          "rules" : "open"
        },
        "short" : "検体検査結果の値",
        "definition" : "検体検査の結果として決定された情報。",
        "comment" : "以下のデータ型はSS-MIX2では未使用のため、未使用とした。今後の議論で使用の必要性が出れば復活させる。  \nvalueBoolean  \nvalueInteger ： 検査結果値を整数値（Integer）で定義したい場合に指定する。ただし、valueQuantityで単位付き数値を示すので、通常は使わない。　SS-MIX2／HL7 V2.5→ OBX-2＝「NW」の時の OBX-5(結果値)  \nvalueRange  \nvalueRatio  \nvalueSampledData  \nvalueTime ： 検査結果値が「時間」の場合、その時間を指定する。　SS-MIX2／HL7 V2.5→ OBX-2＝「TM」の時の OBX-5(結果値)  \nvalueDateTime ： 検査結果値が「日時」の場合、その日時を指定する。　SS-MIX2／HL7 V2.5→ OBX-2＝「DT」の時の OBX-5(結果値)  \nvaluePeriod",
        "type" : [
          {
            "code" : "Quantity"
          },
          {
            "code" : "CodeableConcept"
          },
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "Observation.value[x]:valueQuantity",
        "path" : "Observation.value[x]",
        "sliceName" : "valueQuantity",
        "short" : "検査結果が「数値」の場合、値、単位を設定する。　SS-MIX2／HL7 V2.5→ OBX-2＝「NM」の時の OBX-5(結果値)、OBX-6(単位)【詳細参照】",
        "comment" : "valueQuantity.value　：結果値（数値）を定義。　SS-MIX2／HL7 V2.5：OBX-5(結果値)  \nvalueQuantity.comparator ： QuantityComparator Value setから設定。　SS-MIX2／HL7 V2.5→ 検体検査結果メッセージでは未使用となっているデータ型だが、SN型のSN.1(比較演算子)が該当する。検査値の「0未満」の場合の「未満」などに相当するコードを設定。  \nvalueQuantity.unit ： systemで示す単位のValue setの文字列を指定。　SS-MIX2／HL7 V2.5→ OBX-6(単位) CWE.2 テキスト  \nvalueQuantity.system ： 単位のValue set名を指定。　SS-MIX2／HL7 V2.5→ OBX-6(単位) CWE.3 コード体系 HL7では「ISO+」だが、ローカルコード99zzzのHL7標準の「ISO+」が示すOID、ローカルコードの場合はOIDを別途取得必要  \nvalueQuantity.code ： systemで示す単位のValue setのコードを指定。　SS-MIX2／HL7 V2.5→ OBX-6(単位) CWE.1 識別子",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "Observation.value[x]:valueCodeableConcept",
        "path" : "Observation.value[x]",
        "sliceName" : "valueCodeableConcept",
        "short" : "検査結果が「コード値」の場合、コード、テキスト、コードのValue setを定義する。　SS-MIX2／HL7 V2.5→ OBX-2＝「CWE」の時の OBX-5(結果値)【詳細参照】",
        "comment" : "valueCodeableConcept.coding　：ローカルコードと国際標準コードなど複数指定できる。　SS-MIX2／HL7 V2.5→ CWEは正規コード＋代替コードの2種類登録可能。  \nvalueCodeableConcept.coding.system ： 対象のValue set名を指定。　SS-MIX2／HL7 V2.5→ CWE.3 or 6 コード体系。対象コードの OIDを設定  \nvalueCodeableConcept.coding.version ： 対象のValue setのバージョンを指定。　SS-MIX2／HL7 V2.5→ CWE.7 コード体系バージョン ID valueCodeableConcept.coding.code　：対象のValue setのコードを指定。　SS-MIX2／HL7 V2.5→ CWE.1 or 4 識別子。対象コードシステムのコード  \nvalueCodeableConcept.coding.display ： 対象のValue setのテキストを指定。　SS-MIX2／HL7 V2.5→ CWE.2 or 5 テキスト。対象コードの名称  \nvalueCodeableConcept.coding.userselected ： 未使用。  \nvalueCodeableConcept.text ： コードが示す意味を指定する。通常は.coding.displayの値を指定するが、複数ある場合は適宜編集すること。　SS-MIX2／HL7 V2.5→ CWE.2 テキスト。coding.display と同じ。",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "CodeableConcept"
          }
        ]
      },
      {
        "id" : "Observation.value[x]:valueString",
        "path" : "Observation.value[x]",
        "sliceName" : "valueString",
        "short" : "検査結果値が「文字列」の場合、その文字列を指定する。SS-MIX2／HL7 V2.5→ OBX-2＝「ST」の時の OBX-5(結果値)",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "Observation.dataAbsentReason",
        "path" : "Observation.dataAbsentReason",
        "definition" : "検査結果値が欠落している理由。",
        "comment" : "【JP Core仕様】SS-MIX2で未使用だが、valueの欠落時に使用する必要があり、重要な項目である。  \n制約「obs-6」に示す通り、valueが存在する場合、当該項目は存在してはならない。  \ntextのみでの使用は基本的に不可とし、必ずcodingを設定すること。  \n(unknown |   asked-unknown |   temp-unknown |   not-asked |   asked-declined | masked | not-applicable | unsupported | as-text | error |   not-a-number |   negative-infinity |   positive-infinity | not-performed | not-permitted)"
      },
      {
        "id" : "Observation.interpretation",
        "path" : "Observation.interpretation",
        "short" : "High, low, normal, etc. 高、低、正常など",
        "definition" : "検査結果値の、（高、低、正常）といったカテゴリー評価。結果報告書に記載されることもある情報。",
        "comment" : "【JP Core仕様】拡張可コード表「ObservationInterpretationCodes」を使用する。  \nコード表が大きいため、下記参照。  \nhttps://www.hl7.org/fhir/R4/valueset-observation-interpretation.html",
        "requirements" : "特に数値結果については、結果の重要性を完全に理解するために解釈を必要とする場合がある。"
      },
      {
        "id" : "Observation.note",
        "path" : "Observation.note",
        "definition" : "検査、あるいは結果に関するコメント。フリーテキストの追加情報として使用可能。",
        "comment" : "May include general statements about the observation, or statements about significant, unexpected or unreliable results values, or information about its source when relevant to its interpretation."
      },
      {
        "id" : "Observation.note.author[x]",
        "path" : "Observation.note.author[x]",
        "comment" : "Organization is used when there's no need for specific attribution as to who made the comment."
      },
      {
        "id" : "Observation.note.time",
        "path" : "Observation.note.time"
      },
      {
        "id" : "Observation.note.text",
        "path" : "Observation.note.text",
        "comment" : "Systems are not required to have markdown support, so the text should be readable without markdown processing. The markdown syntax is GFM - see https://github.github.com/gfm/"
      },
      {
        "id" : "Observation.bodySite",
        "path" : "Observation.bodySite",
        "definition" : "検査が行われた患者の体の部位。検体検査に関しては、当面は使用しない。",
        "comment" : "【JP Core仕様】当面は未使用とする。"
      },
      {
        "id" : "Observation.method",
        "path" : "Observation.method",
        "short" : "実施の方法",
        "definition" : "検体検査の検査方法、測定方法。",
        "comment" : "Observation.code の code から測定方法が暗黙的でない場合にのみ使用する。  \n【JP Core仕様】Observation.code に JLAC10コードを使用する場合、測定方法コードが含まれているため method は使用しない。Observation.code から測定方法が判明しない場合や、実際の測定方法が異なる場合に使用することになるが、現状では運用が困難と想定されるため、当面は未使用とする。",
        "requirements" : "In some cases, method can impact results and is thus used for determining whether results can be compared or determining significance of results.  \n場合により、測定方法は結果に影響を与える可能性があるため、結果を比較できるかどうかを判断したり、結果の重要性を判断したりするために使用される。"
      },
      {
        "id" : "Observation.specimen",
        "path" : "Observation.specimen",
        "definition" : "この検査に使用された検体（標本）。",
        "comment" : "【JP Core仕様】検体検査プロファイルでは必須とする。",
        "min" : 1
      },
      {
        "id" : "Observation.device",
        "path" : "Observation.device",
        "definition" : "検査装置、機器。",
        "comment" : "【JP Core仕様】検査に使用した機器等の情報に使用する。"
      },
      {
        "id" : "Observation.referenceRange",
        "path" : "Observation.referenceRange",
        "definition" : "推奨範囲として結果値を解釈するためのガイダンス。基準値。",
        "comment" : "【JP Core仕様】可能な限りlow、highに構造化すべき。構造化できない場合、あるいはlow、highに該当しない場合はtextを使用。"
      },
      {
        "id" : "Observation.referenceRange.low",
        "path" : "Observation.referenceRange.low",
        "comment" : "The context of use may frequently define what kind of quantity this is and therefore what kind of units can be used. The context of use may also restrict the values for the comparator."
      },
      {
        "id" : "Observation.referenceRange.high",
        "path" : "Observation.referenceRange.high",
        "comment" : "The context of use may frequently define what kind of quantity this is and therefore what kind of units can be used. The context of use may also restrict the values for the comparator."
      },
      {
        "id" : "Observation.referenceRange.type",
        "path" : "Observation.referenceRange.type",
        "definition" : "対象となる母集団のどの部分に適用するかを示すコード。正常範囲、要治療範囲、など。",
        "comment" : "This SHOULD be populated if there is more than one range.  If this element is not present then the normal range is assumed."
      },
      {
        "id" : "Observation.referenceRange.appliesTo",
        "path" : "Observation.referenceRange.appliesTo",
        "definition" : "基準値が適用される母集団を示すコード。人種、性別など。",
        "comment" : "This SHOULD be populated if there is more than one range.  If this element is not present then the normal population is assumed."
      },
      {
        "id" : "Observation.referenceRange.age",
        "path" : "Observation.referenceRange.age",
        "definition" : "基準値が適用される年齢。新生児の場合、週数もありうる。",
        "comment" : "The stated low and high value are assumed to have arbitrarily high precision when it comes to determining which values are in the range. I.e. 1.99 is not in the range 2 -> 3."
      },
      {
        "id" : "Observation.referenceRange.text",
        "path" : "Observation.referenceRange.text",
        "definition" : "量的範囲で表せない場合などに使用する。"
      },
      {
        "id" : "Observation.hasMember",
        "path" : "Observation.hasMember",
        "definition" : "グループ検査の場合、この検査に含まれる複数の検査結果項目を示す。",
        "comment" : "【JP Core仕様】この1検査結果で複数の検査結果項目を含むような場合、value[x]には結果値を設定せず、それら検査結果項目を示すJP_Observation_LabResultへのReferenceをhasMemberに設定する。"
      },
      {
        "id" : "Observation.derivedFrom",
        "path" : "Observation.derivedFrom",
        "definition" : "この検査値の発生元である関連リソース。例えば他のObservation を受けて、本検査値が発生した場合など。",
        "comment" : "All the reference choices that are listed in this element can represent clinical observations and other measurements that may be the source for a derived value.  The most common reference will be another Observation.  For a discussion on the ways Observations can assembled in groups together, see [Notes](observation.html#obsgrouping) below."
      },
      {
        "id" : "Observation.component",
        "path" : "Observation.component",
        "definition" : "一度のタイミングでの1回の検査で複数の結果を同時に得る場合にのみ使用される。例えば、血圧の収縮期、拡張期。新生児のApgarスコア。質問に対する複数の回答（飲んだアルコールの種類、など）。",
        "comment" : "For a discussion on the ways Observations can be assembled in groups together see [Notes](observation.html#notes) below."
      },
      {
        "id" : "Observation.component.code",
        "path" : "Observation.component.code",
        "comment" : "*All* code-value and  component.code-component.value pairs need to be taken into account to correctly understand the meaning of the observation."
      },
      {
        "id" : "Observation.component.value[x]",
        "path" : "Observation.component.value[x]",
        "comment" : "Used when observation has a set of component observations. An observation may have both a value (e.g. an  Apgar score)  and component observations (the observations from which the Apgar score was derived). If a value is present, the datatype for this element should be determined by Observation.code. A CodeableConcept with just a text would be used instead of a string if the field was usually coded, or if the type associated with the Observation.code defines a coded value.  For additional guidance, see the [Notes section](observation.html#notes) below."
      },
      {
        "id" : "Observation.component.interpretation",
        "path" : "Observation.component.interpretation",
        "comment" : "Historically used for laboratory results (known as 'abnormal flag' ),  its use extends to other use cases where coded interpretations  are relevant.  Often reported as one or more simple compact codes this element is often placed adjacent to the result value in reports and flow sheets to signal the meaning/normalcy status of the result."
      },
      {
        "id" : "Observation.component.referenceRange",
        "path" : "Observation.component.referenceRange",
        "comment" : "Most observations only have one generic reference range. Systems MAY choose to restrict to only supplying the relevant reference range based on knowledge about the patient (e.g., specific to the patient's age, gender, weight and other factors), but this might not be possible or appropriate. Whenever more than one reference range is supplied, the differences between them SHOULD be provided in the reference range and/or age properties."
      }
    ]
  }
}

```
