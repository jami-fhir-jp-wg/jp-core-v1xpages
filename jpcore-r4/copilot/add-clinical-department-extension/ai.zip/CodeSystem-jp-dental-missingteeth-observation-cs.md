# JP Core Dental MissingTeethObservation CodeSystem - HL7 FHIR JP Core ImplementationGuide v1.3.0-dev

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **JP Core Dental MissingTeethObservation CodeSystem**

## CodeSystem: JP Core Dental MissingTeethObservation CodeSystem 

* **項目**: *定義URL*
  * **内容**: http://jpfhir.jp/fhir/core/CodeSystem/JP_DentalMissingTeethObservation_CS
* **項目**: *Version*
  * **内容**: 1.3.0-dev
* **項目**: *Name*
  * **内容**: JP_DentalMissingTeethObservation_CS
* **項目**: *Title*
  * **内容**: JP Core Dental MissingTeethObservation CodeSystem
* **項目**: *Status*
  * **内容**: Active ( 2024-12-30 )
* **項目**: *Copyright*
  * **内容**: Copyright Japan Dental Association 日本歯科医師会 & FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI) 一般社団法人日本医療情報学会FHIR国内実装基盤研究会

 
JP Coreにて定義した歯科のObservationリソースに関する欠損歯の観察結果コード 

 This Code system is referenced in the content logical definition of the following value sets: 

* [JP_DentalMissingTeethObservation_VS](ValueSet-jp-dental-missingteeth-observation-vs.md)
* [JP_DentalTeethObservation_VS](ValueSet-jp-dental-teethobservation-vs.md)

本実装ガイドへのご質問・ご指摘については、
[GitHub Issue](https://github.com/jami-fhir-jp-wg/jp-core-v1x/issues)および
[GitHub PullRequest](https://github.com/jami-fhir-jp-wg/jp-core-v1x/pulls)にて受け付けている。

## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "jp-dental-missingteeth-observation-cs",
  "url" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_DentalMissingTeethObservation_CS",
  "version" : "1.3.0-dev",
  "name" : "JP_DentalMissingTeethObservation_CS",
  "title" : "JP Core Dental MissingTeethObservation CodeSystem",
  "status" : "active",
  "experimental" : false,
  "date" : "2024-12-30",
  "publisher" : "FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI)",
  "contact" : [
    {
      "name" : "FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI)",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://jpfhir.jp"
        },
        {
          "system" : "email",
          "value" : "office@hlfhir.jp"
        }
      ]
    }
  ],
  "description" : "JP Coreにて定義した歯科のObservationリソースに関する欠損歯の観察結果コード",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "JP",
          "display" : "Japan"
        }
      ]
    }
  ],
  "copyright" : "Copyright Japan Dental Association 日本歯科医師会 & FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI) 一般社団法人日本医療情報学会FHIR国内実装基盤研究会",
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 120,
  "concept" : [
    {
      "code" : "TM-2-01",
      "display" : "ポンティック（ブリッジのリテイナー（５歯以下）"
    },
    {
      "code" : "TM-2-02",
      "display" : "ポンティック（ブリッジのリテイナー（６歯以上）"
    },
    {
      "code" : "TM-2-03",
      "display" : "ポンティック（歯周治療用装置（冠形態）ブリッジ"
    },
    {
      "code" : "TM-2-04",
      "display" : "ポンティック（プロビジョナルブリッジ）"
    },
    {
      "code" : "TM-2-05",
      "display" : "ポンティック（鋳造ポンティック・銀色）（Ｐｏｎ）"
    },
    {
      "code" : "TM-2-06",
      "display" : "ポンティック（鋳造ポンティック・黒色）（Ｐｏｎ）"
    },
    {
      "code" : "TM-2-07",
      "display" : "ポンティック（鋳造ポンティック・金色）（Ｐｏｎ）"
    },
    {
      "code" : "TM-2-08",
      "display" : "ポンティック（前装ポンティック・銀色）（Ｐｏｎ）"
    },
    {
      "code" : "TM-2-09",
      "display" : "ポンティック（前装ポンティック・黒色）（Ｐｏｎ）"
    },
    {
      "code" : "TM-2-10",
      "display" : "ポンティック（前装ポンティック・金色）（Ｐｏｎ）"
    },
    {
      "code" : "TM-2-11",
      "display" : "ポンティック（金属裏装ポンティック・銀色）（Ｐｏｎ）"
    },
    {
      "code" : "TM-2-12",
      "display" : "ポンティック（金属裏装ポンティック・黒色）（Ｐｏｎ）"
    },
    {
      "code" : "TM-2-13",
      "display" : "ポンティック（金属裏装ポンティック・金色）（Ｐｏｎ）"
    },
    {
      "code" : "TM-2-14",
      "display" : "ポンティック（メタルボンドポンティック・銀色）（Ｐｏｎ）"
    },
    {
      "code" : "TM-2-15",
      "display" : "ポンティック（メタルボンドポンティック・黒色）（Ｐｏｎ）"
    },
    {
      "code" : "TM-2-16",
      "display" : "ポンティック（メタルボンドポンティック・金色）（Ｐｏｎ）"
    },
    {
      "code" : "TM-2-17",
      "display" : "ポンティック（非金属ポンティック・レジン系（様）・歯冠色）（Ｐｏｎ）"
    },
    {
      "code" : "TM-2-18",
      "display" : "ポンティック（非金属ポンティック・セラミック系（様）・歯冠色）（Ｐｏｎ）"
    },
    {
      "code" : "TM-2-19",
      "display" : "ポンティック（非金属ポンティック・材質不明、又は材質記載なし・歯冠色）（Ｐｏｎ）"
    },
    {
      "code" : "TM-2-20",
      "display" : "補綴隙（鋳造隙・銀色）"
    },
    {
      "code" : "TM-2-21",
      "display" : "補綴隙（鋳造隙・黒色）"
    },
    {
      "code" : "TM-2-22",
      "display" : "補綴隙（鋳造隙・金色）"
    },
    {
      "code" : "TM-2-23",
      "display" : "補綴隙（前装隙・銀色）"
    },
    {
      "code" : "TM-2-24",
      "display" : "補綴隙（前装隙・黒色）"
    },
    {
      "code" : "TM-2-25",
      "display" : "補綴隙（前装隙・金色）"
    },
    {
      "code" : "TM-2-26",
      "display" : "補綴隙（金属裏装隙・銀色）"
    },
    {
      "code" : "TM-2-27",
      "display" : "補綴隙（金属裏装隙・黒色）"
    },
    {
      "code" : "TM-2-28",
      "display" : "補綴隙（金属裏装隙・金色）"
    },
    {
      "code" : "TM-2-29",
      "display" : "補綴隙（メタルボンド隙・銀色）"
    },
    {
      "code" : "TM-2-30",
      "display" : "補綴隙（メタルボンド隙・黒色）"
    },
    {
      "code" : "TM-2-31",
      "display" : "補綴隙（メタルボンド隙・金色）"
    },
    {
      "code" : "TM-2-32",
      "display" : "補綴隙（非金属隙・レジン系（様）・歯冠色）"
    },
    {
      "code" : "TM-2-33",
      "display" : "補綴隙（非金属隙・セラミック系（様）・歯冠色）"
    },
    {
      "code" : "TM-2-34",
      "display" : "補綴隙（非金属隙・材質不明、又は材質記載なし・歯冠色）"
    },
    {
      "code" : "TM-3-01",
      "display" : "同顎１装置目（固定性）"
    },
    {
      "code" : "TM-3-02",
      "display" : "同顎２装置目（固定性）"
    },
    {
      "code" : "TM-3-03",
      "display" : "同顎３装置目（固定性）"
    },
    {
      "code" : "TM-3-04",
      "display" : "同顎４装置目（固定性）"
    },
    {
      "code" : "TM-3-05",
      "display" : "同顎５装置目（固定性）"
    },
    {
      "code" : "TM-3-06",
      "display" : "同顎６装置目（固定性）"
    },
    {
      "code" : "TM-3-07",
      "display" : "同顎７装置目（固定性）"
    },
    {
      "code" : "TM-3-08",
      "display" : "同顎８装置目（固定性）"
    },
    {
      "code" : "TM-3-09",
      "display" : "同顎１装置目（半固定性・可撤性）"
    },
    {
      "code" : "TM-3-10",
      "display" : "同顎２装置目（半固定性・可撤性）"
    },
    {
      "code" : "TM-3-11",
      "display" : "同顎３装置目（半固定性・可撤性）"
    },
    {
      "code" : "TM-3-12",
      "display" : "同顎４装置目（半固定性・可撤性）"
    },
    {
      "code" : "TM-3-13",
      "display" : "同顎５装置目（半固定性・可撤性）"
    },
    {
      "code" : "TM-3-14",
      "display" : "同顎６装置目（半固定性・可撤性）"
    },
    {
      "code" : "TM-3-15",
      "display" : "同顎７装置目（半固定性・可撤性）"
    },
    {
      "code" : "TM-3-16",
      "display" : "同顎８装置目（半固定性・可撤性）"
    },
    {
      "code" : "TM-4-01",
      "display" : "有床義歯（内容不明）"
    },
    {
      "code" : "TM-4-02",
      "display" : "有床義歯（レジン床）"
    },
    {
      "code" : "TM-4-03",
      "display" : "有床義歯（熱可塑性樹脂床）"
    },
    {
      "code" : "TM-4-04",
      "display" : "有床義歯（セラミック床）"
    },
    {
      "code" : "TM-4-05",
      "display" : "有床義歯（金属床）"
    },
    {
      "code" : "TM-4-06",
      "display" : "有床義歯（金床）"
    },
    {
      "code" : "TM-4-07",
      "display" : "有床義歯（ノンクラスプデンチャー）"
    },
    {
      "code" : "TM-4-08",
      "display" : "総義歯（内容不明）（ＦＤ）"
    },
    {
      "code" : "TM-4-09",
      "display" : "総義歯（レジン床）（ＦＤ）"
    },
    {
      "code" : "TM-4-10",
      "display" : "総義歯（熱可塑性樹脂床）（ＦＤ）"
    },
    {
      "code" : "TM-4-11",
      "display" : "総義歯（セラミック床）（ＦＤ）"
    },
    {
      "code" : "TM-4-12",
      "display" : "総義歯（金属床）（ＦＤ）"
    },
    {
      "code" : "TM-4-13",
      "display" : "総義歯（金床）（ＦＤ）"
    },
    {
      "code" : "TM-4-14",
      "display" : "総義歯（ノンクラスプデンチャー）（ＦＤ）"
    },
    {
      "code" : "TM-4-15",
      "display" : "局部義歯（内容不明）（ＰＤ）"
    },
    {
      "code" : "TM-4-16",
      "display" : "局部義歯（レジン床）（ＰＤ）"
    },
    {
      "code" : "TM-4-17",
      "display" : "局部義歯（熱可塑性樹脂床）（ＰＤ）"
    },
    {
      "code" : "TM-4-18",
      "display" : "局部義歯（セラミック床）（ＰＤ）"
    },
    {
      "code" : "TM-4-19",
      "display" : "局部義歯（金属床）（ＰＤ）"
    },
    {
      "code" : "TM-4-20",
      "display" : "局部義歯（金床）（ＰＤ）"
    },
    {
      "code" : "TM-4-21",
      "display" : "局部義歯（ノンクラスプデンチャー）（ＰＤ）"
    },
    {
      "code" : "TM-4-22",
      "display" : "口蓋補綴・顎補綴"
    },
    {
      "code" : "TM-4-23",
      "display" : "歯周治療用装置（床義歯）"
    },
    {
      "code" : "TM-4-24",
      "display" : "口蓋補綴・顎補綴（イ 腫瘍、顎骨嚢胞等による顎骨切除に対する口蓋補綴装置又は顎補綴装置）"
    },
    {
      "code" : "TM-4-25",
      "display" : "口蓋補綴・顎補綴（ロ オクルーザルランプを付与した口腔内装置）"
    },
    {
      "code" : "TM-4-26",
      "display" : "口蓋補綴・顎補綴（ハ 発音補整装置）"
    },
    {
      "code" : "TM-4-27",
      "display" : "口蓋補綴・顎補綴（ニ 発音補助装置）"
    },
    {
      "code" : "TM-4-28",
      "display" : "口蓋補綴・顎補綴（ホ ホッツ床）"
    },
    {
      "code" : "TM-4-29",
      "display" : "アタッチメント有床義歯（内容不明）"
    },
    {
      "code" : "TM-4-30",
      "display" : "アタッチメント有床義歯（レジン床）"
    },
    {
      "code" : "TM-4-31",
      "display" : "アタッチメント有床義歯（熱可塑性樹脂床）"
    },
    {
      "code" : "TM-4-32",
      "display" : "アタッチメント有床義歯（セラミック床）"
    },
    {
      "code" : "TM-4-33",
      "display" : "アタッチメント有床義歯（金属床）"
    },
    {
      "code" : "TM-4-34",
      "display" : "アタッチメント有床義歯（金床）"
    },
    {
      "code" : "TM-4-35",
      "display" : "アタッチメント総義歯（内容不明）（ＦＤ）"
    },
    {
      "code" : "TM-4-36",
      "display" : "アタッチメント総義歯（レジン床）（ＦＤ）"
    },
    {
      "code" : "TM-4-37",
      "display" : "アタッチメント総義歯（熱可塑性樹脂床）（ＦＤ）"
    },
    {
      "code" : "TM-4-38",
      "display" : "アタッチメント総義歯（セラミック床）（ＦＤ）"
    },
    {
      "code" : "TM-4-39",
      "display" : "アタッチメント総義歯（金属床）（ＦＤ）"
    },
    {
      "code" : "TM-4-40",
      "display" : "アタッチメント総義歯（金床）（ＦＤ）"
    },
    {
      "code" : "TM-4-41",
      "display" : "アタッチメント局部義歯（内容不明）（ＰＤ）"
    },
    {
      "code" : "TM-4-42",
      "display" : "アタッチメント局部義歯（レジン床）（ＰＤ）"
    },
    {
      "code" : "TM-4-43",
      "display" : "アタッチメント局部義歯（熱可塑性樹脂床）（ＰＤ）"
    },
    {
      "code" : "TM-4-44",
      "display" : "アタッチメント局部義歯（セラミック床）（ＰＤ）"
    },
    {
      "code" : "TM-4-45",
      "display" : "アタッチメント局部義歯（金属床）（ＰＤ）"
    },
    {
      "code" : "TM-4-46",
      "display" : "アタッチメント局部義歯（金床）（ＰＤ）"
    },
    {
      "code" : "TM-5-01",
      "display" : "同顎２床目"
    },
    {
      "code" : "TM-5-02",
      "display" : "同顎３床目"
    },
    {
      "code" : "TM-6-01",
      "display" : "レジン歯（材質不明、又は材質記載なしの非金属人工歯含む）"
    },
    {
      "code" : "TM-6-02",
      "display" : "スルフォン樹脂レジン歯"
    },
    {
      "code" : "TM-6-03",
      "display" : "硬質レジン歯"
    },
    {
      "code" : "TM-6-04",
      "display" : "金属歯"
    },
    {
      "code" : "TM-6-05",
      "display" : "陶歯"
    },
    {
      "code" : "TM-7-01",
      "display" : "義歯補綴隙（レジン隙、材質不明、又は材質記載なしの非金属隙含む）"
    },
    {
      "code" : "TM-7-02",
      "display" : "義歯補綴隙（スルフォン樹脂レジン隙）"
    },
    {
      "code" : "TM-7-03",
      "display" : "義歯補綴隙（硬質レジン隙）"
    },
    {
      "code" : "TM-7-04",
      "display" : "義歯補綴隙（金属隙）"
    },
    {
      "code" : "TM-7-05",
      "display" : "義歯補綴隙（陶歯）"
    },
    {
      "code" : "TM-8-01",
      "display" : "屈曲バー（リンガル／パラタル）（Ｂａｒ）"
    },
    {
      "code" : "TM-8-02",
      "display" : "鋳造バー／ストラップ（リンガル／パラタル）（Ｃａｓｔ　Ｂａｒ）"
    },
    {
      "code" : "TM-8-03",
      "display" : "プレート（リンガル／パラタル）"
    },
    {
      "code" : "TM-8-04",
      "display" : "リンガルエプロン"
    },
    {
      "code" : "TM-9-01",
      "display" : "補強線"
    },
    {
      "code" : "TM-10-01",
      "display" : "骨瘤（唇側・頬側）（Ｔｏｒ）"
    },
    {
      "code" : "TM-10-02",
      "display" : "骨瘤（舌側・口蓋側）（Ｔｏｒ）"
    },
    {
      "code" : "TM-10-03",
      "display" : "骨瘤（唇側・頬側および舌側・口蓋側）（Ｔｏｒ）"
    },
    {
      "code" : "TM-10-04",
      "display" : "骨瘤（側不明）（Ｔｏｒ）"
    },
    {
      "code" : "TM-11-01",
      "display" : "アタッチメント（磁性：磁石構造体など）"
    },
    {
      "code" : "TM-11-02",
      "display" : "アタッチメント（バー：スリーブなど）"
    },
    {
      "code" : "TM-11-03",
      "display" : "アタッチメント（その他）"
    }
  ]
}

```
