# JP Core Observation BodyMeasurement Code CodeSystem - HL7 FHIR JP Core ImplementationGuide v1.3.0-dev

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **JP Core Observation BodyMeasurement Code CodeSystem**

## CodeSystem: JP Core Observation BodyMeasurement Code CodeSystem 

* **項目**: *定義URL*
  * **内容**: http://jpfhir.jp/fhir/core/CodeSystem/JP_ObservationBodyMeasurementCode_CS
* **項目**: *Version*
  * **内容**: 1.3.0-dev
* **項目**: *Name*
  * **内容**: JP_ObservationBodyMeasurementCode_CS
* **項目**: *Title*
  * **内容**: JP Core Observation BodyMeasurement Code CodeSystem
* **項目**: *Status*
  * **内容**: Active ( 2024-12-30 )
* **項目**: *Copyright*
  * **内容**: Copyright MEDIS-DC 一般財団法人 医療情報システム開発センター

 
Observation（身体計測）で使用する項目コードのコードシステム （出典：看護実践用語標準マスターの概要＜看護行為編＞Ver. 3. 6） 

 This Code system is referenced in the content logical definition of the following value sets: 

* This CodeSystem is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

本実装ガイドへのご質問・ご指摘については、
[GitHub Issue](https://github.com/jami-fhir-jp-wg/jp-core-v1x/issues)および
[GitHub PullRequest](https://github.com/jami-fhir-jp-wg/jp-core-v1x/pulls)にて受け付けている。

## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "jp-observation-bodymeasurement-code-cs",
  "url" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_ObservationBodyMeasurementCode_CS",
  "version" : "1.3.0-dev",
  "name" : "JP_ObservationBodyMeasurementCode_CS",
  "title" : "JP Core Observation BodyMeasurement Code CodeSystem",
  "status" : "active",
  "experimental" : false,
  "date" : "2024-12-30",
  "publisher" : "FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI)",
  "contact" : [
    {
      "name" : "FHIR Japanese implementation research working group in Japan Association of Medical Informatics (JAMI)",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://jpfhir.jp"
        },
        {
          "system" : "email",
          "value" : "office@hlfhir.jp"
        }
      ]
    }
  ],
  "description" : "Observation（身体計測）で使用する項目コードのコードシステム　（出典：看護実践用語標準マスターの概要＜看護行為編＞Ver. 3. 6）",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "JP",
          "display" : "Japan"
        }
      ]
    }
  ],
  "copyright" : "Copyright MEDIS-DC 一般財団法人 医療情報システム開発センター",
  "caseSensitive" : true,
  "valueSet" : "http://jpfhir.jp/fhir/core/ValueSet/JP_ObservationBodyMeasurementCode_VS",
  "content" : "complete",
  "count" : 116,
  "concept" : [
    {
      "code" : "31000296",
      "display" : "体重",
      "definition" : "体重(Kg)"
    },
    {
      "code" : "31000297",
      "display" : "体重",
      "definition" : "体重(g)"
    },
    {
      "code" : "31000298",
      "display" : "身長"
    },
    {
      "code" : "31000299",
      "display" : "胸囲"
    },
    {
      "code" : "31000300",
      "display" : "腹囲（臍上）"
    },
    {
      "code" : "31000301",
      "display" : "腹囲"
    },
    {
      "code" : "31000901",
      "display" : "開口度",
      "definition" : "開口度(mm)"
    },
    {
      "code" : "31000902",
      "display" : "開口度",
      "definition" : "開口度(横指)"
    },
    {
      "code" : "31001697",
      "display" : "体脂肪率"
    },
    {
      "code" : "31002749",
      "display" : "右上腕周囲"
    },
    {
      "code" : "31002750",
      "display" : "左上腕周囲"
    },
    {
      "code" : "31002751",
      "display" : "右前腕周囲"
    },
    {
      "code" : "31002752",
      "display" : "左前腕周囲"
    },
    {
      "code" : "31002753",
      "display" : "右大腿周囲"
    },
    {
      "code" : "31002754",
      "display" : "左大腿周囲"
    },
    {
      "code" : "31002755",
      "display" : "右下腿周囲"
    },
    {
      "code" : "31002756",
      "display" : "左下腿周囲"
    },
    {
      "code" : "31002900",
      "display" : "出生体重"
    },
    {
      "code" : "31003020",
      "display" : "ＢＭＩ"
    },
    {
      "code" : "31003138",
      "display" : "標準体重"
    },
    {
      "code" : "31003177",
      "display" : "肘窩上部１０ｃｍ周囲長（右患側）"
    },
    {
      "code" : "31003178",
      "display" : "肘窩上部１０ｃｍ周囲長（左患側）"
    },
    {
      "code" : "31003179",
      "display" : "肘窩上部１０ｃｍ周囲長（患側）"
    },
    {
      "code" : "31003180",
      "display" : "肘窩上部１０ｃｍ周囲長（右健側）"
    },
    {
      "code" : "31003181",
      "display" : "肘窩上部１０ｃｍ周囲長（左健側）"
    },
    {
      "code" : "31003182",
      "display" : "肘窩上部１０ｃｍ周囲長（健側）"
    },
    {
      "code" : "31003183",
      "display" : "肘窩下部５ｃｍ周囲長（右患側）"
    },
    {
      "code" : "31003184",
      "display" : "肘窩下部５ｃｍ周囲長（左患側）"
    },
    {
      "code" : "31003185",
      "display" : "肘窩下部５ｃｍ周囲長（患側）"
    },
    {
      "code" : "31003186",
      "display" : "肘窩下部５ｃｍ周囲長（右健側）"
    },
    {
      "code" : "31003187",
      "display" : "肘窩下部５ｃｍ周囲長（左健側）"
    },
    {
      "code" : "31003188",
      "display" : "肘窩下部５ｃｍ周囲長（健側）"
    },
    {
      "code" : "31003189",
      "display" : "手関節周囲長（右患側）"
    },
    {
      "code" : "31003190",
      "display" : "手関節周囲長（左患側）"
    },
    {
      "code" : "31003191",
      "display" : "手関節周囲長（患側）"
    },
    {
      "code" : "31003192",
      "display" : "手関節周囲長（右健側）"
    },
    {
      "code" : "31003193",
      "display" : "手関節周囲長（左健側）"
    },
    {
      "code" : "31003194",
      "display" : "手関節周囲長（健側）"
    },
    {
      "code" : "31003195",
      "display" : "ＭＰ関節周囲長（右患側）"
    },
    {
      "code" : "31003196",
      "display" : "ＭＰ関節周囲長（左患側）"
    },
    {
      "code" : "31003197",
      "display" : "ＭＰ関節周囲長（患側）"
    },
    {
      "code" : "31003198",
      "display" : "ＭＰ関節周囲長（右健側）"
    },
    {
      "code" : "31003199",
      "display" : "ＭＰ関節周囲長（左健側）"
    },
    {
      "code" : "31003200",
      "display" : "ＭＰ関節周囲長（健側）"
    },
    {
      "code" : "31003201",
      "display" : "大腿根部周囲長（右患側）"
    },
    {
      "code" : "31003202",
      "display" : "大腿根部周囲長（左患側）"
    },
    {
      "code" : "31003203",
      "display" : "大腿根部周囲長（患側）"
    },
    {
      "code" : "31003204",
      "display" : "大腿根部周囲長（右健側）"
    },
    {
      "code" : "31003205",
      "display" : "大腿根部周囲長（左健側）"
    },
    {
      "code" : "31003206",
      "display" : "大腿根部周囲長（健側）"
    },
    {
      "code" : "31003207",
      "display" : "膝窩上部１０ｃｍ周囲長（右患側）"
    },
    {
      "code" : "31003208",
      "display" : "膝窩上部１０ｃｍ周囲長（左患側）"
    },
    {
      "code" : "31003209",
      "display" : "膝窩上部１０ｃｍ周囲長（患側）"
    },
    {
      "code" : "31003210",
      "display" : "膝窩上部１０ｃｍ周囲長（右健側）"
    },
    {
      "code" : "31003211",
      "display" : "膝窩上部１０ｃｍ周囲長（左健側）"
    },
    {
      "code" : "31003212",
      "display" : "膝窩上部１０ｃｍ周囲長（健側）"
    },
    {
      "code" : "31003213",
      "display" : "膝窩下部５ｃｍ周囲長（右患側）"
    },
    {
      "code" : "31003214",
      "display" : "膝窩下部５ｃｍ周囲長（左患側）"
    },
    {
      "code" : "31003215",
      "display" : "膝窩下部５ｃｍ周囲長（患側）"
    },
    {
      "code" : "31003216",
      "display" : "膝窩下部５ｃｍ周囲長（右健側）"
    },
    {
      "code" : "31003217",
      "display" : "膝窩下部５ｃｍ周囲長（左健側）"
    },
    {
      "code" : "31003218",
      "display" : "膝窩下部５ｃｍ周囲長（健側）"
    },
    {
      "code" : "31003219",
      "display" : "足関節周囲長（右患側）"
    },
    {
      "code" : "31003220",
      "display" : "足関節周囲長（左患側）"
    },
    {
      "code" : "31003221",
      "display" : "足関節周囲長（患側）"
    },
    {
      "code" : "31003222",
      "display" : "足関節周囲長（右健側）"
    },
    {
      "code" : "31003223",
      "display" : "足関節周囲長（左健側）"
    },
    {
      "code" : "31003224",
      "display" : "足関節周囲長（健側）"
    },
    {
      "code" : "31003225",
      "display" : "足背周囲長（右患側）"
    },
    {
      "code" : "31003226",
      "display" : "足背周囲長（左患側）"
    },
    {
      "code" : "31003227",
      "display" : "足背周囲長（患側）"
    },
    {
      "code" : "31003228",
      "display" : "足背周囲長（右健側）"
    },
    {
      "code" : "31003229",
      "display" : "足背周囲長（左健側）"
    },
    {
      "code" : "31003230",
      "display" : "足背周囲長（健側）"
    },
    {
      "code" : "31003421",
      "display" : "上腕周囲長（ＡＣ）"
    },
    {
      "code" : "31003422",
      "display" : "下腿周囲長（ＣＣ）"
    },
    {
      "code" : "31003423",
      "display" : "上腕筋囲"
    },
    {
      "code" : "31003424",
      "display" : "上腕筋面積"
    },
    {
      "code" : "31003425",
      "display" : "上腕三頭筋部皮下脂肪厚（ＴＳＦ）"
    },
    {
      "code" : "31003426",
      "display" : "肩甲骨下部皮下脂肪厚（ＳＳＦ）"
    },
    {
      "code" : "31003601",
      "display" : "肥満度"
    },
    {
      "code" : "31003602",
      "display" : "ローレル指数"
    },
    {
      "code" : "31003603",
      "display" : "体重減少率"
    },
    {
      "code" : "31003604",
      "display" : "体重増加率"
    },
    {
      "code" : "31003605",
      "display" : "体重変化率"
    },
    {
      "code" : "31003607",
      "display" : "身長推定値"
    },
    {
      "code" : "31003623",
      "display" : "肘窩上部１０ｃｍ周囲長（右）"
    },
    {
      "code" : "31003624",
      "display" : "肘窩上部１０ｃｍ周囲長（左）"
    },
    {
      "code" : "31003625",
      "display" : "肘窩下部５ｃｍ周囲長（右）"
    },
    {
      "code" : "31003626",
      "display" : "肘窩下部５ｃｍ周囲長（左）"
    },
    {
      "code" : "31003627",
      "display" : "手関節周囲長（右）"
    },
    {
      "code" : "31003628",
      "display" : "手関節周囲長（左）"
    },
    {
      "code" : "31003629",
      "display" : "ＭＰ関節周囲長（右）"
    },
    {
      "code" : "31003630",
      "display" : "ＭＰ関節周囲長（左）"
    },
    {
      "code" : "31003631",
      "display" : "大腿根部周囲長（右）"
    },
    {
      "code" : "31003632",
      "display" : "大腿根部周囲長（左）"
    },
    {
      "code" : "31003633",
      "display" : "膝窩上部１０ｃｍ周囲長（右）"
    },
    {
      "code" : "31003634",
      "display" : "膝窩上部１０ｃｍ周囲長（左）"
    },
    {
      "code" : "31003635",
      "display" : "膝窩下部５ｃｍ周囲長（右）"
    },
    {
      "code" : "31003636",
      "display" : "膝窩下部５ｃｍ周囲長（左）"
    },
    {
      "code" : "31003637",
      "display" : "足関節周囲長（右）"
    },
    {
      "code" : "31003638",
      "display" : "足関節周囲長（左）"
    },
    {
      "code" : "31003639",
      "display" : "足背周囲長（右）"
    },
    {
      "code" : "31003640",
      "display" : "足背周囲長（左）"
    },
    {
      "code" : "31003721",
      "display" : "体重（透析前）",
      "definition" : "体重（透析前）(Kg)"
    },
    {
      "code" : "31003722",
      "display" : "体重（透析前）",
      "definition" : "体重（透析前）(g)"
    },
    {
      "code" : "31003723",
      "display" : "体重（透析後）",
      "definition" : "体重（透析後）(Kg)"
    },
    {
      "code" : "31003724",
      "display" : "体重（透析後）",
      "definition" : "体重（透析後）(g)"
    },
    {
      "code" : "31003725",
      "display" : "目標体重",
      "definition" : "目標体重(Kg)"
    },
    {
      "code" : "31003726",
      "display" : "目標体重",
      "definition" : "目標体重(g)"
    },
    {
      "code" : "31003727",
      "display" : "体重変化量",
      "definition" : "体重変化量(Kg)"
    },
    {
      "code" : "31003728",
      "display" : "体重変化量",
      "definition" : "体重変化量(g)"
    },
    {
      "code" : "31006116",
      "display" : "頭囲"
    },
    {
      "code" : "31006215",
      "display" : "握力（右）"
    },
    {
      "code" : "31006216",
      "display" : "握力（左）"
    },
    {
      "code" : "31006397",
      "display" : "体重（前日差）"
    }
  ]
}

```
