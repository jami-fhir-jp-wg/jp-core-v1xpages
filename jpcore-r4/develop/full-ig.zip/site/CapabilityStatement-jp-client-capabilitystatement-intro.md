この章ではJP Core Clientの期待される機能について説明する。
JP Core Serverによってサポートされる FHIR プロファイル・RESTful操作・検索パラメータの完全なリストを定義する。  
JP Core Clientは個別のユースケースや意味的な要請に応じてこれらのリストを通じて必要なデータにアクセスすることができる。

## RESTful Capabilities by Resource/Profile:

{% include markdown-link-references.md %}