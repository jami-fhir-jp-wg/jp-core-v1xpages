
### Definitions(定義情報)
- [JSON](definitions.json.zip)
- [XML](definitions.xml.zip)

### Examples(サンプルデータ)

- [JSON](examples.json.zip)
- [XML](examples.xml.zip)

### 一覧データ
- [CSV](csvs.zip)
- [Excel](excels.zip)

{% include markdown-link-references.md %}