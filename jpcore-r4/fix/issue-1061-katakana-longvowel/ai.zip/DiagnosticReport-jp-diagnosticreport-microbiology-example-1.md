# JP Core DiagnosticReport_Microbiology Example 一般細菌検査レポート - HL7 FHIR JP Core ImplementationGuide v1.3.0-dev

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **JP Core DiagnosticReport_Microbiology Example 一般細菌検査レポート**

## Example DiagnosticReport: JP Core DiagnosticReport_Microbiology Example 一般細菌検査レポート

## Microbiology studies (微生物検査 )

| | |
| :--- | :--- |
| Subject | 山田 太郎 male, DoB: 1970-01-01 ( id: 00000010) |
| When For | 2021-03-04 08:30:00+09:00 |
| Reported | 2021-03-04 11:45:33+09:00 |
| Identifier: | id: 1234567 (use: USUAL) |

**Report Details**

* Category: Gram stain
  * Code: 白血球
  * Value: 1+
  * Category: 
* Category: 上皮細胞
  * Code: 少数
* Category: グラム陽性球菌（GPC）
  * Code: 1+
* Category: グラム陽性桿菌（GPR）
  * Code: 少数
* Category: Organism panels
  * Code: 培養同定(一般細菌)
  * Value: 
  * Category: Organism
  * Code: α-Streptococcus
  * Value: 1+
  * Category: 
* Category: Corynebacterium spp.
  * Code: 少数
* Category: Staphylococcus aureus (MRSA)
  * Code: 2+
* Category: Streptococcus pneumoniae
  * Code: 1+
* Category: Susceptibility panels
  * Code: Staphylococcus aureus (MRSA)
  * Value: 
  * Category: Susceptibility measurements
  * Code: GM
  * Value: Resistant
* Category: ABK
  * Code: Susceptible
* Category: MINO
  * Code: Resistant
* Category: CLDM
  * Code: Resistant
* Category: LVFX
  * Code: Resistant
* Category: FOM
  * Code: Intermediate
* Category: VCM
  * Code: Susceptible
* Category: Susceptibility panels
  * Code: Streptococcus pneumoniae
  * Value: 
  * Category: Susceptibility measurements
  * Code: PCG
  * Value: Susceptible
* Category: MINO
  * Code: Resistant
* Category: EM
  * Code: Resistant
* Category: CTRX
  * Code: Susceptible
* Category: CFPN-PI
  * Code: Susceptible
* Category: CLDM
  * Code: Resistant
* Category: LVFX
  * Code: Susceptible
* Category: MEPM
  * Code: Susceptible
* Category: VCM
  * Code: Susceptible

本実装ガイドへのご質問・ご指摘については、
[GitHub Issue](https://github.com/jami-fhir-jp-wg/jp-core-v1x/issues)および
[GitHub PullRequest](https://github.com/jami-fhir-jp-wg/jp-core-v1x/pulls)にて受け付けている。

## Resource Content

```json
{
  "resourceType" : "DiagnosticReport",
  "id" : "jp-diagnosticreport-microbiology-example-1",
  "meta" : {
    "profile" : [
      "http://jpfhir.jp/fhir/core/StructureDefinition/JP_DiagnosticReport_Microbiology"
    ]
  },
  "contained" : [
    {
      "resourceType" : "Observation",
      "id" : "gram-strain1",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "gram-stain",
              "display" : "Gram stain"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "http://example.org/abc-hospital/fhir/Observation/localcode",
            "code" : "6A0100000061704Z1",
            "display" : "塗抹鏡検(一般細菌)_喀痰_グラム染色_ユーザー定義1(白血球)"
          }
        ],
        "text" : "白血球"
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "valueString" : "1+"
    },
    {
      "resourceType" : "Observation",
      "id" : "gram-strain2",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "gram-stain",
              "display" : "Gram stain"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "http://example.org/abc-hospital/fhir/Observation/localcode",
            "code" : "6A0100000061704Z2",
            "display" : "塗抹鏡検(一般細菌)_喀痰_グラム染色_ユーザー定義2(上皮細胞)"
          }
        ],
        "text" : "上皮細胞"
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "valueString" : "少数"
    },
    {
      "resourceType" : "Observation",
      "id" : "gram-strain3",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "gram-stain",
              "display" : "Gram stain"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "http://example.org/abc-hospital/fhir/Observation/localcode",
            "code" : "6A0100000061704Z3",
            "display" : "塗抹鏡検(一般細菌)_喀痰_グラム染色_ユーザー定義3(グラム陽性球菌（GPC）)"
          }
        ],
        "text" : "グラム陽性球菌（GPC）"
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "valueString" : "1+"
    },
    {
      "resourceType" : "Observation",
      "id" : "gram-strain4",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "gram-stain",
              "display" : "Gram stain"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "http://example.org/abc-hospital/fhir/Observation/localcode",
            "code" : "6A0100000061704Z4",
            "display" : "塗抹鏡検(一般細菌)_喀痰_グラム染色_ユーザー定義4(グラム陽性桿菌（GPR）)"
          }
        ],
        "text" : "グラム陽性桿菌（GPR）"
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "valueString" : "少数"
    },
    {
      "resourceType" : "Observation",
      "id" : "organism-panels1",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "organism-panels",
              "display" : "Organism panels"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "http://medis.or.jp/CodeSystem/master-JLAC10-17digits",
            "code" : "6B010000006174149",
            "display" : "培養同定(一般細菌)_喀痰_培養検査"
          }
        ],
        "text" : "培養同定(一般細菌)"
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "hasMember" : [
        {
          "reference" : "#organism-id1"
        },
        {
          "reference" : "#susceptibility-panels1"
        }
      ]
    },
    {
      "resourceType" : "Observation",
      "id" : "organism-panels2",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "organism-panels",
              "display" : "Organism panels"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "http://medis.or.jp/CodeSystem/master-JLAC10-17digits",
            "code" : "6B010000006174149",
            "display" : "培養同定(一般細菌)_喀痰_培養検査"
          }
        ],
        "text" : "培養同定(一般細菌)"
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "hasMember" : [
        {
          "reference" : "#organism-id2"
        },
        {
          "reference" : "#susceptibility-panels2"
        }
      ]
    },
    {
      "resourceType" : "Observation",
      "id" : "organism-panels3",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "organism-panels",
              "display" : "Organism panels"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "http://medis.or.jp/CodeSystem/master-JLAC10-17digits",
            "code" : "6B010000006174149",
            "display" : "培養同定(一般細菌)_喀痰_培養検査"
          }
        ],
        "text" : "培養同定(一般細菌)"
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "hasMember" : [
        {
          "reference" : "#organism-id3"
        }
      ]
    },
    {
      "resourceType" : "Observation",
      "id" : "organism-panels4",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "organism-panels",
              "display" : "Organism panels"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "http://medis.or.jp/CodeSystem/master-JLAC10-17digits",
            "code" : "6B010000006174149",
            "display" : "培養同定(一般細菌)_喀痰_培養検査"
          }
        ],
        "text" : "培養同定(一般細菌)"
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "hasMember" : [
        {
          "reference" : "#organism-id4"
        }
      ]
    },
    {
      "resourceType" : "Observation",
      "id" : "organism-id1",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "organism",
              "display" : "Organism"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "urn:oid:1.2.392.100495.10.3.100.5.27.6.1",
            "code" : "1303"
          }
        ],
        "text" : "Staphylococcus aureus (MRSA)"
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "valueString" : "2+"
    },
    {
      "resourceType" : "Observation",
      "id" : "organism-id2",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "organism",
              "display" : "Organism"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "urn:oid:1.2.392.100495.10.3.100.5.27.6.1",
            "code" : "1131"
          }
        ],
        "text" : "Streptococcus pneumoniae"
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "valueString" : "1+"
    },
    {
      "resourceType" : "Observation",
      "id" : "organism-id3",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "organism",
              "display" : "Organism"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "urn:oid:1.2.392.100495.10.3.100.5.27.6.1",
            "code" : "1101"
          }
        ],
        "text" : "α-Streptococcus"
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "valueString" : "1+"
    },
    {
      "resourceType" : "Observation",
      "id" : "organism-id4",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "organism",
              "display" : "Organism"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "urn:oid:1.2.392.100495.10.3.100.5.27.6.1",
            "code" : "6000"
          }
        ],
        "text" : "Corynebacterium sp."
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "valueString" : "少数"
    },
    {
      "resourceType" : "Observation",
      "id" : "susceptibility-panels1",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "susceptibility-panels",
              "display" : "Susceptibility panels"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "urn:oid:1.2.392.100495.10.3.100.5.27.6.1",
            "code" : "1303"
          }
        ],
        "text" : "Staphylococcus aureus (MRSA)"
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "hasMember" : [
        {
          "reference" : "#susceptibility-measurements1-1"
        },
        {
          "reference" : "#susceptibility-measurements1-2"
        },
        {
          "reference" : "#susceptibility-measurements1-3"
        },
        {
          "reference" : "#susceptibility-measurements1-4"
        },
        {
          "reference" : "#susceptibility-measurements1-5"
        },
        {
          "reference" : "#susceptibility-measurements1-6"
        },
        {
          "reference" : "#susceptibility-measurements1-7"
        }
      ]
    },
    {
      "resourceType" : "Observation",
      "id" : "susceptibility-panels2",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "susceptibility-panels",
              "display" : "Susceptibility panels"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "urn:oid:1.2.392.100495.10.3.100.5.27.6.1",
            "code" : "1131"
          }
        ],
        "text" : "Streptococcus pneumoniae"
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "hasMember" : [
        {
          "reference" : "#susceptibility-measurements2-1"
        },
        {
          "reference" : "#susceptibility-measurements2-2"
        },
        {
          "reference" : "#susceptibility-measurements2-3"
        },
        {
          "reference" : "#susceptibility-measurements2-4"
        },
        {
          "reference" : "#susceptibility-measurements2-5"
        },
        {
          "reference" : "#susceptibility-measurements2-6"
        },
        {
          "reference" : "#susceptibility-measurements2-7"
        },
        {
          "reference" : "#susceptibility-measurements2-8"
        },
        {
          "reference" : "#susceptibility-measurements2-9"
        }
      ]
    },
    {
      "resourceType" : "Observation",
      "id" : "susceptibility-measurements1-1",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "susceptibility-measurements",
              "display" : "Susceptibility measurements"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "urn:oid:1.2.392.100495.10.3.100.5.11.5.2",
            "code" : "1821",
            "display" : "GM"
          }
        ]
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "interpretation" : [
        {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
              "code" : "R",
              "display" : "Resistant"
            }
          ]
        }
      ]
    },
    {
      "resourceType" : "Observation",
      "id" : "susceptibility-measurements1-2",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "susceptibility-measurements",
              "display" : "Susceptibility measurements"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "urn:oid:1.2.392.100495.10.3.100.5.11.5.2",
            "code" : "1871",
            "display" : "ABK"
          }
        ]
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "interpretation" : [
        {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
              "code" : "S",
              "display" : "Susceptible"
            }
          ]
        }
      ]
    },
    {
      "resourceType" : "Observation",
      "id" : "susceptibility-measurements1-3",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "susceptibility-measurements",
              "display" : "Susceptibility measurements"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "urn:oid:1.2.392.100495.10.3.100.5.11.5.2",
            "code" : "2121",
            "display" : "MINO"
          }
        ]
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "interpretation" : [
        {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
              "code" : "R",
              "display" : "Resistant"
            }
          ]
        }
      ]
    },
    {
      "resourceType" : "Observation",
      "id" : "susceptibility-measurements1-4",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "susceptibility-measurements",
              "display" : "Susceptibility measurements"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "urn:oid:1.2.392.100495.10.3.100.5.11.5.2",
            "code" : "2006",
            "display" : "CLDM"
          }
        ]
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "interpretation" : [
        {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
              "code" : "R",
              "display" : "Resistant"
            }
          ]
        }
      ]
    },
    {
      "resourceType" : "Observation",
      "id" : "susceptibility-measurements1-5",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "susceptibility-measurements",
              "display" : "Susceptibility measurements"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "urn:oid:1.2.392.100495.10.3.100.5.11.5.2",
            "code" : "2516",
            "display" : "LVFX"
          }
        ]
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "interpretation" : [
        {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
              "code" : "R",
              "display" : "Resistant"
            }
          ]
        }
      ]
    },
    {
      "resourceType" : "Observation",
      "id" : "susceptibility-measurements1-6",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "susceptibility-measurements",
              "display" : "Susceptibility measurements"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "urn:oid:1.2.392.100495.10.3.100.5.11.5.2",
            "code" : "2601",
            "display" : "FOM"
          }
        ]
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "interpretation" : [
        {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
              "code" : "I",
              "display" : "Intermediate"
            }
          ]
        }
      ]
    },
    {
      "resourceType" : "Observation",
      "id" : "susceptibility-measurements1-7",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "susceptibility-measurements",
              "display" : "Susceptibility measurements"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "urn:oid:1.2.392.100495.10.3.100.5.11.5.2",
            "code" : "2301",
            "display" : "VCM"
          }
        ]
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "interpretation" : [
        {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
              "code" : "S",
              "display" : "Susceptible"
            }
          ]
        }
      ]
    },
    {
      "resourceType" : "Observation",
      "id" : "susceptibility-measurements2-1",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "susceptibility-measurements",
              "display" : "Susceptibility measurements"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "urn:oid:1.2.392.100495.10.3.100.5.11.5.2",
            "code" : "1201",
            "display" : "PCG"
          }
        ]
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "interpretation" : [
        {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
              "code" : "S",
              "display" : "Susceptible"
            }
          ]
        }
      ]
    },
    {
      "resourceType" : "Observation",
      "id" : "susceptibility-measurements2-2",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "susceptibility-measurements",
              "display" : "Susceptibility measurements"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "urn:oid:1.2.392.100495.10.3.100.5.11.5.2",
            "code" : "2121",
            "display" : "MINO"
          }
        ]
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "interpretation" : [
        {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
              "code" : "R",
              "display" : "Resistant"
            }
          ]
        }
      ]
    },
    {
      "resourceType" : "Observation",
      "id" : "susceptibility-measurements2-3",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "susceptibility-measurements",
              "display" : "Susceptibility measurements"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "urn:oid:1.2.392.100495.10.3.100.5.11.5.2",
            "code" : "1901",
            "display" : "EM"
          }
        ]
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "interpretation" : [
        {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
              "code" : "R",
              "display" : "Resistant"
            }
          ]
        }
      ]
    },
    {
      "resourceType" : "Observation",
      "id" : "susceptibility-measurements2-4",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "susceptibility-measurements",
              "display" : "Susceptibility measurements"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "urn:oid:1.2.392.100495.10.3.100.5.11.5.2",
            "code" : "1656",
            "display" : "CTRX"
          }
        ]
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "interpretation" : [
        {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
              "code" : "S",
              "display" : "Susceptible"
            }
          ]
        }
      ]
    },
    {
      "resourceType" : "Observation",
      "id" : "susceptibility-measurements2-5",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "susceptibility-measurements",
              "display" : "Susceptibility measurements"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "urn:oid:1.2.392.100495.10.3.100.5.11.5.2",
            "code" : "1596",
            "display" : "CFPN-PI"
          }
        ]
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "interpretation" : [
        {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
              "code" : "S",
              "display" : "Susceptible"
            }
          ]
        }
      ]
    },
    {
      "resourceType" : "Observation",
      "id" : "susceptibility-measurements2-6",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "susceptibility-measurements",
              "display" : "Susceptibility measurements"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "urn:oid:1.2.392.100495.10.3.100.5.11.5.2",
            "code" : "2006",
            "display" : "CLDM"
          }
        ]
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "interpretation" : [
        {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
              "code" : "R",
              "display" : "Resistant"
            }
          ]
        }
      ]
    },
    {
      "resourceType" : "Observation",
      "id" : "susceptibility-measurements2-7",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "susceptibility-measurements",
              "display" : "Susceptibility measurements"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "urn:oid:1.2.392.100495.10.3.100.5.11.5.2",
            "code" : "2516",
            "display" : "LVFX"
          }
        ]
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "interpretation" : [
        {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
              "code" : "S",
              "display" : "Susceptible"
            }
          ]
        }
      ]
    },
    {
      "resourceType" : "Observation",
      "id" : "susceptibility-measurements2-8",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "susceptibility-measurements",
              "display" : "Susceptibility measurements"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "urn:oid:1.2.392.100495.10.3.100.5.11.5.2",
            "code" : "1411",
            "display" : "MEPM"
          }
        ]
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "interpretation" : [
        {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
              "code" : "S",
              "display" : "Susceptible"
            }
          ]
        }
      ]
    },
    {
      "resourceType" : "Observation",
      "id" : "susceptibility-measurements2-9",
      "meta" : {
        "profile" : [
          "http://jpfhir.jp/fhir/core/StructureDefinition/JP_Observation_Microbiology"
        ]
      },
      "status" : "final",
      "category" : [
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_SimpleObservationCategory_CS",
              "code" : "laboratory",
              "display" : "Laboratory"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://loinc.org",
              "code" : "18725-2",
              "display" : "Microbiology studies (set)"
            }
          ]
        },
        {
          "coding" : [
            {
              "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_MicrobiologyCategory_CS",
              "code" : "susceptibility-measurements",
              "display" : "Susceptibility measurements"
            }
          ]
        }
      ],
      "code" : {
        "coding" : [
          {
            "system" : "urn:oid:1.2.392.100495.10.3.100.5.11.5.2",
            "code" : "2301",
            "display" : "VCM"
          }
        ]
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-1"
        }
      ],
      "interpretation" : [
        {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
              "code" : "S",
              "display" : "Susceptible"
            }
          ]
        }
      ]
    },
    {
      "resourceType" : "ServiceRequest",
      "id" : "jp-servicerequest-example-1",
      "status" : "active",
      "intent" : "original-order",
      "code" : {
        "coding" : [
          {
            "system" : "http://example.org/abc-hospital/fhir/ObservationOrder/localcode",
            "code" : "12345678"
          }
        ],
        "text" : "生化学検査"
      },
      "subject" : {
        "reference" : "Patient/jp-patient-example-1"
      },
      "encounter" : {
        "reference" : "Encounter/jp-encounter-example-1"
      },
      "occurrenceDateTime" : "2021-10-19T01:15:00+09:00",
      "requester" : {
        "reference" : "Practitioner/jp-practitioner-example-female-1"
      },
      "performer" : [
        {
          "reference" : "Practitioner/jp-practitioner-example-male-2"
        }
      ]
    }
  ],
  "identifier" : [
    {
      "use" : "usual",
      "system" : "http://example.org/abc-hospital/fhir/mb/reportid",
      "value" : "1234567"
    }
  ],
  "basedOn" : [
    {
      "reference" : "#jp-servicerequest-example-1"
    }
  ],
  "status" : "final",
  "category" : [
    {
      "coding" : [
        {
          "system" : "http://loinc.org",
          "code" : "LP7819-8",
          "display" : "微生物検査"
        }
      ]
    }
  ],
  "code" : {
    "coding" : [
      {
        "system" : "http://jpfhir.jp/fhir/core/CodeSystem/JP_DocumentCodes_CS",
        "code" : "18725-2",
        "display" : "微生物学的検査報告書"
      }
    ]
  },
  "subject" : {
    "reference" : "Patient/jp-patient-example-1"
  },
  "encounter" : {
    "reference" : "Encounter/jp-encounter-example-1"
  },
  "effectiveDateTime" : "2021-03-04T08:30:00+09:00",
  "issued" : "2021-03-04T11:45:33+09:00",
  "performer" : [
    {
      "reference" : "Organization/jp-organization-example-inspection",
      "display" : "株式会社ＡＢＣ検査"
    }
  ],
  "resultsInterpreter" : [
    {
      "reference" : "Practitioner/jp-practitioner-example-female-1",
      "display" : "福岡 花子"
    }
  ],
  "specimen" : [
    {
      "reference" : "Specimen/jp-specimen-example-3",
      "display" : "喀痰"
    }
  ],
  "result" : [
    {
      "reference" : "#gram-strain1"
    },
    {
      "reference" : "#gram-strain2"
    },
    {
      "reference" : "#gram-strain3"
    },
    {
      "reference" : "#gram-strain4"
    },
    {
      "reference" : "#organism-panels1"
    },
    {
      "reference" : "#organism-panels2"
    },
    {
      "reference" : "#organism-panels3"
    },
    {
      "reference" : "#organism-panels4"
    }
  ],
  "presentedForm" : [
    {
      "contentType" : "application/pdf",
      "language" : "ja-JP",
      "data" : "JVBERi0xLjQKJdPr6eEKMSAwIG9iago8PC9DcmVhdG9yIChNb3ppbGxhLzUuMCBcKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NFwpIEFwcGxlV2ViS2l0LzUzNy4zNiBcKEtIVE1MLCBsaWtlIEdlY2tvXCkgQ2hyb21lLzExNC4wLjAuMCBTYWZhcmkvNTM3LjM2KQovUHJvZHVjZXIgKFNraWEvUERGIG0xMTQpCi9DcmVhdGlvbkRhdGUgKEQ6MjAyMzA2MTQwODI2MjQrMDAnMDAnKQovTW9kRGF0ZSAoRDoyMDIzMDYxNDA4MjYyNCswMCcwMCcpPj4KZW5kb2JqCjMgMCBvYmoKPDwvY2EgMQovQk0gL05vcm1hbD4+CmVuZG9iago2IDAgb2JqCjw8L0ZpbHRlciAvRmxhdGVEZWNvZGUKL0xlbmd0aCA0MjE2Pj4gc3RyZWFtCnicvVtbb1y3EX7Xr9jHtkDXvF8AI4C0koo+FOjFQJ+DNAla5ARt2gL9+eVwLuTZ9VKHjJwEskayOTPffMO5UPbZ2Fz/O6ny/2/P3ZfJ6XPWOafTN9vDvx60UedkrTXp1InGlD8VQvAna0I6W6X86advH/76m9OP5Yw5R6ucIu3tq8/rKmbOXplT++XPvztdfeen7x8+/M6evv/3Q7Ft3Slpe9Jg8buHs47Gn/pf4fjNN4uGYlXH3J9Nprhn/WmrktZJnX4oou5FMPcD2DngIzq3VUtVQUaTIIiew/5qMB5PRRFDPeACHAquO5QBYipOgVAIK77oTigGlrza0BKo0aaaRIH0ZVvFkGZ8h0NFUTukAztfJbQWdC9N+0+ebWithsGR/yCQPh3wj3k9FfyACNopoy0hqFK1Z7TrpXkGAkNAexgLBlEl0ml0qLJWYQZGPVbUdMdsvQmAo0rVpjWml6ZxsHcbGcSIRMJRJdJpDWLSdiqf6jHA0Y65wDic5JELppemcbB3GxnEiHjCUSXS6YibuaxyxG075WveAAovueS176VpFOzbRvYwHoyiSqTTEzPaTFUmT9R2x4INhKNK1WawsZemcbB3GxnEiCTCUSXSGWxGNswMjHoK2JBTQUpskBobpMiGpSrLvm1kr2pyilBUiVFQQdPl4AwMKrbdsVQjBziSRC7VyIk0j0PKbZB6G6Tghr7iQsAWup0rJ/bdLlC3c0ljkxMBDMx3u0DdDtWUJudqb69tr3W7sNLt8k23C9LtsvS4Jk37T55ht8vc7TJ3u9B1u7DU7fJNtwvS7bL0uCbNMxAYAtqTbpel24Wu2wENaupCwzFgtDuG+c83AXmH/G/SPA72biODmnocJhP2vZZNeSGboPtcZVPmbIIuhDnUJDAyn02Zsgn1FBLALKVVl015JZtA1VU2Zc4mtAc51KR5BOzbRvY4mxAE5pWwYM0CC65IexZgyUEWnLIU+yaBkWkW4NCG1iwGH8wSHY0FkOdZAFV7FhABSGgPYt+keQTs20b2LMUeQSAfwoIru+U8C3Chdyy4MswSC1jHg+4l5edZgEPIAjYYR5e50uGFBZAXWCiq9iwggipR9XC9NI2AfSMWKBYMAvnw3JtdsvO9uSy/Yd+cXXLYnMtvRWzKTQIb0+0ZDm1kLGJbrmapU1tJoyJOp1HVdJVHFQFIbDDoXpwHQc5tZDBiBhGImlS25VKR53Op6rpKpgoDJDIJOdSJC1wExkEmI2UR0xGaVmyBdmUxDdFcL6aIBaQQLa2jTZpHwt5tZNBSgwbT3LStLKYVx/xi6rW6XkwRB0hea1pHmzSPg73byKCmdRRMo8Q6HXEzv5iCrv1iiihAQouwjjZpHgX7tpE9TesoogCJdXpixqopGJ6o7Y7h2OdoAMQMgLGvSfM42LuNDFpaRzGrfKcT2VrLqtvnDmCCskoeOTpJr2QVnKKskucOL88drBP5Wsqqm+cORFEleeTopGkU7BtllTx3eHnuYJ2IcunxKRRSr9kI/PgUdCYOmuSn1wr2biODmTgA08xLe3zy00senAJdV2wEfnxCi8BBk+ZRsG8b2cvEAaJAXtpTYIAX+gU2oHPs2QilPxAb9T5WNppk9AIbcIrYoB7k6Y5XiXRWnEavsBHNFRuIokpUVXwvTaNg34gNigejqBLpxP7oV/p4Sjd9PMRAfTwl7t5NAjvzfRxObWSQ+ziY5o7uW1YBjvmsqjiusqriAAltQi41aR4He7eRQc4qxIH55VtWxdl1A06BrqusqihAQouQS02aR8G+bWSPswpRYH556eOVjfkH5srG/oEZcYCENuFZuUnzONi7jQxyH0cc2NFRJzzdVjamH5gjrOC7B2ZCUaRY12V4Vm7SPAr2bSN7VZNT1TJKgqKsJcjG9AMzKLt6YEYcIKFNmKWatICDvNvIIEbEMY7sdmxEtcSGvWYjKmHDChtNml7F2Tdiwwob1ggvjQ2QV9iwN2wgjipZYaNJ8zjIO2LDChvWCC8dG3aJjXDDhhU2gnDQJLvEhhU2grARhA3bsWHX2Ai3bFhhIwgHTZrHQd4RG0HYCMKG7dgIS2zkGzaCsJGFgyaFJTaCsJGFjSxshI6NsMZGvmUjCBtZOGjSPA7yjtjIwkYWNkLHRl5hI5kbNjKzkQxz0KSYl9jIzAZpcqpaZl46NvISG6Dsmo3MbKBN4KBJCzjIu40MMhuEo/LS2EhmiQ1/zUYywoYXNppkVtiAU8SGFza8EV4aGyCvsOFv2EAcVfLCRpPmcZB3xIYXNrwRXjo2/BIb6YYNL2wk4aBJfokNL2wkYSMJG75jw6+xkW7Z8MJGEg6aNI+DvCM2krCRhA3SiXvV0v5XX4WvFsCUeAGk52PY+zoRTM2vgHBqY5uRNj96lMZ1sC2BFcz8Eohg9lsggnHtpwOw/HXiPBh2cGObkdY/AoM7YdsEQZ7fBK9+WIALIK+CZBQ2wE6ch8LubWwy0g5IUHAxbOtg5WV+HURe9vsgggGJzMIa2InzYNjBjW1GWgQJDG6HXf1KK/Ur65v6lbh+Zc1Vq0nzONi3jexx/QLLXMm6+pWW6hcou65fiesX2oSq1aQFHOTdRga5fhGO7HZsZL3EhrtmI2thwwkbTdIrbMApYsMJG84IL40NkFfYcDdsII4qOWGjSfM4yDtiwwkbzggvHRtuiY14w4YTNqJw0CS3xIYTNqKwEYUN17Hh1tiIt2w4YUN+9tRJ8zjIO2IjChtR2HAdG0uvV1qpGzrk+ar8JrPQiXnpASvLAxarcgqtMzkdJWtPWFXbNSfyhkVmgYpOXABDDm5sk2lhMJWhxotWSw9ZWpVJcU9M0dSY8VGY6cSl16x6jLlBZZUbHxpNjZz6xRI7PlyzQ4hQrJaRnk5cetdiRGg2CkGICLnqGfJ5iaF0y1BQwlBqtHSiz0sMlWPMUGoMpcYQ6SXIeY2h9BmGKiIUU6OlE+cRsY/MUGoMpcYQI0LQSwxpfctQFobKyMe0dCKYWmEoCUOkzCl0QMjqGUprDIG+G4ayMISWKy2duICIfdzYrDBEiJCsjiGt1xhyNwzBDsAMucZQJ+olhuAYM+QaQy40sjqG4IslhtwtQ4gIRdcY6sR5ROwjM+QaQy40snqG3BpD8ZYh3xiKjZZOdGsMucZQbAzFxpDrGXKLDMXPMOQbQ7HR0onziNhHZig2hmJjiPSq+u8viy4UyvmnTw8f/nj6+PHDHy6/fy7f+uqrp+fLw4dXdzLu9Om7B43/HrQsjydrT5+2h49lFFFKuUv5CKW/+fJhiuzxe1V+pc+P5XP5Hhzw8Gdj+Ujl+5HOJ/j+V6dP/3h4+cPl4eXTlTf6vjfwb0x9hH+4KV5Vt57uazMDbSmdrc+2YXyJ6NeHv/zz6x+Lhsdv/vPfr3/49O3//nP6+Pry+hq9fv2qKDyBxo8qX6IY/qge/Wv5eFGP5vG+O/a+O05du6PU5b4mJ5pKtoWdJl14c8xaoOgDU88Y/cpgvK/as+o7YfCXqCUMn7GfzdnCJWAn8nMj6H5orepD+/TahRZYfgoX9eQz5RXkosOcA0TqFb9vIuagKX9AP+P3dPlzuuSdLnmp4WtFn91exkzCzzVPY6fj3ofDzyOiwpCoUr+ZqeKfe6L7oQlPrnp9xoCq06e/nT4iRO/vm4z3TTI3za72hMVfxSR0cuzi8IRxqb9vSabfUy8kX/rv33c0jWNTyjLFBsFqdQ466hRbKGq07C4k1p9tyfGUWrwiJf4g6fOBmIk/UzFz9PGM39Opi1+Yj5lW46CFRE4aTMpw1i4528cstiyrobncq3q/+u7vv26XUkXTX8qqol60gbP6QFjF45tr5yjEoQtdxqvM19UnbDMutXM2YeGzCdMmqXMOfdaYoti8ju+t7lvHlevpZAqyfW7qc3grMdM5qv1Fjq1u1QOR6tqF+umoT9r7/sG/mCr7KOVBQKVU8k08J+wzvau1aw9dHYXKDVxRoba1Epq9S3VWqLgHiv1AcfBnp4Lp9drMdSLl+lsCkZpFbYUjg+G+QWP1uaRj+IVjG+97ZKM5qzoPLYQ23dfrSmhTfN/A5vvmfImIM7oU7F8ysEbd9yg4ey5xNSs5a/RAb3bn66uALnbNSgtqHc/BGuB3V1U8VRa/Lxo+tmHc64GDZtBAymgdIrv2KKHV6byPbDWoBkbs2Ejm8skrApe9oefujck0hvg8nEz92WAnMIkIeMotR+6pTcn1w+mz3c39lzzw2A/C0AoYO4OD6MtA32CabOCsJn35SY8XmvD40gF76WLxUV3Ss3r1g+ZuBnNmAyfOPD6nshy9DvQNxsEOnGNwwaicn8qHKZSMdsDRbNf0RpruHsuIUUhVr3YwhdnBFNbpzLQCBWfwPllbK0kpMAPdg6Gpi2tUB5PGDi5889UZNxlXO7jjnV6XJK46p8sbcR3stZ3OaD4TV+vfiOuhy9j8fStf7Wi1w79MRt3TULV+pMKpqdaFcRG1owtWDDiu1NAORHF6e3a0h25aohlXK/2inp1W+fJYlnkz0HvoppVOzg8cT8Py5MpqtHsUsH15espQogYvJIeuaPIZnXm1byzybnAtDTRIyB6ffi7pbnBbrQlnE2AEhUfHascagzun5bc2HgssfW3oxYc+u8BL08CHwc3m4VA8eLP+uMGd7hBZczVp0exRZj+V+/3VX7pM9zQ68BhBA1KNdHoj0oN60Pklo1plDqJq2S+zXyv1YHZxg2IhIXXuYOlxg8rQuS5zhe2mrFos8OK5Mo7u3wY8b54rWTOoKs2poLlvVWdSl7G0yvNqD59KTS/OV5s5n2O0rtsBYI0f3thBOZKYZ359gJeGURr7QT3p4LVHq3e8kH5QezrbwXUNga8IXgPeC+hxwY2XGD8oQhy54I8WAD8oJ1I5YzR94PhZJ+yDV5337YWk3nMcx7M9a7dbTkfrnx8UpeZTDosd1h+qLVeYv/QF9YMa1DkloL/4BfWDMuYLCb7unL90ZgzKWOdUSw1FKeGoRfQRU/un1iE7g2pVqso5KHj/CLxS4Ng7aG9hUK/kIaKpe+ONPXTTS2x3YfRzpDAoWg1QNALI4U9uzKCUhEFhElBN5aGEeR3XwjCoXh0MLzYVvOqUz/D3twbDchhUoAbFf0F+BjWqAyY/S4S5DF7N4bV6mHiDMtOApS8IbFBWGrCkBRhOWqXoe7cb6GyGn8GVz4MtOAzKhaBttr4A2kN1IzlBm3E5GVEYj9SOTuWllTh5ouSyyFeNnygHVy0eqhgpSjDbs7TfrQiQqkN8R8pIZ+cdykg8MgRpNVe6fm6vi0emIK34SWR6DIqHxqBr1O80NMdD484Vup8zNcdD48wvzvGheaYPwzsNNPFQYcpKomGpxwz+Ak06Upg6le9wcdOhopTtbP9PR2pQp/bdG0c6NNhkWSpNGhfVdGSgaeq+AKBDA03O/UBjI+0wgxafjgw0Te27JN2hEaYrJfXiZHoI1/AkOFA+Glk65VIR6s0clJg0uukcIF0C844RyqNK0IGIaXJ8zaP73sCI3vfP4zyqDA2aVuk9Btg8KgOCtxl7F/JGpaJDaFNfVBOl94i8UQloYOy7ghmVhw6M/D2n5bE1j6pCQxd+Hro/lf//DwWIk08KZW5kc3RyZWFtCmVuZG9iagoyIDAgb2JqCjw8L1R5cGUgL1BhZ2UKL1Jlc291cmNlcyA8PC9Qcm9jU2V0IFsvUERGIC9UZXh0IC9JbWFnZUIgL0ltYWdlQyAvSW1hZ2VJXQovRXh0R1N0YXRlIDw8L0czIDMgMCBSPj4KL0ZvbnQgPDwvRjQgNCAwIFIKL0Y1IDUgMCBSPj4+PgovTWVkaWFCb3ggWzAgMCA1OTQuOTU5OTYgODQxLjkxOTk4XQovQ29udGVudHMgNiAwIFIKL1N0cnVjdFBhcmVudHMgMAovUGFyZW50IDcgMCBSPj4KZW5kb2JqCjcgMCBvYmoKPDwvVHlwZSAvUGFnZXMKL0NvdW50IDEKL0tpZHMgWzIgMCBSXT4+CmVuZG9iagoxMiAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9Ob25TdHJ1Y3QKL1AgMTEgMCBSCi9LIFs8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDA+Pl0KL0lEIChub2RlMDAwMDAxMTYpPj4KZW5kb2JqCjExIDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL0RpdgovUCAxMCAwIFIKL0sgWzEyIDAgUl0KL0lEIChub2RlMDAwMDAxNzkpPj4KZW5kb2JqCjEzIDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCAxMCAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgMT4+XQovSUQgKG5vZGUwMDAwMDExNyk+PgplbmRvYmoKMTUgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDE0IDAgUgovSyBbPDwvVHlwZSAvTUNSCi9QZyAyIDAgUgovTUNJRCAyPj5dCi9JRCAobm9kZTAwMDAwMTE4KT4+CmVuZG9iagoxNCAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9EaXYKL1AgMTAgMCBSCi9LIFsxNSAwIFJdCi9JRCAobm9kZTAwMDAwMTgwKT4+CmVuZG9iagoxNiAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9Ob25TdHJ1Y3QKL1AgMTAgMCBSCi9LIFs8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDM+Pl0KL0lEIChub2RlMDAwMDAxMTkpPj4KZW5kb2JqCjEwIDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL0gyCi9QIDkgMCBSCi9LIFsxMSAwIFIgMTMgMCBSIDE0IDAgUiAxNiAwIFJdCi9JRCAobm9kZTAwMDAwMTc4KT4+CmVuZG9iagoyMCAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9Ob25TdHJ1Y3QKL1AgMTkgMCBSCi9LIFs8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDQ+Pl0KL0lEIChub2RlMDAwMDAxMjApPj4KZW5kb2JqCjE5IDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCAxOCAwIFIKL0sgWzIwIDAgUl0KL0EgWzw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMTgyKT4+CmVuZG9iagoyMiAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9Ob25TdHJ1Y3QKL1AgMjEgMCBSCi9LIFs8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDU+Pl0KL0lEIChub2RlMDAwMDAxMjEpPj4KZW5kb2JqCjIxIDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCAxOCAwIFIKL0sgWzIyIDAgUl0KL0EgWzw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMTgzKT4+CmVuZG9iagoxOCAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9Ob25TdHJ1Y3QKL1AgMTcgMCBSCi9LIFsxOSAwIFIgMjEgMCBSXQovSUQgKG5vZGUwMDAwMDE4MSk+PgplbmRvYmoKMjUgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDI0IDAgUgovSyBbPDwvVHlwZSAvTUNSCi9QZyAyIDAgUgovTUNJRCA2Pj5dCi9JRCAobm9kZTAwMDAwMTIyKT4+CmVuZG9iagoyNCAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9Ob25TdHJ1Y3QKL1AgMjMgMCBSCi9LIFsyNSAwIFJdCi9BIFs8PC9PIC9UYWJsZQovUm93U3BhbiAxPj4gPDwvTyAvVGFibGUKL0NvbFNwYW4gMT4+XQovSUQgKG5vZGUwMDAwMDE4NSk+PgplbmRvYmoKMjcgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDI2IDAgUgovSyBbPDwvVHlwZSAvTUNSCi9QZyAyIDAgUgovTUNJRCA3Pj5dCi9JRCAobm9kZTAwMDAwMTIzKT4+CmVuZG9iagoyNiAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9Ob25TdHJ1Y3QKL1AgMjMgMCBSCi9LIFsyNyAwIFJdCi9BIFs8PC9PIC9UYWJsZQovUm93U3BhbiAxPj4gPDwvTyAvVGFibGUKL0NvbFNwYW4gMT4+XQovSUQgKG5vZGUwMDAwMDE4Nik+PgplbmRvYmoKMjMgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDE3IDAgUgovSyBbMjQgMCBSIDI2IDAgUl0KL0lEIChub2RlMDAwMDAxODQpPj4KZW5kb2JqCjMwIDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCAyOSAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgOD4+XQovSUQgKG5vZGUwMDAwMDEyNCk+PgplbmRvYmoKMjkgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDI4IDAgUgovSyBbMzAgMCBSXQovQSBbPDwvTyAvVGFibGUKL1Jvd1NwYW4gMT4+IDw8L08gL1RhYmxlCi9Db2xTcGFuIDE+Pl0KL0lEIChub2RlMDAwMDAxODgpPj4KZW5kb2JqCjMyIDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCAzMSAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgOT4+XQovSUQgKG5vZGUwMDAwMDEyNSk+PgplbmRvYmoKMzEgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDI4IDAgUgovSyBbMzIgMCBSXQovQSBbPDwvTyAvVGFibGUKL1Jvd1NwYW4gMT4+IDw8L08gL1RhYmxlCi9Db2xTcGFuIDE+Pl0KL0lEIChub2RlMDAwMDAxODkpPj4KZW5kb2JqCjI4IDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCAxNyAwIFIKL0sgWzI5IDAgUiAzMSAwIFJdCi9JRCAobm9kZTAwMDAwMTg3KT4+CmVuZG9iagozNSAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9Ob25TdHJ1Y3QKL1AgMzQgMCBSCi9LIFs8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDEwPj5dCi9JRCAobm9kZTAwMDAwMTI2KT4+CmVuZG9iagozNCAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9Ob25TdHJ1Y3QKL1AgMzMgMCBSCi9LIFszNSAwIFJdCi9BIFs8PC9PIC9UYWJsZQovUm93U3BhbiAxPj4gPDwvTyAvVGFibGUKL0NvbFNwYW4gMT4+XQovSUQgKG5vZGUwMDAwMDE5MSk+PgplbmRvYmoKMzcgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDM2IDAgUgovSyBbPDwvVHlwZSAvTUNSCi9QZyAyIDAgUgovTUNJRCAxMT4+XQovSUQgKG5vZGUwMDAwMDEyNyk+PgplbmRvYmoKMzYgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDMzIDAgUgovSyBbMzcgMCBSXQovQSBbPDwvTyAvVGFibGUKL1Jvd1NwYW4gMT4+IDw8L08gL1RhYmxlCi9Db2xTcGFuIDE+Pl0KL0lEIChub2RlMDAwMDAxOTIpPj4KZW5kb2JqCjMzIDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCAxNyAwIFIKL0sgWzM0IDAgUiAzNiAwIFJdCi9JRCAobm9kZTAwMDAwMTkwKT4+CmVuZG9iagoxNyAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9Ob25TdHJ1Y3QKL1AgOSAwIFIKL0sgWzE4IDAgUiAyMyAwIFIgMjggMCBSIDMzIDAgUl0KL0lEIChub2RlMDAwMDAxMDcpPj4KZW5kb2JqCjM5IDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCAzOCAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgMTI+Pl0KL0lEIChub2RlMDAwMDAxMjgpPj4KZW5kb2JqCjM4IDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL1AKL1AgOSAwIFIKL0sgWzM5IDAgUl0KL0lEIChub2RlMDAwMDAxOTMpPj4KZW5kb2JqCjQzIDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCA0MiAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgMTM+Pl0KL0lEIChub2RlMDAwMDAxMjkpPj4KZW5kb2JqCjQyIDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL1RICi9QIDQxIDAgUgovSyBbNDMgMCBSXQovQSBbPDwvTyAvVGFibGUKL1Njb3BlIC9Db2x1bW4+PiA8PC9PIC9UYWJsZQovUm93U3BhbiAxPj4gPDwvTyAvVGFibGUKL0NvbFNwYW4gMT4+XQovSUQgKG5vZGUwMDAwMDEwOSk+PgplbmRvYmoKNDUgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDQ0IDAgUgovSyBbPDwvVHlwZSAvTUNSCi9QZyAyIDAgUgovTUNJRCAxND4+XQovSUQgKG5vZGUwMDAwMDAwNCk+PgplbmRvYmoKNDQgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVEgKL1AgNDEgMCBSCi9LIFs0NSAwIFJdCi9BIFs8PC9PIC9UYWJsZQovU2NvcGUgL0NvbHVtbj4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMTEwKT4+CmVuZG9iago0NyAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9Ob25TdHJ1Y3QKL1AgNDYgMCBSCi9LIFs8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDE1Pj5dCi9JRCAobm9kZTAwMDAwMTMwKT4+CmVuZG9iago0NiAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9USAovUCA0MSAwIFIKL0sgWzQ3IDAgUl0KL0EgWzw8L08gL1RhYmxlCi9TY29wZSAvQ29sdW1uPj4gPDwvTyAvVGFibGUKL1Jvd1NwYW4gMT4+IDw8L08gL1RhYmxlCi9Db2xTcGFuIDE+Pl0KL0lEIChub2RlMDAwMDAwMDUpPj4KZW5kb2JqCjQ5IDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCA0OCAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgMTY+Pl0KL0lEIChub2RlMDAwMDAwMDcpPj4KZW5kb2JqCjQ4IDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL1RICi9QIDQxIDAgUgovSyBbNDkgMCBSXQovQSBbPDwvTyAvVGFibGUKL1Njb3BlIC9Db2x1bW4+PiA8PC9PIC9UYWJsZQovUm93U3BhbiAxPj4gPDwvTyAvVGFibGUKL0NvbFNwYW4gMT4+XQovSUQgKG5vZGUwMDAwMDAwNik+PgplbmRvYmoKNTEgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDUwIDAgUgovSyBbPDwvVHlwZSAvTUNSCi9QZyAyIDAgUgovTUNJRCAxNz4+XQovSUQgKG5vZGUwMDAwMDAwOSk+PgplbmRvYmoKNTAgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVEgKL1AgNDEgMCBSCi9LIFs1MSAwIFJdCi9BIFs8PC9PIC9UYWJsZQovU2NvcGUgL0NvbHVtbj4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDA4KT4+CmVuZG9iago1MyAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9Ob25TdHJ1Y3QKL1AgNTIgMCBSCi9LIFs8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDE4Pj5dCi9JRCAobm9kZTAwMDAwMTMxKT4+CmVuZG9iago1MiAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9USAovUCA0MSAwIFIKL0sgWzUzIDAgUl0KL0EgWzw8L08gL1RhYmxlCi9TY29wZSAvQ29sdW1uPj4gPDwvTyAvVGFibGUKL1Jvd1NwYW4gMT4+IDw8L08gL1RhYmxlCi9Db2xTcGFuIDE+Pl0KL0lEIChub2RlMDAwMDAwMTApPj4KZW5kb2JqCjU1IDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCA1NCAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgMTk+Pl0KL0lEIChub2RlMDAwMDAwMTIpPj4KZW5kb2JqCjU0IDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL1RICi9QIDQxIDAgUgovSyBbNTUgMCBSXQovQSBbPDwvTyAvVGFibGUKL1Njb3BlIC9Db2x1bW4+PiA8PC9PIC9UYWJsZQovUm93U3BhbiAxPj4gPDwvTyAvVGFibGUKL0NvbFNwYW4gMT4+XQovSUQgKG5vZGUwMDAwMDAxMSk+PgplbmRvYmoKNTcgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDU2IDAgUgovSyBbPDwvVHlwZSAvTUNSCi9QZyAyIDAgUgovTUNJRCAyMD4+XQovSUQgKG5vZGUwMDAwMDAxNCk+PgplbmRvYmoKNTYgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVEgKL1AgNDEgMCBSCi9LIFs1NyAwIFJdCi9BIFs8PC9PIC9UYWJsZQovU2NvcGUgL0NvbHVtbj4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDEzKT4+CmVuZG9iago1OSAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9Ob25TdHJ1Y3QKL1AgNTggMCBSCi9LIFs8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDIxPj5dCi9JRCAobm9kZTAwMDAwMDE2KT4+CmVuZG9iago1OCAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9USAovUCA0MSAwIFIKL0sgWzU5IDAgUl0KL0EgWzw8L08gL1RhYmxlCi9TY29wZSAvQ29sdW1uPj4gPDwvTyAvVGFibGUKL1Jvd1NwYW4gMT4+IDw8L08gL1RhYmxlCi9Db2xTcGFuIDE+Pl0KL0lEIChub2RlMDAwMDAwMTUpPj4KZW5kb2JqCjQxIDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL1RSCi9QIDQwIDAgUgovSyBbNDIgMCBSIDQ0IDAgUiA0NiAwIFIgNDggMCBSIDUwIDAgUiA1MiAwIFIgNTQgMCBSIDU2IDAgUiA1OCAwIFJdCi9JRCAobm9kZTAwMDAwMTk0KT4+CmVuZG9iago2MiAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9Ob25TdHJ1Y3QKL1AgNjEgMCBSCi9LIFs8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDIyPj4gPDwvVHlwZSAvTUNSCi9QZyAyIDAgUgovTUNJRCAyMz4+XQovSUQgKG5vZGUwMDAwMDAxNyk+PgplbmRvYmoKNjEgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVEQKL1AgNjAgMCBSCi9LIFs2MiAwIFJdCi9BIFs8PC9PIC9UYWJsZQovSGVhZGVycyBbKG5vZGUwMDAwMDEwOSldPj4gPDwvTyAvVGFibGUKL1Jvd1NwYW4gND4+IDw8L08gL1RhYmxlCi9Db2xTcGFuIDE+Pl0KL0lEIChub2RlMDAwMDAxMTEpPj4KZW5kb2JqCjY0IDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCA2MyAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgMjQ+Pl0KL0lEIChub2RlMDAwMDAxMzIpPj4KZW5kb2JqCjYzIDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL1RECi9QIDYwIDAgUgovSyBbNjQgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAxMTApXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMTEyKT4+CmVuZG9iago2NiAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9Ob25TdHJ1Y3QKL1AgNjUgMCBSCi9LIFs8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDI1Pj5dCi9JRCAobm9kZTAwMDAwMTMzKT4+CmVuZG9iago2NSAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCA2MCAwIFIKL0sgWzY2IDAgUl0KL0EgWzw8L08gL1RhYmxlCi9IZWFkZXJzIFsobm9kZTAwMDAwMDA1KV0+PiA8PC9PIC9UYWJsZQovUm93U3BhbiAxPj4gPDwvTyAvVGFibGUKL0NvbFNwYW4gMT4+XQovSUQgKG5vZGUwMDAwMDAxOCk+PgplbmRvYmoKNjAgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVFIKL1AgNDAgMCBSCi9LIFs2MSAwIFIgNjMgMCBSIDY1IDAgUl0KL0lEIChub2RlMDAwMDAxOTUpPj4KZW5kb2JqCjY5IDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCA2OCAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgMjY+Pl0KL0lEIChub2RlMDAwMDAxMzQpPj4KZW5kb2JqCjY4IDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL1RECi9QIDY3IDAgUgovSyBbNjkgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAxMTApXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMTEzKT4+CmVuZG9iago3MSAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9Ob25TdHJ1Y3QKL1AgNzAgMCBSCi9LIFs8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDI3Pj5dCi9JRCAobm9kZTAwMDAwMTM1KT4+CmVuZG9iago3MCAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCA2NyAwIFIKL0sgWzcxIDAgUl0KL0EgWzw8L08gL1RhYmxlCi9IZWFkZXJzIFsobm9kZTAwMDAwMDA1KV0+PiA8PC9PIC9UYWJsZQovUm93U3BhbiAxPj4gPDwvTyAvVGFibGUKL0NvbFNwYW4gMT4+XQovSUQgKG5vZGUwMDAwMDAyMCk+PgplbmRvYmoKNjcgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVFIKL1AgNDAgMCBSCi9LIFs2OCAwIFIgNzAgMCBSXQovSUQgKG5vZGUwMDAwMDE5Nik+PgplbmRvYmoKNzQgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDczIDAgUgovSyBbPDwvVHlwZSAvTUNSCi9QZyAyIDAgUgovTUNJRCAyOD4+IDw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgMjk+PiA8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDMwPj5dCi9JRCAobm9kZTAwMDAwMTM2KT4+CmVuZG9iago3MyAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCA3MiAwIFIKL0sgWzc0IDAgUl0KL0EgWzw8L08gL1RhYmxlCi9IZWFkZXJzIFsobm9kZTAwMDAwMTEwKV0+PiA8PC9PIC9UYWJsZQovUm93U3BhbiAxPj4gPDwvTyAvVGFibGUKL0NvbFNwYW4gMT4+XQovSUQgKG5vZGUwMDAwMDExNCk+PgplbmRvYmoKNzYgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDc1IDAgUgovSyBbPDwvVHlwZSAvTUNSCi9QZyAyIDAgUgovTUNJRCAzMT4+XQovSUQgKG5vZGUwMDAwMDAyMik+PgplbmRvYmoKNzUgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVEQKL1AgNzIgMCBSCi9LIFs3NiAwIFJdCi9BIFs8PC9PIC9UYWJsZQovSGVhZGVycyBbKG5vZGUwMDAwMDAwNSldPj4gPDwvTyAvVGFibGUKL1Jvd1NwYW4gMT4+IDw8L08gL1RhYmxlCi9Db2xTcGFuIDE+Pl0KL0lEIChub2RlMDAwMDAwMjEpPj4KZW5kb2JqCjcyIDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL1RSCi9QIDQwIDAgUgovSyBbNzMgMCBSIDc1IDAgUl0KL0lEIChub2RlMDAwMDAxOTcpPj4KZW5kb2JqCjc5IDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCA3OCAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgMzI+PiA8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDMzPj4gPDwvVHlwZSAvTUNSCi9QZyAyIDAgUgovTUNJRCAzND4+XQovSUQgKG5vZGUwMDAwMDEzNyk+PgplbmRvYmoKNzggMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVEQKL1AgNzcgMCBSCi9LIFs3OSAwIFJdCi9BIFs8PC9PIC9UYWJsZQovSGVhZGVycyBbKG5vZGUwMDAwMDExMCldPj4gPDwvTyAvVGFibGUKL1Jvd1NwYW4gMT4+IDw8L08gL1RhYmxlCi9Db2xTcGFuIDE+Pl0KL0lEIChub2RlMDAwMDAwMjQpPj4KZW5kb2JqCjgxIDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCA4MCAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgMzU+Pl0KL0lEIChub2RlMDAwMDAwMjYpPj4KZW5kb2JqCjgwIDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL1RECi9QIDc3IDAgUgovSyBbODEgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMDUpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDI1KT4+CmVuZG9iago3NyAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9UUgovUCA0MCAwIFIKL0sgWzc4IDAgUiA4MCAwIFJdCi9JRCAobm9kZTAwMDAwMDIzKT4+CmVuZG9iago4NCAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9Ob25TdHJ1Y3QKL1AgODMgMCBSCi9LIFs8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDM2Pj4gPDwvVHlwZSAvTUNSCi9QZyAyIDAgUgovTUNJRCAzNz4+XQovSUQgKG5vZGUwMDAwMDAyOCk+PgplbmRvYmoKODMgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVEQKL1AgODIgMCBSCi9LIFs4NCAwIFJdCi9BIFs8PC9PIC9UYWJsZQovSGVhZGVycyBbKG5vZGUwMDAwMDEwOSldPj4gPDwvTyAvVGFibGUKL1Jvd1NwYW4gNDg+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMTE1KT4+CmVuZG9iago4NiAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9Ob25TdHJ1Y3QKL1AgODUgMCBSCi9LIFs8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDM4Pj4gPDwvVHlwZSAvTUNSCi9QZyAyIDAgUgovTUNJRCAzOT4+IDw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgNDA+Pl0KL0lEIChub2RlMDAwMDAwMzApPj4KZW5kb2JqCjg1IDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL1RECi9QIDgyIDAgUgovSyBbODYgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAxMTApXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDQ4Pj4gPDwvTyAvVGFibGUKL0NvbFNwYW4gMT4+XQovSUQgKG5vZGUwMDAwMDAyOSk+PgplbmRvYmoKODggMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDg3IDAgUgovSyBbPDwvVHlwZSAvTUNSCi9QZyAyIDAgUgovTUNJRCA0MT4+XQovSUQgKG5vZGUwMDAwMDAzMyk+PgplbmRvYmoKODcgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVEQKL1AgODIgMCBSCi9LIFs4OCAwIFJdCi9BIFs8PC9PIC9UYWJsZQovSGVhZGVycyBbKG5vZGUwMDAwMDAwNildPj4gPDwvTyAvVGFibGUKL1Jvd1NwYW4gND4+IDw8L08gL1RhYmxlCi9Db2xTcGFuIDE+Pl0KL0lEIChub2RlMDAwMDAwMzIpPj4KZW5kb2JqCjkwIDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCA4OSAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgNDI+Pl0KL0lEIChub2RlMDAwMDAxMzgpPj4KZW5kb2JqCjg5IDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL1RECi9QIDgyIDAgUgovSyBbOTAgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMDgpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDM0KT4+CmVuZG9iago5MiAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9Ob25TdHJ1Y3QKL1AgOTEgMCBSCi9LIFs8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDQzPj5dCi9JRCAobm9kZTAwMDAwMTM5KT4+CmVuZG9iago5MSAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCA4MiAwIFIKL0sgWzkyIDAgUl0KL0EgWzw8L08gL1RhYmxlCi9IZWFkZXJzIFsobm9kZTAwMDAwMDEwKV0+PiA8PC9PIC9UYWJsZQovUm93U3BhbiAxPj4gPDwvTyAvVGFibGUKL0NvbFNwYW4gMT4+XQovSUQgKG5vZGUwMDAwMDAzNSk+PgplbmRvYmoKODIgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVFIKL1AgNDAgMCBSCi9LIFs4MyAwIFIgODUgMCBSIDg3IDAgUiA4OSAwIFIgOTEgMCBSXQovSUQgKG5vZGUwMDAwMDAyNyk+PgplbmRvYmoKOTUgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDk0IDAgUgovSyBbPDwvVHlwZSAvTUNSCi9QZyAyIDAgUgovTUNJRCA0ND4+IDw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgNDU+Pl0KL0lEIChub2RlMDAwMDAxNDApPj4KZW5kb2JqCjk0IDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL1RECi9QIDkzIDAgUgovSyBbOTUgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMDgpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDM4KT4+CmVuZG9iago5NyAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9Ob25TdHJ1Y3QKL1AgOTYgMCBSCi9LIFs8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDQ2Pj5dCi9JRCAobm9kZTAwMDAwMTQxKT4+CmVuZG9iago5NiAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCA5MyAwIFIKL0sgWzk3IDAgUl0KL0EgWzw8L08gL1RhYmxlCi9IZWFkZXJzIFsobm9kZTAwMDAwMDEwKV0+PiA8PC9PIC9UYWJsZQovUm93U3BhbiAxPj4gPDwvTyAvVGFibGUKL0NvbFNwYW4gMT4+XQovSUQgKG5vZGUwMDAwMDAzOSk+PgplbmRvYmoKOTMgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVFIKL1AgNDAgMCBSCi9LIFs5NCAwIFIgOTYgMCBSXQovSUQgKG5vZGUwMDAwMDAzNyk+PgplbmRvYmoKMTAwIDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCA5OSAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgNDc+PiA8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDQ4Pj5dCi9JRCAobm9kZTAwMDAwMTQyKT4+CmVuZG9iago5OSAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCA5OCAwIFIKL0sgWzEwMCAwIFJdCi9BIFs8PC9PIC9UYWJsZQovSGVhZGVycyBbKG5vZGUwMDAwMDAwOCldPj4gPDwvTyAvVGFibGUKL1Jvd1NwYW4gMT4+IDw8L08gL1RhYmxlCi9Db2xTcGFuIDE+Pl0KL0lEIChub2RlMDAwMDAwNDEpPj4KZW5kb2JqCjEwMiAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9Ob25TdHJ1Y3QKL1AgMTAxIDAgUgovSyBbPDwvVHlwZSAvTUNSCi9QZyAyIDAgUgovTUNJRCA0OT4+XQovSUQgKG5vZGUwMDAwMDA0Myk+PgplbmRvYmoKMTAxIDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL1RECi9QIDk4IDAgUgovSyBbMTAyIDAgUl0KL0EgWzw8L08gL1RhYmxlCi9IZWFkZXJzIFsobm9kZTAwMDAwMDEwKV0+PiA8PC9PIC9UYWJsZQovUm93U3BhbiAxPj4gPDwvTyAvVGFibGUKL0NvbFNwYW4gMT4+XQovSUQgKG5vZGUwMDAwMDA0Mik+PgplbmRvYmoKOTggMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVFIKL1AgNDAgMCBSCi9LIFs5OSAwIFIgMTAxIDAgUl0KL0lEIChub2RlMDAwMDAwNDApPj4KZW5kb2JqCjEwNSAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9Ob25TdHJ1Y3QKL1AgMTA0IDAgUgovSyBbPDwvVHlwZSAvTUNSCi9QZyAyIDAgUgovTUNJRCA1MD4+IDw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgNTE+Pl0KL0lEIChub2RlMDAwMDAxNDMpPj4KZW5kb2JqCjEwNCAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCAxMDMgMCBSCi9LIFsxMDUgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMDgpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDQ1KT4+CmVuZG9iagoxMDcgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDEwNiAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgNTI+Pl0KL0lEIChub2RlMDAwMDAxNDQpPj4KZW5kb2JqCjEwNiAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCAxMDMgMCBSCi9LIFsxMDcgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMTApXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDQ2KT4+CmVuZG9iagoxMDMgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVFIKL1AgNDAgMCBSCi9LIFsxMDQgMCBSIDEwNiAwIFJdCi9JRCAobm9kZTAwMDAwMDQ0KT4+CmVuZG9iagoxMTAgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDEwOSAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgNTM+PiA8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDU0Pj5dCi9JRCAobm9kZTAwMDAwMDQ5KT4+CmVuZG9iagoxMDkgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVEQKL1AgMTA4IDAgUgovSyBbMTEwIDAgUl0KL0EgWzw8L08gL1RhYmxlCi9IZWFkZXJzIFsobm9kZTAwMDAwMDA2KV0+PiA8PC9PIC9UYWJsZQovUm93U3BhbiA3Pj4gPDwvTyAvVGFibGUKL0NvbFNwYW4gMT4+XQovSUQgKG5vZGUwMDAwMDA0OCk+PgplbmRvYmoKMTEyIDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCAxMTEgMCBSCi9LIFs8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDU1Pj4gPDwvVHlwZSAvTUNSCi9QZyAyIDAgUgovTUNJRCA1Nj4+XQovSUQgKG5vZGUwMDAwMDA1MCk+PgplbmRvYmoKMTExIDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL1RECi9QIDEwOCAwIFIKL0sgWzExMiAwIFJdCi9BIFs8PC9PIC9UYWJsZQovSGVhZGVycyBbKG5vZGUwMDAwMDAwOCldPj4gPDwvTyAvVGFibGUKL1Jvd1NwYW4gNz4+IDw8L08gL1RhYmxlCi9Db2xTcGFuIDE+Pl0KL0lEIChub2RlMDAwMDAwMDIpPj4KZW5kb2JqCjExNCAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9Ob25TdHJ1Y3QKL1AgMTEzIDAgUgovSyBbPDwvVHlwZSAvTUNSCi9QZyAyIDAgUgovTUNJRCA1Nz4+IDw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgNTg+Pl0KL0lEIChub2RlMDAwMDAwNTMpPj4KZW5kb2JqCjExMyAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCAxMDggMCBSCi9LIFsxMTQgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMTEpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDc+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDUyKT4+CmVuZG9iagoxMTYgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDExNSAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgNTk+Pl0KL0lEIChub2RlMDAwMDAxNDUpPj4KZW5kb2JqCjExNSAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCAxMDggMCBSCi9LIFsxMTYgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMTMpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDU0KT4+CmVuZG9iagoxMTggMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDExNyAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgNjA+Pl0KL0lEIChub2RlMDAwMDAxNDYpPj4KZW5kb2JqCjExNyAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCAxMDggMCBSCi9LIFsxMTggMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMTUpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDU1KT4+CmVuZG9iagoxMDggMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVFIKL1AgNDAgMCBSCi9LIFsxMDkgMCBSIDExMSAwIFIgMTEzIDAgUiAxMTUgMCBSIDExNyAwIFJdCi9JRCAobm9kZTAwMDAwMDQ3KT4+CmVuZG9iagoxMjEgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDEyMCAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgNjE+Pl0KL0lEIChub2RlMDAwMDAxNDcpPj4KZW5kb2JqCjEyMCAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCAxMTkgMCBSCi9LIFsxMjEgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMTMpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDU3KT4+CmVuZG9iagoxMjMgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDEyMiAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgNjI+Pl0KL0lEIChub2RlMDAwMDAxNDgpPj4KZW5kb2JqCjEyMiAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCAxMTkgMCBSCi9LIFsxMjMgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMTUpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDU4KT4+CmVuZG9iagoxMTkgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVFIKL1AgNDAgMCBSCi9LIFsxMjAgMCBSIDEyMiAwIFJdCi9JRCAobm9kZTAwMDAwMDU2KT4+CmVuZG9iagoxMjYgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDEyNSAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgNjM+Pl0KL0lEIChub2RlMDAwMDAxNDkpPj4KZW5kb2JqCjEyNSAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCAxMjQgMCBSCi9LIFsxMjYgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMTMpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDYwKT4+CmVuZG9iagoxMjggMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDEyNyAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgNjQ+Pl0KL0lEIChub2RlMDAwMDAxNTApPj4KZW5kb2JqCjEyNyAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCAxMjQgMCBSCi9LIFsxMjggMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMTUpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDYxKT4+CmVuZG9iagoxMjQgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVFIKL1AgNDAgMCBSCi9LIFsxMjUgMCBSIDEyNyAwIFJdCi9JRCAobm9kZTAwMDAwMDU5KT4+CmVuZG9iagoxMzEgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDEzMCAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgNjU+Pl0KL0lEIChub2RlMDAwMDAxNTEpPj4KZW5kb2JqCjEzMCAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCAxMjkgMCBSCi9LIFsxMzEgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMTMpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDYzKT4+CmVuZG9iagoxMzMgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDEzMiAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgNjY+Pl0KL0lEIChub2RlMDAwMDAxNTIpPj4KZW5kb2JqCjEzMiAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCAxMjkgMCBSCi9LIFsxMzMgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMTUpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDY0KT4+CmVuZG9iagoxMjkgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVFIKL1AgNDAgMCBSCi9LIFsxMzAgMCBSIDEzMiAwIFJdCi9JRCAobm9kZTAwMDAwMDYyKT4+CmVuZG9iagoxMzYgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDEzNSAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgNjc+Pl0KL0lEIChub2RlMDAwMDAxNTMpPj4KZW5kb2JqCjEzNSAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCAxMzQgMCBSCi9LIFsxMzYgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMTMpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDY2KT4+CmVuZG9iagoxMzggMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDEzNyAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgNjg+Pl0KL0lEIChub2RlMDAwMDAxNTQpPj4KZW5kb2JqCjEzNyAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCAxMzQgMCBSCi9LIFsxMzggMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMTUpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDY3KT4+CmVuZG9iagoxMzQgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVFIKL1AgNDAgMCBSCi9LIFsxMzUgMCBSIDEzNyAwIFJdCi9JRCAobm9kZTAwMDAwMDY1KT4+CmVuZG9iagoxNDEgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDE0MCAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgNjk+Pl0KL0lEIChub2RlMDAwMDAxNTUpPj4KZW5kb2JqCjE0MCAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCAxMzkgMCBSCi9LIFsxNDEgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMTMpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDY5KT4+CmVuZG9iagoxNDMgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDE0MiAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgNzA+Pl0KL0lEIChub2RlMDAwMDAxNTYpPj4KZW5kb2JqCjE0MiAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCAxMzkgMCBSCi9LIFsxNDMgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMTUpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDcwKT4+CmVuZG9iagoxMzkgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVFIKL1AgNDAgMCBSCi9LIFsxNDAgMCBSIDE0MiAwIFJdCi9JRCAobm9kZTAwMDAwMDY4KT4+CmVuZG9iagoxNDYgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDE0NSAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgNzE+Pl0KL0lEIChub2RlMDAwMDAxNTcpPj4KZW5kb2JqCjE0NSAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCAxNDQgMCBSCi9LIFsxNDYgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMTMpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDcyKT4+CmVuZG9iagoxNDggMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDE0NyAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgNzI+Pl0KL0lEIChub2RlMDAwMDAxNTgpPj4KZW5kb2JqCjE0NyAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCAxNDQgMCBSCi9LIFsxNDggMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMTUpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDczKT4+CmVuZG9iagoxNDQgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVFIKL1AgNDAgMCBSCi9LIFsxNDUgMCBSIDE0NyAwIFJdCi9JRCAobm9kZTAwMDAwMDcxKT4+CmVuZG9iagoxNTEgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDE1MCAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgNzM+PiA8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDc0Pj5dCi9JRCAobm9kZTAwMDAwMTU5KT4+CmVuZG9iagoxNTAgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVEQKL1AgMTQ5IDAgUgovSyBbMTUxIDAgUl0KL0EgWzw8L08gL1RhYmxlCi9IZWFkZXJzIFsobm9kZTAwMDAwMDA2KV0+PiA8PC9PIC9UYWJsZQovUm93U3BhbiA5Pj4gPDwvTyAvVGFibGUKL0NvbFNwYW4gMT4+XQovSUQgKG5vZGUwMDAwMDA3NSk+PgplbmRvYmoKMTUzIDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCAxNTIgMCBSCi9LIFs8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDc1Pj4gPDwvVHlwZSAvTUNSCi9QZyAyIDAgUgovTUNJRCA3Nj4+XQovSUQgKG5vZGUwMDAwMDA3Nyk+PgplbmRvYmoKMTUyIDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL1RECi9QIDE0OSAwIFIKL0sgWzE1MyAwIFJdCi9BIFs8PC9PIC9UYWJsZQovSGVhZGVycyBbKG5vZGUwMDAwMDAwOCldPj4gPDwvTyAvVGFibGUKL1Jvd1NwYW4gOT4+IDw8L08gL1RhYmxlCi9Db2xTcGFuIDE+Pl0KL0lEIChub2RlMDAwMDAwNzYpPj4KZW5kb2JqCjE1NSAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9Ob25TdHJ1Y3QKL1AgMTU0IDAgUgovSyBbPDwvVHlwZSAvTUNSCi9QZyAyIDAgUgovTUNJRCA3Nz4+IDw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgNzg+Pl0KL0lEIChub2RlMDAwMDAxNjApPj4KZW5kb2JqCjE1NCAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCAxNDkgMCBSCi9LIFsxNTUgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMTEpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDk+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDc5KT4+CmVuZG9iagoxNTcgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDE1NiAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgNzk+Pl0KL0lEIChub2RlMDAwMDAxNjEpPj4KZW5kb2JqCjE1NiAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCAxNDkgMCBSCi9LIFsxNTcgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMTMpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDgwKT4+CmVuZG9iagoxNTkgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDE1OCAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgODA+Pl0KL0lEIChub2RlMDAwMDAxNjIpPj4KZW5kb2JqCjE1OCAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCAxNDkgMCBSCi9LIFsxNTkgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMTUpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDgxKT4+CmVuZG9iagoxNDkgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVFIKL1AgNDAgMCBSCi9LIFsxNTAgMCBSIDE1MiAwIFIgMTU0IDAgUiAxNTYgMCBSIDE1OCAwIFJdCi9JRCAobm9kZTAwMDAwMDc0KT4+CmVuZG9iagoxNjIgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDE2MSAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgODE+Pl0KL0lEIChub2RlMDAwMDAxNjMpPj4KZW5kb2JqCjE2MSAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCAxNjAgMCBSCi9LIFsxNjIgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMTMpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDgzKT4+CmVuZG9iagoxNjQgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDE2MyAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgODI+Pl0KL0lEIChub2RlMDAwMDAxNjQpPj4KZW5kb2JqCjE2MyAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCAxNjAgMCBSCi9LIFsxNjQgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMTUpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDg0KT4+CmVuZG9iagoxNjAgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVFIKL1AgNDAgMCBSCi9LIFsxNjEgMCBSIDE2MyAwIFJdCi9JRCAobm9kZTAwMDAwMDgyKT4+CmVuZG9iagoxNjcgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDE2NiAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgODM+Pl0KL0lEIChub2RlMDAwMDAxNjUpPj4KZW5kb2JqCjE2NiAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCAxNjUgMCBSCi9LIFsxNjcgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMTMpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDg2KT4+CmVuZG9iagoxNjkgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDE2OCAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgODQ+Pl0KL0lEIChub2RlMDAwMDAxNjYpPj4KZW5kb2JqCjE2OCAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCAxNjUgMCBSCi9LIFsxNjkgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMTUpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDg3KT4+CmVuZG9iagoxNjUgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVFIKL1AgNDAgMCBSCi9LIFsxNjYgMCBSIDE2OCAwIFJdCi9JRCAobm9kZTAwMDAwMDg1KT4+CmVuZG9iagoxNzIgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDE3MSAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgODU+Pl0KL0lEIChub2RlMDAwMDAxNjcpPj4KZW5kb2JqCjE3MSAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCAxNzAgMCBSCi9LIFsxNzIgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMTMpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDg5KT4+CmVuZG9iagoxNzQgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDE3MyAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgODY+Pl0KL0lEIChub2RlMDAwMDAxNjgpPj4KZW5kb2JqCjE3MyAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9URAovUCAxNzAgMCBSCi9LIFsxNzQgMCBSXQovQSBbPDwvTyAvVGFibGUKL0hlYWRlcnMgWyhub2RlMDAwMDAwMTUpXT4+IDw8L08gL1RhYmxlCi9Sb3dTcGFuIDE+PiA8PC9PIC9UYWJsZQovQ29sU3BhbiAxPj5dCi9JRCAobm9kZTAwMDAwMDkwKT4+CmVuZG9iagoxNzAgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVFIKL1AgNDAgMCBSCi9LIFsxNzEgMCBSIDE3MyAwIFJdCi9JRCAobm9kZTAwMDAwMDg4KT4+CmVuZG9iagoxNzcgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvTm9uU3RydWN0Ci9QIDE3NiAwIFIKL0sgWzw8L1R5cGUgL01DUgovUGcgMiAwIFIKL01DSUQgODc+PiA8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDg4Pj5dCi9JRCAobm9kZTAwMDAwMTY5KT4+CmVuZG9iagoxNzYgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVEQKL1AgMTc1IDAgUgovSyBbMTc3IDAgUl0KL0EgWzw8L08gL1RhYmxlCi9IZWFkZXJzIFsobm9kZTAwMDAwMDEzKV0+PiA8PC9PIC9UYWJsZQovUm93U3BhbiAxPj4gPDwvTyAvVGFibGUKL0NvbFNwYW4gMT4+XQovSUQgKG5vZGUwMDAwMDA5Mik+PgplbmRvYmoKMTc5IDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCAxNzggMCBSCi9LIFs8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDg5Pj5dCi9JRCAobm9kZTAwMDAwMDk0KT4+CmVuZG9iagoxNzggMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVEQKL1AgMTc1IDAgUgovSyBbMTc5IDAgUl0KL0EgWzw8L08gL1RhYmxlCi9IZWFkZXJzIFsobm9kZTAwMDAwMDE1KV0+PiA8PC9PIC9UYWJsZQovUm93U3BhbiAxPj4gPDwvTyAvVGFibGUKL0NvbFNwYW4gMT4+XQovSUQgKG5vZGUwMDAwMDA5Myk+PgplbmRvYmoKMTc1IDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL1RSCi9QIDQwIDAgUgovSyBbMTc2IDAgUiAxNzggMCBSXQovSUQgKG5vZGUwMDAwMDA5MSk+PgplbmRvYmoKMTgyIDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCAxODEgMCBSCi9LIFs8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDkwPj5dCi9JRCAobm9kZTAwMDAwMTcwKT4+CmVuZG9iagoxODEgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVEQKL1AgMTgwIDAgUgovSyBbMTgyIDAgUl0KL0EgWzw8L08gL1RhYmxlCi9IZWFkZXJzIFsobm9kZTAwMDAwMDEzKV0+PiA8PC9PIC9UYWJsZQovUm93U3BhbiAxPj4gPDwvTyAvVGFibGUKL0NvbFNwYW4gMT4+XQovSUQgKG5vZGUwMDAwMDA5Nik+PgplbmRvYmoKMTg0IDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCAxODMgMCBSCi9LIFs8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDkxPj5dCi9JRCAobm9kZTAwMDAwMTcxKT4+CmVuZG9iagoxODMgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVEQKL1AgMTgwIDAgUgovSyBbMTg0IDAgUl0KL0EgWzw8L08gL1RhYmxlCi9IZWFkZXJzIFsobm9kZTAwMDAwMDE1KV0+PiA8PC9PIC9UYWJsZQovUm93U3BhbiAxPj4gPDwvTyAvVGFibGUKL0NvbFNwYW4gMT4+XQovSUQgKG5vZGUwMDAwMDA5Nyk+PgplbmRvYmoKMTgwIDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL1RSCi9QIDQwIDAgUgovSyBbMTgxIDAgUiAxODMgMCBSXQovSUQgKG5vZGUwMDAwMDA5NSk+PgplbmRvYmoKMTg3IDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCAxODYgMCBSCi9LIFs8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDkyPj5dCi9JRCAobm9kZTAwMDAwMTcyKT4+CmVuZG9iagoxODYgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVEQKL1AgMTg1IDAgUgovSyBbMTg3IDAgUl0KL0EgWzw8L08gL1RhYmxlCi9IZWFkZXJzIFsobm9kZTAwMDAwMDEzKV0+PiA8PC9PIC9UYWJsZQovUm93U3BhbiAxPj4gPDwvTyAvVGFibGUKL0NvbFNwYW4gMT4+XQovSUQgKG5vZGUwMDAwMDA5OSk+PgplbmRvYmoKMTg5IDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCAxODggMCBSCi9LIFs8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDkzPj5dCi9JRCAobm9kZTAwMDAwMTczKT4+CmVuZG9iagoxODggMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVEQKL1AgMTg1IDAgUgovSyBbMTg5IDAgUl0KL0EgWzw8L08gL1RhYmxlCi9IZWFkZXJzIFsobm9kZTAwMDAwMDE1KV0+PiA8PC9PIC9UYWJsZQovUm93U3BhbiAxPj4gPDwvTyAvVGFibGUKL0NvbFNwYW4gMT4+XQovSUQgKG5vZGUwMDAwMDEwMCk+PgplbmRvYmoKMTg1IDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL1RSCi9QIDQwIDAgUgovSyBbMTg2IDAgUiAxODggMCBSXQovSUQgKG5vZGUwMDAwMDA5OCk+PgplbmRvYmoKMTkyIDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCAxOTEgMCBSCi9LIFs8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDk0Pj5dCi9JRCAobm9kZTAwMDAwMTc0KT4+CmVuZG9iagoxOTEgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVEQKL1AgMTkwIDAgUgovSyBbMTkyIDAgUl0KL0EgWzw8L08gL1RhYmxlCi9IZWFkZXJzIFsobm9kZTAwMDAwMDEzKV0+PiA8PC9PIC9UYWJsZQovUm93U3BhbiAxPj4gPDwvTyAvVGFibGUKL0NvbFNwYW4gMT4+XQovSUQgKG5vZGUwMDAwMDEwMik+PgplbmRvYmoKMTk0IDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCAxOTMgMCBSCi9LIFs8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDk1Pj5dCi9JRCAobm9kZTAwMDAwMTc1KT4+CmVuZG9iagoxOTMgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVEQKL1AgMTkwIDAgUgovSyBbMTk0IDAgUl0KL0EgWzw8L08gL1RhYmxlCi9IZWFkZXJzIFsobm9kZTAwMDAwMDE1KV0+PiA8PC9PIC9UYWJsZQovUm93U3BhbiAxPj4gPDwvTyAvVGFibGUKL0NvbFNwYW4gMT4+XQovSUQgKG5vZGUwMDAwMDEwMyk+PgplbmRvYmoKMTkwIDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL1RSCi9QIDQwIDAgUgovSyBbMTkxIDAgUiAxOTMgMCBSXQovSUQgKG5vZGUwMDAwMDEwMSk+PgplbmRvYmoKMTk3IDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCAxOTYgMCBSCi9LIFs8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDk2Pj5dCi9JRCAobm9kZTAwMDAwMTc2KT4+CmVuZG9iagoxOTYgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVEQKL1AgMTk1IDAgUgovSyBbMTk3IDAgUl0KL0EgWzw8L08gL1RhYmxlCi9IZWFkZXJzIFsobm9kZTAwMDAwMDEzKV0+PiA8PC9PIC9UYWJsZQovUm93U3BhbiAxPj4gPDwvTyAvVGFibGUKL0NvbFNwYW4gMT4+XQovSUQgKG5vZGUwMDAwMDEwNSk+PgplbmRvYmoKMTk5IDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL05vblN0cnVjdAovUCAxOTggMCBSCi9LIFs8PC9UeXBlIC9NQ1IKL1BnIDIgMCBSCi9NQ0lEIDk3Pj5dCi9JRCAobm9kZTAwMDAwMTc3KT4+CmVuZG9iagoxOTggMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVEQKL1AgMTk1IDAgUgovSyBbMTk5IDAgUl0KL0EgWzw8L08gL1RhYmxlCi9IZWFkZXJzIFsobm9kZTAwMDAwMDE1KV0+PiA8PC9PIC9UYWJsZQovUm93U3BhbiAxPj4gPDwvTyAvVGFibGUKL0NvbFNwYW4gMT4+XQovSUQgKG5vZGUwMDAwMDEwNik+PgplbmRvYmoKMTk1IDAgb2JqCjw8L1R5cGUgL1N0cnVjdEVsZW0KL1MgL1RSCi9QIDQwIDAgUgovSyBbMTk2IDAgUiAxOTggMCBSXQovSUQgKG5vZGUwMDAwMDEwNCk+PgplbmRvYmoKNDAgMCBvYmoKPDwvVHlwZSAvU3RydWN0RWxlbQovUyAvVGFibGUKL1AgOSAwIFIKL0sgWzQxIDAgUiA2MCAwIFIgNjcgMCBSIDcyIDAgUiA3NyAwIFIgODIgMCBSIDkzIDAgUiA5OCAwIFIgMTAzIDAgUiAxMDggMCBSIDExOSAwIFIgMTI0IDAgUiAxMjkgMCBSIDEzNCAwIFIgMTM5IDAgUiAxNDQgMCBSIDE0OSAwIFIgMTYwIDAgUiAxNjUgMCBSIDE3MCAwIFIgMTc1IDAgUiAxODAgMCBSIDE4NSAwIFIgMTkwIDAgUiAxOTUgMCBSXQovSUQgKG5vZGUwMDAwMDEwOCk+PgplbmRvYmoKOSAwIG9iago8PC9UeXBlIC9TdHJ1Y3RFbGVtCi9TIC9Eb2N1bWVudAovTGFuZyAoamEtSlApCi9QIDggMCBSCi9LIFsxMCAwIFIgMTcgMCBSIDM4IDAgUiA0MCAwIFJdCi9JRCAobm9kZTAwMDAwMDAxKT4+CmVuZG9iagoyMDAgMCBvYmoKWzEyIDAgUiAxMyAwIFIgMTUgMCBSIDE2IDAgUiAyMCAwIFIgMjIgMCBSIDI1IDAgUiAyNyAwIFIgMzAgMCBSIDMyIDAgUiAzNSAwIFIgMzcgMCBSIDM5IDAgUiA0MyAwIFIgNDUgMCBSIDQ3IDAgUiA0OSAwIFIgNTEgMCBSIDUzIDAgUiA1NSAwIFIgNTcgMCBSIDU5IDAgUiA2MiAwIFIgNjIgMCBSIDY0IDAgUiA2NiAwIFIgNjkgMCBSIDcxIDAgUiA3NCAwIFIgNzQgMCBSIDc0IDAgUiA3NiAwIFIgNzkgMCBSIDc5IDAgUiA3OSAwIFIgODEgMCBSIDg0IDAgUiA4NCAwIFIgODYgMCBSIDg2IDAgUiA4NiAwIFIgODggMCBSIDkwIDAgUiA5MiAwIFIgOTUgMCBSIDk1IDAgUiA5NyAwIFIgMTAwIDAgUiAxMDAgMCBSIDEwMiAwIFIgMTA1IDAgUiAxMDUgMCBSIDEwNyAwIFIgMTEwIDAgUiAxMTAgMCBSIDExMiAwIFIgMTEyIDAgUiAxMTQgMCBSIDExNCAwIFIgMTE2IDAgUiAxMTggMCBSIDEyMSAwIFIgMTIzIDAgUiAxMjYgMCBSIDEyOCAwIFIgMTMxIDAgUiAxMzMgMCBSIDEzNiAwIFIgMTM4IDAgUiAxNDEgMCBSIDE0MyAwIFIgMTQ2IDAgUiAxNDggMCBSIDE1MSAwIFIgMTUxIDAgUiAxNTMgMCBSIDE1MyAwIFIgMTU1IDAgUiAxNTUgMCBSIDE1NyAwIFIgMTU5IDAgUiAxNjIgMCBSIDE2NCAwIFIgMTY3IDAgUiAxNjkgMCBSIDE3MiAwIFIgMTc0IDAgUiAxNzcgMCBSIDE3NyAwIFIgMTc5IDAgUiAxODIgMCBSIDE4NCAwIFIgMTg3IDAgUiAxODkgMCBSIDE5MiAwIFIgMTk0IDAgUiAxOTcgMCBSIDE5OSAwIFJdCmVuZG9iagoyMDEgMCBvYmoKPDwvVHlwZSAvUGFyZW50VHJlZQovTnVtcyBbMCAyMDAgMCBSXT4+CmVuZG9iagoyMDIgMCBvYmoKPDwvTGltaXRzIFsobm9kZTAwMDAwMDAxKSAobm9kZTAwMDAwMTk3KV0KL05hbWVzIFsobm9kZTAwMDAwMDAxKSA5IDAgUiAobm9kZTAwMDAwMDAyKSAxMTEgMCBSIChub2RlMDAwMDAwMDQpIDQ1IDAgUiAobm9kZTAwMDAwMDA1KSA0NiAwIFIgKG5vZGUwMDAwMDAwNikgNDggMCBSIChub2RlMDAwMDAwMDcpIDQ5IDAgUiAobm9kZTAwMDAwMDA4KSA1MCAwIFIgKG5vZGUwMDAwMDAwOSkgNTEgMCBSIChub2RlMDAwMDAwMTApIDUyIDAgUiAobm9kZTAwMDAwMDExKSA1NCAwIFIgKG5vZGUwMDAwMDAxMikgNTUgMCBSIChub2RlMDAwMDAwMTMpIDU2IDAgUiAobm9kZTAwMDAwMDE0KSA1NyAwIFIgKG5vZGUwMDAwMDAxNSkgNTggMCBSIChub2RlMDAwMDAwMTYpIDU5IDAgUiAobm9kZTAwMDAwMDE3KSA2MiAwIFIgKG5vZGUwMDAwMDAxOCkgNjUgMCBSIChub2RlMDAwMDAwMjApIDcwIDAgUiAobm9kZTAwMDAwMDIxKSA3NSAwIFIgKG5vZGUwMDAwMDAyMikgNzYgMCBSIChub2RlMDAwMDAwMjMpIDc3IDAgUiAobm9kZTAwMDAwMDI0KSA3OCAwIFIgKG5vZGUwMDAwMDAyNSkgODAgMCBSIChub2RlMDAwMDAwMjYpIDgxIDAgUiAobm9kZTAwMDAwMDI3KSA4MiAwIFIgKG5vZGUwMDAwMDAyOCkgODQgMCBSIChub2RlMDAwMDAwMjkpIDg1IDAgUiAobm9kZTAwMDAwMDMwKSA4NiAwIFIgKG5vZGUwMDAwMDAzMikgODcgMCBSIChub2RlMDAwMDAwMzMpIDg4IDAgUiAobm9kZTAwMDAwMDM0KSA4OSAwIFIgKG5vZGUwMDAwMDAzNSkgOTEgMCBSIChub2RlMDAwMDAwMzcpIDkzIDAgUiAobm9kZTAwMDAwMDM4KSA5NCAwIFIgKG5vZGUwMDAwMDAzOSkgOTYgMCBSIChub2RlMDAwMDAwNDApIDk4IDAgUiAobm9kZTAwMDAwMDQxKSA5OSAwIFIgKG5vZGUwMDAwMDA0MikgMTAxIDAgUiAobm9kZTAwMDAwMDQzKSAxMDIgMCBSIChub2RlMDAwMDAwNDQpIDEwMyAwIFIgKG5vZGUwMDAwMDA0NSkgMTA0IDAgUiAobm9kZTAwMDAwMDQ2KSAxMDYgMCBSIChub2RlMDAwMDAwNDcpIDEwOCAwIFIgKG5vZGUwMDAwMDA0OCkgMTA5IDAgUiAobm9kZTAwMDAwMDQ5KSAxMTAgMCBSIChub2RlMDAwMDAwNTApIDExMiAwIFIgKG5vZGUwMDAwMDA1MikgMTEzIDAgUiAobm9kZTAwMDAwMDUzKSAxMTQgMCBSIChub2RlMDAwMDAwNTQpIDExNSAwIFIgKG5vZGUwMDAwMDA1NSkgMTE3IDAgUiAobm9kZTAwMDAwMDU2KSAxMTkgMCBSIChub2RlMDAwMDAwNTcpIDEyMCAwIFIgKG5vZGUwMDAwMDA1OCkgMTIyIDAgUiAobm9kZTAwMDAwMDU5KSAxMjQgMCBSIChub2RlMDAwMDAwNjApIDEyNSAwIFIgKG5vZGUwMDAwMDA2MSkgMTI3IDAgUiAobm9kZTAwMDAwMDYyKSAxMjkgMCBSIChub2RlMDAwMDAwNjMpIDEzMCAwIFIgKG5vZGUwMDAwMDA2NCkgMTMyIDAgUiAobm9kZTAwMDAwMDY1KSAxMzQgMCBSIChub2RlMDAwMDAwNjYpIDEzNSAwIFIgKG5vZGUwMDAwMDA2NykgMTM3IDAgUiAobm9kZTAwMDAwMDY4KSAxMzkgMCBSIChub2RlMDAwMDAwNjkpIDE0MCAwIFIgKG5vZGUwMDAwMDA3MCkgMTQyIDAgUiAobm9kZTAwMDAwMDcxKSAxNDQgMCBSIChub2RlMDAwMDAwNzIpIDE0NSAwIFIgKG5vZGUwMDAwMDA3MykgMTQ3IDAgUiAobm9kZTAwMDAwMDc0KSAxNDkgMCBSIChub2RlMDAwMDAwNzUpIDE1MCAwIFIgKG5vZGUwMDAwMDA3NikgMTUyIDAgUiAobm9kZTAwMDAwMDc3KSAxNTMgMCBSIChub2RlMDAwMDAwNzkpIDE1NCAwIFIgKG5vZGUwMDAwMDA4MCkgMTU2IDAgUiAobm9kZTAwMDAwMDgxKSAxNTggMCBSIChub2RlMDAwMDAwODIpIDE2MCAwIFIgKG5vZGUwMDAwMDA4MykgMTYxIDAgUiAobm9kZTAwMDAwMDg0KSAxNjMgMCBSIChub2RlMDAwMDAwODUpIDE2NSAwIFIgKG5vZGUwMDAwMDA4NikgMTY2IDAgUiAobm9kZTAwMDAwMDg3KSAxNjggMCBSIChub2RlMDAwMDAwODgpIDE3MCAwIFIgKG5vZGUwMDAwMDA4OSkgMTcxIDAgUiAobm9kZTAwMDAwMDkwKSAxNzMgMCBSIChub2RlMDAwMDAwOTEpIDE3NSAwIFIgKG5vZGUwMDAwMDA5MikgMTc2IDAgUiAobm9kZTAwMDAwMDkzKSAxNzggMCBSIChub2RlMDAwMDAwOTQpIDE3OSAwIFIgKG5vZGUwMDAwMDA5NSkgMTgwIDAgUiAobm9kZTAwMDAwMDk2KSAxODEgMCBSIChub2RlMDAwMDAwOTcpIDE4MyAwIFIgKG5vZGUwMDAwMDA5OCkgMTg1IDAgUiAobm9kZTAwMDAwMDk5KSAxODYgMCBSIChub2RlMDAwMDAxMDApIDE4OCAwIFIgKG5vZGUwMDAwMDEwMSkgMTkwIDAgUiAobm9kZTAwMDAwMTAyKSAxOTEgMCBSIChub2RlMDAwMDAxMDMpIDE5MyAwIFIgKG5vZGUwMDAwMDEwNCkgMTk1IDAgUiAobm9kZTAwMDAwMTA1KSAxOTYgMCBSIChub2RlMDAwMDAxMDYpIDE5OCAwIFIgKG5vZGUwMDAwMDEwNykgMTcgMCBSIChub2RlMDAwMDAxMDgpIDQwIDAgUiAobm9kZTAwMDAwMTA5KSA0MiAwIFIgKG5vZGUwMDAwMDExMCkgNDQgMCBSIChub2RlMDAwMDAxMTEpIDYxIDAgUiAobm9kZTAwMDAwMTEyKSA2MyAwIFIgKG5vZGUwMDAwMDExMykgNjggMCBSIChub2RlMDAwMDAxMTQpIDczIDAgUiAobm9kZTAwMDAwMTE1KSA4MyAwIFIgKG5vZGUwMDAwMDExNikgMTIgMCBSIChub2RlMDAwMDAxMTcpIDEzIDAgUiAobm9kZTAwMDAwMTE4KSAxNSAwIFIgKG5vZGUwMDAwMDExOSkgMTYgMCBSIChub2RlMDAwMDAxMjApIDIwIDAgUiAobm9kZTAwMDAwMTIxKSAyMiAwIFIgKG5vZGUwMDAwMDEyMikgMjUgMCBSIChub2RlMDAwMDAxMjMpIDI3IDAgUiAobm9kZTAwMDAwMTI0KSAzMCAwIFIgKG5vZGUwMDAwMDEyNSkgMzIgMCBSIChub2RlMDAwMDAxMjYpIDM1IDAgUiAobm9kZTAwMDAwMTI3KSAzNyAwIFIgKG5vZGUwMDAwMDEyOCkgMzkgMCBSIChub2RlMDAwMDAxMjkpIDQzIDAgUiAobm9kZTAwMDAwMTMwKSA0NyAwIFIgKG5vZGUwMDAwMDEzMSkgNTMgMCBSIChub2RlMDAwMDAxMzIpIDY0IDAgUiAobm9kZTAwMDAwMTMzKSA2NiAwIFIgKG5vZGUwMDAwMDEzNCkgNjkgMCBSIChub2RlMDAwMDAxMzUpIDcxIDAgUiAobm9kZTAwMDAwMTM2KSA3NCAwIFIgKG5vZGUwMDAwMDEzNykgNzkgMCBSIChub2RlMDAwMDAxMzgpIDkwIDAgUiAobm9kZTAwMDAwMTM5KSA5MiAwIFIgKG5vZGUwMDAwMDE0MCkgOTUgMCBSIChub2RlMDAwMDAxNDEpIDk3IDAgUiAobm9kZTAwMDAwMTQyKSAxMDAgMCBSIChub2RlMDAwMDAxNDMpIDEwNSAwIFIgKG5vZGUwMDAwMDE0NCkgMTA3IDAgUiAobm9kZTAwMDAwMTQ1KSAxMTYgMCBSIChub2RlMDAwMDAxNDYpIDExOCAwIFIgKG5vZGUwMDAwMDE0NykgMTIxIDAgUiAobm9kZTAwMDAwMTQ4KSAxMjMgMCBSIChub2RlMDAwMDAxNDkpIDEyNiAwIFIgKG5vZGUwMDAwMDE1MCkgMTI4IDAgUiAobm9kZTAwMDAwMTUxKSAxMzEgMCBSIChub2RlMDAwMDAxNTIpIDEzMyAwIFIgKG5vZGUwMDAwMDE1MykgMTM2IDAgUiAobm9kZTAwMDAwMTU0KSAxMzggMCBSIChub2RlMDAwMDAxNTUpIDE0MSAwIFIgKG5vZGUwMDAwMDE1NikgMTQzIDAgUiAobm9kZTAwMDAwMTU3KSAxNDYgMCBSIChub2RlMDAwMDAxNTgpIDE0OCAwIFIgKG5vZGUwMDAwMDE1OSkgMTUxIDAgUiAobm9kZTAwMDAwMTYwKSAxNTUgMCBSIChub2RlMDAwMDAxNjEpIDE1NyAwIFIgKG5vZGUwMDAwMDE2MikgMTU5IDAgUiAobm9kZTAwMDAwMTYzKSAxNjIgMCBSIChub2RlMDAwMDAxNjQpIDE2NCAwIFIgKG5vZGUwMDAwMDE2NSkgMTY3IDAgUiAobm9kZTAwMDAwMTY2KSAxNjkgMCBSIChub2RlMDAwMDAxNjcpIDE3MiAwIFIgKG5vZGUwMDAwMDE2OCkgMTc0IDAgUiAobm9kZTAwMDAwMTY5KSAxNzcgMCBSIChub2RlMDAwMDAxNzApIDE4MiAwIFIgKG5vZGUwMDAwMDE3MSkgMTg0IDAgUiAobm9kZTAwMDAwMTcyKSAxODcgMCBSIChub2RlMDAwMDAxNzMpIDE4OSAwIFIgKG5vZGUwMDAwMDE3NCkgMTkyIDAgUiAobm9kZTAwMDAwMTc1KSAxOTQgMCBSIChub2RlMDAwMDAxNzYpIDE5NyAwIFIgKG5vZGUwMDAwMDE3NykgMTk5IDAgUiAobm9kZTAwMDAwMTc4KSAxMCAwIFIgKG5vZGUwMDAwMDE3OSkgMTEgMCBSIChub2RlMDAwMDAxODApIDE0IDAgUiAobm9kZTAwMDAwMTgxKSAxOCAwIFIgKG5vZGUwMDAwMDE4MikgMTkgMCBSIChub2RlMDAwMDAxODMpIDIxIDAgUiAobm9kZTAwMDAwMTg0KSAyMyAwIFIgKG5vZGUwMDAwMDE4NSkgMjQgMCBSIChub2RlMDAwMDAxODYpIDI2IDAgUiAobm9kZTAwMDAwMTg3KSAyOCAwIFIgKG5vZGUwMDAwMDE4OCkgMjkgMCBSIChub2RlMDAwMDAxODkpIDMxIDAgUiAobm9kZTAwMDAwMTkwKSAzMyAwIFIgKG5vZGUwMDAwMDE5MSkgMzQgMCBSIChub2RlMDAwMDAxOTIpIDM2IDAgUiAobm9kZTAwMDAwMTkzKSAzOCAwIFIgKG5vZGUwMDAwMDE5NCkgNDEgMCBSIChub2RlMDAwMDAxOTUpIDYwIDAgUiAobm9kZTAwMDAwMTk2KSA2NyAwIFIgKG5vZGUwMDAwMDE5NykgNzIgMCBSXT4+CmVuZG9iagoyMDMgMCBvYmoKPDwvS2lkcyBbMjAyIDAgUl0+PgplbmRvYmoKOCAwIG9iago8PC9UeXBlIC9TdHJ1Y3RUcmVlUm9vdAovSyA5IDAgUgovUGFyZW50VHJlZU5leHRLZXkgMQovUGFyZW50VHJlZSAyMDEgMCBSCi9JRFRyZWUgMjAzIDAgUj4+CmVuZG9iagoyMDQgMCBvYmoKPDwvVHlwZSAvQ2F0YWxvZwovUGFnZXMgNyAwIFIKL01hcmtJbmZvIDw8L1R5cGUgL01hcmtJbmZvCi9NYXJrZWQgdHJ1ZT4+Ci9TdHJ1Y3RUcmVlUm9vdCA4IDAgUj4+CmVuZG9iagoyMDUgMCBvYmoKPDwvTGVuZ3RoMSA0OTIzNgovRmlsdGVyIC9GbGF0ZURlY29kZQovTGVuZ3RoIDg2Mzk+PiBzdHJlYW0KeJztfAl4lNXV8Dn3fWdJZjJbMpNlgMxksgADDGRISCSSyQohAiEEmoBIQoIERAlERVS2EpZGVAQJCFqoRbRY4SWgDotKFRGloEXR1uUTpKitRCmtfAjkzX/uO0MMaP38+vT/ffo/77lz77n33O3cs907JAQQACxUiACjxvjSR5cOSQLAD4laXXtrTUP/X9Z8BcByqP1O7Z23u16Y/OrdNLgCQGO7uWHqrevfT5UBrAMBDC9OrWlsgDjw0HwjX3XqjLk3V9f1PgLQ7R8Atufqp9TUmU/OZ9S/mfoz64lg+Yv9ArVvpHZy/a2337VljVEDcMOjANkfzphZW3O67YvVAL7f0hpnb625qyH6smE0je9G41231dw6JbYivQeAYCFafsPMxts7MuFmqnN+XQ2zpzT4+vc1AUTUA+hev5P2i37Moqf+hXy/O2m/C9A9CLD0Lr4fIAgQSckEuo4OMFMbTHPYO/AsjAItMLCAD6rp9ON0l2kkH61Ah5/v+T1A8/X3XL6HRCFdcF0caynllK5gmsMpEVMvkjyNn7evvzjWuC4079oxoF0I984ZP2SSOedrl0Gv9GxnG8Zw/KeRcVsvuC7fYynVr6CxEcRpCATddrYPNKDXrNf4admUEBY2QZAd0wMz6EVBI4pM5GP1XfYcMcblAkp3JOq0HVqRTiEsqWaw8eP36PRLNae4dIFP4DtxKcQo8uBYhP2E+1C/CEYqe0EhlMAIKIdxMAWmwjSYAQ1wB8yFTb7aSdumXprWbfa0OxJJ3nzNnlDQObomPPo2mP3d0R2nfiDVvl+37dDjvl/lrz3/8FPXyvx/BB2M56cRI6heB03hOtJp7grXGZ29IVwX6KyF4boIDugXrmvIExzhupZqJFQ6/zTlLDOhL+RTOYPW51KZDY3UM5NO6oJMWiED+l812tU5egTRaok6k2bMJKu7Ha6j3u8f++2cb3t/Q/3ptPoAyFbmXbuai+Q/kygNSllDlBBf/agnj1abQbicaFOhnvoaldYUwvwMd1JZRyNBmwoGig+nIBHWKyVokJchEJdSvYG85qTiO52lPKnj62+VwOexqR0nNV9CDBvYcUbYQ7YFHWd+SHHyNv09oZo+nLlhw2/JIj+FP1JtK9UossAeZZAELf9sJeQx0Py/tBs+bwKW43AsUOp56MeeYfoIDGBml4EXoA1OwCGQibN34TB8DV/AKfgQ9sKL8Ebnaumd41/qssdYnMHc7BM8x0q/w8BZSoD9ifeX6Xy/gftgGVnwO3ARzsBa+G/UdF1HKScLW2hskPZ9SCEHlfIFktNZpSbBU7Cbxolwjnj9EL6hld6C9+EgPAdP0JhPiPYuHMAyzKWTZ9GJ/wL/BcdgFzyC8f97Cf4g5EExlEIZjCUPnUS2No0ss5G8ch78nM65gk7QAhtgE/G1FbYTB7vpVK+QlI8QP+8RnyfpBF8Qz1+TPDpQxAg0XTPu37gyRmMcdsckTMM+OAAzcTDZQBHJaJTmDMUG0KyHeKWMu/qQZLOK3Do+C5Udq6j8nKy7F/cPGg/ynm9HUzuaDetoE8ohmsa1/ThBXuUfz8Jp+INCbg13b6DTPg7H4Z5/usBZnIFFP26vroAVWECy8Cj1PMxBb2c9G12wqnNcLMlPS95xjqzpBEn4HFyk9knym5fhr9+zsNRlj0aSsQcvwmU4/51xb3DvwnS0wNuwnPQ6D5bALKpz25auHooOpUxQGnPgeYojd8OicOdTZCMhWAlbyBaA+O1NurCyZLAK0PEVWMlP9pAXfUL9dK48E1vOltHN4WVLWBPdDl7WRG0RvB372bJWjyd7t1KJdmS/wO5ic+jm8LI57M5W5g0E2Z07o+3ZA/MGstGAeIpN4OvgJyHMfKyXsl4fwrQe8xLm9N6EtYR7sRR603jxb6yv0t+XeZT+ZMK8ncTcynw3tfmuHpbSak+05Dnw7+CizPA91k+Z0ZNWMlNcTiPMR6YSJnrHCZayM6Vn9rg8AxEQXuclW8yW0lXKj7e0NdapHG9pq8mcndeb3cMSlJ3vJszXcYbb8YQ5xwkshl4xXmZl/A3mZRZmUvrNYRxFmJZmJsbfHbQ/nmuNi8/OW0ExMUaZERfGsWHsIMzPaCfMd4gmTCvg0/ga2PEpPEjlE/gqlY/jASo34itUPoovU/kI/o7KFtxP5Wp8icqV+CLY2UK2CMxsPlsAJnYvm0evxlvYfNrNQOVgyqWU91K+RFlD1IUwgfJ9lC9RFtm9uBo6IBGfw+fBhEEqzVRvoXjgxT24l2j7qDRjK+6k+i4qzbgNt1NdotJMPG7CX4GR+FuPGwi34FpcR3g1PoxrCK/Eh3CVQl/dGpdozsuj/XIpj6L8MWURNuJKqq0kDT9NY5+BKJLEWtxK+Ala+0nCj9NamyEKfPg0Wd4+yME9lIOUn6O8i3IrZYnyNspPU36K8hOUH6e8kfIjlFsor6a8MlCe8/EJR2y3d45Tcc+9Duc998b/4RjV75xDxa0NVMyYScUttzmct9y2YHbC7XfE2LtNnU7FzdOomFIf45xSv2RWQnyj4+6CePdcymSnN+I4xSMmhPH4MK4K48ow/hmOU/yJkNmanTedrtJRSkdFGI/BcgWXU5sMC0eHcVkYj8KRSv9IvIEbIl3rIXwDlij00jAeTpiPH4b5SntoGBeHcVEYF4ZxQRjn0iMhjkxiCOF4wteHcU4YDw7j6wh3I5wdxllhPAgzA6O6JcK7lndZ4MWyF9nnn4L34U/xm/PgvUD5vyl/Tfn8Bo237Yzg/fgL/ILQma8E79+/Au85yoF/WG3ZX34ler86K3jPrhW9LyBDVLgjCyDxdewNNzEwgLr7/wkX/gk3rmfeRylvWC94H1kvete3CN6ah9D70CrBu5ryw6tE7yqiBVEMnFiD3l+uZd41LaJ3HeGWtYJ30QL0zpuv8c5vErzLl6B3GeUlTehd3CR6XU1pPbOdg+xxmXZ7ht020G72243p9ogBdm1/u+CzQz97apqpZ5q5t9fUx2tO8piSPeYeiSZXotlssRojIg1GrU5vFESNkcKSscmMTRFoEAoFVigcFpgBJsDTIAym2+4+en8dhkugdWL3qDhdQpTdEhtlE2OiDL1RyMEMJ/bJ6Z3TMyc1JzknKceV0yPHmROXY8+x5ZhzInK0OUIO5JT5K1CylUJpRb4UjYTH5Et+b2lQcJVL6d5SKaJsQuUOxAeqiCqx5UGECklcHmSEbAXjJ1QGMZ53L3HuJnGDVFq95P4qr7e7VFc6plJa2L1KSueVld2roFRKHy05Pfnea6GxsVFBt1Nq7ELf0TO1SOpdVCP1Kaou7DoBr1Tg2pVu79oKNxq9V636T0GKk3Lp9NeSr92DL6gwfRVtNwXE54qCuKeoJoj7Qvw2Nt4eZPcWBdnComk1VHoKg2x+0TTerqaa56ozfXuoqzYPn+jqzTpbOyK4isrK80slfTnlsglSgocah6iRSQ2jJ5+u/MDYSTdNvHHC+KqK8hE3lA4vGTa0uCA/L5A75PqcwddlZw3KzBjoTx/Q39evbx9v714901JTkj1Jbldij+7dnAnxcbEOe0y0zWoxm6KMhsgIvU6rEQWG0AfjpLiCyqLpUnxBNW1V6LG4JOPIsyN8Eticbo/V5fdV9Q2PkjReCaJLpZiyyh0QyKqStN5rh4yUhBTLOTdNHuF0FUliCn08w2vqpJ7llW6P5V1nZ38VzZESCirdbqfEUuhTQl30GV7jqpMsZUR3O0OUEgnKKnkOdnySRUTIcldRWV4p9bjSrKr6PibpK0TH/mvYHInNlh3G+IJCCWJ2gPETCex82NkseorlSD3JPVIsVFNWA5+EMeckjJbQPoJYvnoLPu1E1vfIoKhuuqeobhpJtK76W5meDUnU7Wp2NZdXWv1UVZgmRY+u3GGILPAUTIkkAigE2BFpIIqBE2iJhh1oHIJKhRmLrtvBQB9F4rNxdot4ni4F7qumiqeQ5EY90d/2BDv2r+jaBTTtSi06VAsxIWkLJF2ICdc0KVAjwX2uHX32N68IWmBytddY56mrubFSEmpowA4QUorqK6RupWXjiURbUa6ud3F1FyoFV56rqN7VTG0+tppKTyFX+lX0uvop1dxMsNpTSH0RBZXL3PudFJYqlxVJVq8URcOi7v6zU2guipvm4s3m5mUuaROx26XXzUsygjhivbnIQ7vRYkXT87lKfJ1qU6yxpE5RTuC+Gpe0cPL0kO3VrLhi/+5mi2Q87ybtkH5opjIxLMq66umc5ek1/JhF013N901RjrpCORrZq6toeiHPfCJZP4yl2eMri+o9Rd9uSAenipBy7Vy3W4r38onNzUWcxZo64j7EMnV8yz/3CacXiZ8CKVChIKhQdEA7BmoKq8Kk8IDxfBrvqS6sqnKH9E5DJV3KMk0/j6uZr6hLkWK8FvcB6tvft09peWVRoVM5vcQKKq9vi3O2Ub20rJOMcTSm2dfmDMmodIyndHTICuqvFNUVIQdmnZqnoeHxyqpH4pxHqF7sKa5ubi72uIqbq5trgh0LJ3tcFk/zDqOxuaGo2qV4PhJ9z31OqXhFlWSprsfrSMnc3oopQEaPnsDVU+yqrwkFi1yPO8vptlZdGVP2z7rDfkYWT3bP/azZcoZ4M1JEcrqKeXgJUlRwSpYs7qbEydhK8oNaxWaVgvyDLkXm5J4iVKUUTRsTFhBZY9hgeNwbHabSIm4396H7ggGYTA1p4ejKUNsFk52tEPB5SXfVvGf/lR77WN6z8EpP5/RqD+kqjl/KP2jTXe252eqxubJ9ivyVcFsn7a+gM17IkvRZYXVHF1QKThauMafAa5FeCl85UqxXmchlQlGy2eJxveWRLF5JU1C535lT5bJYKbwhjRnm5V5DUfQtz+vIYyfEWCTMkdDB6UCxVAnpQmwWdXYaj6uouTpsXV2PFb4A6uq//2w0xuKh4zlD4602Dz/h75WQFo7UKcXcl5zu0IjhVZKJx2PJdEYpiF9nQaWLog9562il4ipy1XNlS67qQiUMVDm7koMdJ6oLedgjlvkQZ9isqQyJ9mpb+/EWvpAsfNGKqnqybinQm07gyqBtFW+pqAxLKcsZ9iK+Vwk/ytX9nVK8Mua70i2tuKrVZV2lL6vT8SsqpWLvlXVC7aFeZ9fmsGu6S650U3SY57yb3xIM8nd4cPnoHQFcPmZ85W4LgGt5RWUrQ1ZQnV+1I5n6Kne76HmjUBmnciJvuHgDSpFWa2V6ZbxzdwBgodIrKgSlXUvvWYWmv0JDqKXHrUKzXKExookhWkChhR4NLu59zdUe8kiKg5XgxCpuVVyDLMUV7OigQHaEAqBb0qbcSJniXIS3ykWGNZzGDeW5mshDpYW1Ndw2ueUIPKSW1FZJ+s4FaUiJFEErRIRXoBHFyhwejGlSLdlPjUepEpnsdWGVVOXlm1ZO4wu4XPQsGea5TtKmhtbUpPKNfFXNNk+6EtW1KVJkyjKOIog3HpsUipOatFlVyHF0RuK81kNdtdUukooItWMqyTlS+SfSGaJMoctVTJ2i5EhnuBNCRm2IipQi+vErQ6fUDf1oQfroqqpCzCutZeEBtLdFMhBHqV1EGZ5A0qGuEs4LfZYRq3zo7/gyo4NQ7rmL3IIzrayko24pKqWkhmJAaL6BKJ6sK5NpLb1C4mscCFF1/ORG5V1ZEex40jPX3QX69vHQJVnJDQjoaw8EoKr5WoI0gWKZ/lpqlEJubtZHff+EkLz0UZ2YiDSE8R8J6UDLf3alA3Bb3dYUKpAoFxdq+BdAuAgL+b+VI/xKniTM0KaCCTwBCzq1gCatXm8yiCaTRfTZsn2WI1Y/T5CbO6A/ulOZ1YJuu5aQLVaYIbe+sRPn4chDn312SJ50Ft/HBJaKL8TtkkX5NCXhWdqjifYYpewRHzCAMxL0TGM0Whhf/kjnyhmZ9KWBpWW4gRAeo5VPn34DR+K8HfKk2OfxEjopXXwuTi5of1/+TE7j3I/p+ESTp+X/opwUsMbZVwnRUeZVEaKBxGSbp/W1WbN9tHz7QfoM6J+i1XpctDi4XbFWT6oniZ/Bn545yK/Je/FEvbxFno2rcRxGXPZ8cez1v375Wv3Bla4pP+uDj+IsnI5PLpAPH5JPyt/Il+TTJfPJy3cCaDo0pyASrNAjYDasQsG4CrTzzOZo4wLwtdHx2gjltg3o77e6XaLNHsNEt2D1u6wW9058DwN485vvyevkow89znTt32hObZZ/e+mUvHazeP7SfzMtE/gZbyM1bqZdDJAWiI5kqzFCs1oraBD5jzQjFwi+tvQrGmpLp8aA/m53ht/qyXDbPVa/sPnyG+fPC5nnz58U3SdPXvqYViS+tStpRSP4A06miRRE0aBDnUHQCxGGSEELC5GsYLMudAJbbDZpyOezUiM2m69uRQ9auUGhW7tS3iPv/UDeKx/F2WQI9+Js0dOex/ZdOqE5dfljwQ0hOWndyn52GBCIQ9QYhdUmkyZqlVYwRs632WI1JnGBxtf+Kt+jjbZr83Fs9aOP74cevptLtFs0aCWFZQxM9Wjdcr1cfEx+juXhdWiX324//fDx5qaX2eD2VzWnPn5JPr6SzZC9DzTefBtwwwfNUeJAC90DURqGAh1ST99KBQFyfejzWw6mW/nZ6ESUUHO0/YC8vf1VnIAP4gOaUxe7a05d2imOoLMUdZwU7xCfhDhwQyDgQRbvShja3xAwMIPB7FqncVjNa+0Wmz7eAE2Inu5N+pAU/X7LAcUSuU1ObLP6/crRMsgmk1IzBian8EMl6TwZmX46KFpFrT3G4U8X75DfvH977bpDmIYftDxz54eGz/dhCmrkN+Vj66bPmrN27vWvbjjwRnzirZPH/z3rhaPtMibHT5tYO5LLfWPHCU0k+Z2ZuE0PJAhkpiy6xeSwaGJb9BbDYrs9gYFobWK+9vSQ6LkJpZP0qSB/0fHIkZnpTyfHBE+SYHUolpuEb8fIJ9C/9Dc3/f5j+c/vrJNuHou58te3lpdrU9tfnTVcPij/Wf6rvEVY1j4/FX+Bs0gDQ0luvcUtEMs91RGzljmMprV6SyT5rnWxRpFRV08NO2p6yFFDshjkF3u//Jj8lvxbrETXvu2WrU88svXpx578tSW7kmzAQ3IpqJI/XXds797X1vHzl3ScEHfR+S2QAP0D8WZAK4tv0ThsppgWg8XELE1WazfH4k4NhU+fnu7L7dQNxQjwpztiydqtqR6XVVHKLvlIy7qfvXYGe7xzw/x70S8fqRsn72+6f/q6u4dgATowBquS8vDUJYE1euW7X93OueESaBW3khIcMDDQDYc6HDGgQY2wNsIR80uzxYFaaLLZ4rDJqDDUflBxaRLIRM4eD5E2NwnB2hnFrCmMtCK2Xj4cg3MOHDR88SY541YsxO4sUj4ifiVbWbS8+QH5/HjMxGRMwhHtx/PRKx/nspErxF2kjzhIgusCPeKjzC1udzddRIvQLdac4OjWEmPRWqMc8fHJPRZbFX4OKBbMJUQshQRGmiI+ktIy/A7ulhnEmSKu2EFXS+uE/MqR182vrdr5xM6nZA/a//ibX9oxST4yZZz8uyUrbl1CUfXLvheHzt8TWM9GoRZzpw+/fJQN88qrn/818fowhcGPSI/8NosPGLGWgdasAV0Tan0H2w+CLzdXEY/VLfCo9JH8PJYY5CPo18Si+Zv3xaVkfxtpjWPKGqZnkQE5J7d2xQdpyjE+mnqVceIHJBcrpAaijTrNGrMl0owR3JmjjfqmCAqwobDON01Xgq1V8VweouzkLC6r+IF8+Ja76u7na6585ia8jeWdu6Pq8g5x6eN33iCPCdnCh+IXZAsGiIbEgMW4VmuxrAVHxGKbzW5aLISvjlzl6tCEtc1L5P5HmT0ifyofwsEYi/GYLb9G9+FXaMeoZCyi+JWExWQI/yV/LO8VLsi3yI14P67h8UCepImks/F4MDBA16kVotealGggmPUWqwaVmIAUEBQGrNwlci3cIdpCEeHKIb8TERQBUkA4fIICwsO7yqeFAoIcpU3bQAHhkPy53CY/Lcxt/3kSLsaZEJK0sE1sJm6SA1ZdpAaFKLPeHKk1m63aptDdo7wNPjqoxEr0dJVyeqywLXJI/a9/wfe9/7nK2N7CCMvAy++JS48t+Bmj1cvI99PprCnc10wJWreYbGXiumSHPXYdvWBM0e7FWm1aQpMp5GsHLAfD0cdq4xfBICs3aYrJaf0Eis7+LoEotgezx4iepDLjm6c/H3ZT3tlf5GPqhQ8k/ev7an4+etLcs83ycfnyIOz25Hx/ht2YWb286jdvj5DPPTgs8/pBDseQx+7d8Q4/f7eOvwjDNYcpGqQH4iP19uh1zGE26tbpzUZLhE5jAoizNIUjo+Vg6H73pxOHllCEpGuDLnm/IhG3NRQgheH3rHhz/7pHMB1r5cdumjm0OELXY8dBNuEwFsl7D8ueYAP/9TVoIekcI7+w0psiBs0sao3GYSHpM2iix0tkWPxtXPxKPLwSDl1Wa3grq1skna+QJsmrMGP6XVPvQ//js8vwGfZN+0vn7hwvjOK3rjxJ5N6no3dGnKAVmVNnFs1agem0gg6ZqIMIjahcvpZ3062Qnb1Ms38/39KWHbqLo/llLL7fvkTeJ8mDcQQFsTRx6Td/wo3i8suvCoNpjxs7Duge1T4CPWD8LqOhW7wmiKN3auPsEUEsCxisWm3AilZrdHfG6RZEDHbsD8QYLMPQlBi9IJrNpOLB6DejxWjwTZx11OedTc8puqHp4UvS5vloen8NvwjdGZS1ujSI1mh1V8SuZN2jF/YLae1z2TL58Yo5/0CxFnsN7P0F9mWb2qvZrPYH2ZkcBLzlIvZdv3Ix3oIzB/26HsvlbX+T374orwENRHa06i5of0vvWDdZbC/oCy/sg744BFKhF16/MyU2IWZPx1mIwZJn7fZIMUHHWzocGkjUajHhRMrZFJaakprCkl3du+cmjkrcmLg9UUxMjEwOYiBg8CV8lcASEgxxvUkKRQGLC/sjw6iA2T4sKspmjuRE+0rDJsNbhhMG0WzABQb0GXLpScNlMnsiCcHv89KrJV0RDTeNifQ4oxdDts83UXk4ZNmyw8jSZmkjgZFhkqySU0hq9BClJGp0qWn0onMnp5HZapGoIZFmuHVbLzz1l8n1U7EUB7R/KGixu+BsP4bdcPoDVWO//OYVjVM+eU5eyw5d3iKMD+WR+4Ss3qkHb3t338qV+56b84fE5MuvCyN//pIsf71MHjh3rnxmnly/iL5hmjru1/1DuxWug1wogKGYHIjq388wOCo2yWKLjk50ckE68fqAOTdhFBdSrIueC5lDtUHMC9gs+a78/vll+WJD/sJ8ll/sz1PI23X4pg4tOpeOuXQNOqZLDeKInVH90kmShQFTx2DcOBhhMDYMxsF9+QZ9sSRghH7Y0A/79etlTk4M4rDnG1w4yYUuIUidBsayXYN1+WKv2Cw+IQtLA2nRQxqy0Zedm802Zm/PfilbyM5OGrKgF9In0Kus18pem3pJvTS9SEcTZ/kpRk6cRQ+Ftiw/vWStfl8bkUlxVk5vy+Kds9rSLe+0hWr+dJ9Spmdx9U3kivP5s5VHvjWbrEOTljyI64Y0pUvz2B2xXHkertJM2yAedSjZM2GQ3wG8y674gUOjS6ZviGlawWP301y7xrdbnjQOc1fKQVzzl5FrimrTH77Jl302t3LVjVLC7988u2wepgy7OA4nPfOLW8bLl3GrvH8T9r1fflSehSsXjLku/4kncHcrZsn7a98e9wHrOytzYNmc+cXzX0wuuHyQPbZ8YcsSXL3yMC6QF900HMWm5XJ78VuZWRmz2t9+ccpH94uHp9RXte8+fvw4RQpLx4O6O7RBKAUp4LLFDvT703J8pKHBoobpoCSy1Gwy6Y02e2x3sbt+L5bxr85Y0lrqLAx2nA2YCwNRscMKC439swI6o5gWxFGtpfaeFE122uOGcRwwGEzDfD2xZ/dh8cYgDm+12wOk551mUjL4ZreRSrgfzfZ6SUvkSHS7knK8WVxVbSR5P4mea8GazTF3p4l+/v3V5+uPWl1Y+IOsHkUHGbE8BilK4OHIbWFM6/Gk0SuM9GP1MKBBEB3CtmiPTqtM9lgzBwmF6csuHp/un/vNTSn+w70Cn2FU7sU76vvRHi4BEtKXNZ7vEex/vcuB9mj52Q82H0az3d9L/vLlLVs+7ekq6F6Q9Io7cdJUH9vQI729kNXnx523FeK8g1OKG7Hl9xEPLsDJ8i+3tGOSc0hD++n2sfLf5p7LXoElZ/Ehueby+4fWv832YZ38u/bFbz8YZH3Rua1k0cBZWUPlI5448td48teT2m2QDoNgCJRDWyDV06NHSjdb5CgTmobkB/IwL2+Me/TwshvYALo8evZMzTQNceANe7EYRkAZ3vB8YBQ+OApHabgjaXDITrFvnwhS4XMluUURPn0R6aS12JfKe1Mxf1dKirtbZpBCqTk+3tE7JsaYM3iwz2LUkwqLd/l8DnTxkS4cFYh0Bxy4wPGggzm4z1G08/OYd4RrjquNq0P5Mk49lnfbuCv5/VkH6PGUxX3xozYfV7ktHDnDmZRMMZS+fnJ6f80VF4sNfaVXki2alE1f5pmguKGiSQUNouvIryG12lDLiBqNvAx/888cFMuHWPH031LSHph8Jn7Xlsm7x2+dM6AtLhVX5FkemjZv8fK6uzY1bp41PdESvzi6fVJyYYy4LE+/Je6yZdDJWWv2L2IREUc2tjQIcNeioSnyRxlljWxMv7RHZuG+mkzcLm/At+W+OEV2YXcs7r5q2RtyoXxg+51nH9oUXLxt8x8unE3stTitdlHF6Xa5jb23RQ7WPXAIB15msu2zBUdx+dGj8nsDe7/y2LBT8Tgn9Ntm9u9NQ+H2fyHthE+vJDSH09DOtDycnvm+xARWwhazNwQrpamUfqGkxyi9JRrEckqLxGMai6YgnO5Qk5rUpCY1qUlNalKTmtSkJjWpSU1qUpOa/uPSH/9/SNol/2+Srlk/UU1qUpOa1KQmNanph1LEBH2XP93EnvrhvywinIVfUW764VH/HtAsgjHacv5b21eDaOO/i/4t6Aq+O0bTcTVN8w7/3esfuW8kFGnGwEaxGoYSLhHPw1CFTnWO2Sz+m6AhoPpGpY+wJl0Zr7SFl2n+zVAm1EM36rvqLyCJJ348LyqooIIKKqigggoqqKCCCiqooIIKKqigggoqqKCCCiqooIIKKqigggoqqKCCCir8a6AHuPGn5kGFEPA/M/tT8/DvBDqPibLlp+ZDBRVUUEEFFVRQQQUVVFBBBRVU+M8FPUB81//bqf+fx3fj+f8uV517/Y14M32XfjXtXx3zz/fFx2jvj7rgDWF+3gvjti48toXnPEP5EWp/GG7vDc1HM++75lxnfiwvKqigggoqqKCCCiqooIIKKqigggoqqKCCCiqooIIKKqigggoqqKCCCiqooIIKKvxroAdo/Kl5UCEEpIvqn5qHfyfQeSZTrvip+VBBBRVUUEEFFVRQQQUVVFBBBRX+c0EPcNP/AR8H6rcKZW5kc3RyZWFtCmVuZG9iagoyMDYgMCBvYmoKPDwvVHlwZSAvRm9udERlc2NyaXB0b3IKL0ZvbnROYW1lIC9BQUFBQUErTWVpcnlvLUJvbGQKL0ZsYWdzIDQKL0FzY2VudCAxMDYwLjA1ODU5Ci9EZXNjZW50IDQzOS45NDE0MQovU3RlbVYgODMuOTg0Mzc1Ci9DYXBIZWlnaHQgNzM1LjgzOTg0Ci9JdGFsaWNBbmdsZSAwCi9Gb250QkJveCBbLTk4NC4zNzUgLTQzOS45NDE0MSAyMDM2LjYyMTEgMTA2OC4zNTkzOF0KL0ZvbnRGaWxlMiAyMDUgMCBSPj4KZW5kb2JqCjIwNyAwIG9iago8PC9UeXBlIC9Gb250Ci9Gb250RGVzY3JpcHRvciAyMDYgMCBSCi9CYXNlRm9udCAvQUFBQUFBK01laXJ5by1Cb2xkCi9TdWJ0eXBlIC9DSURGb250VHlwZTIKL0NJRFRvR0lETWFwIC9JZGVudGl0eQovQ0lEU3lzdGVtSW5mbyA8PC9SZWdpc3RyeSAoQWRvYmUpCi9PcmRlcmluZyAoSWRlbnRpdHkpCi9TdXBwbGVtZW50IDA+PgovVyBbMCBbMTAwMCAwIDAgMzMyLjAzMTI1XSAxMSAxMiA0OTIuMTg3NSAzOCBbNjg3Ljk4ODI4IDc5MC4wMzkwNl0gNDQgWzUwOC43ODkwNiAwIDAgMCA5MDcuNzE0ODRdIDUzIFs3NDkuNTExNzIgMCAwIDAgNzI4LjUxNTYzXSA2OCBbNjI5Ljg4MjgxIDY2NS41MjczNCA1NDYuODc1IDY2NS41MjczNCA2MjAuMTE3MTkgMCA2NjUuNTI3MzQgMCAzMDUuMTc1NzggMCAwIDMwNS4xNzU3OCAwIDY4MC4xNzU3OCA2NDkuNDE0MDYgNjY1LjUyNzM0IDAgNDY5LjcyNjU2IDU0OS44MDQ2OSA0MjUuNzgxMjUgNjgwLjE3NTc4IDAgMCAwIDYwOS4zNzVdIDI1MDMgMzcwMiAxMDAwXQovRFcgMD4+CmVuZG9iagoyMDggMCBvYmoKPDwvRmlsdGVyIC9GbGF0ZURlY29kZQovTGVuZ3RoIDM1MD4+IHN0cmVhbQp4nF2SzWqEMBDH7z5Fju1hUaPGFURwXQUP/aC2D+Am41aoMUT34Ns3ydhdaEDhl5n5z1f8qj23clyJ/65n3sFKhlEKDct80xzIBa6j9EJKxMjXndyfT73yfBPcbcsKUyuH2ctzQvwPY11WvZGnUswXePb8Ny1Aj/JKnr6qznB3U+oHJpArCbyiIAIGo/TSq9d+AuK7sEMrjH1ct4OJeXh8bgoIdRxiNXwWsKieg+7lFbw8MKcgeWNO4YEU/+xhjGGXgX/32rlHxj0IaFBYopWjOHMUBUhnpMRRQpEyJOYoLh2xFAlVGKrEDVLlKEFb6mxZlRqiDYssldSqsLQ5OUpqS1lYIVmVlKJmnTJDSVPWrsm9m+Svt8csTi5ZgDnpEXtkSCk2F2GRMdIRaw2x1hB7xBGxGi/3MaBnSvcKMKeduH0Z93Xym9Zmk+75uBXa5Y0S7i9MzcpG2e8X83Cx3QplbmRzdHJlYW0KZW5kb2JqCjQgMCBvYmoKPDwvVHlwZSAvRm9udAovU3VidHlwZSAvVHlwZTAKL0Jhc2VGb250IC9BQUFBQUErTWVpcnlvLUJvbGQKL0VuY29kaW5nIC9JZGVudGl0eS1ICi9EZXNjZW5kYW50Rm9udHMgWzIwNyAwIFJdCi9Ub1VuaWNvZGUgMjA4IDAgUj4+CmVuZG9iagoyMDkgMCBvYmoKPDwvTGVuZ3RoMSA4NjY3MgovRmlsdGVyIC9GbGF0ZURlY29kZQovTGVuZ3RoIDE2NzE2Pj4gc3RyZWFtCnic7X0HYFRF+vjMvLYt27IlyabsZtNggQ276USylEAAgQBREiAQJHSU0JuhIxBAMEoRUJrtQGDpAVRQECxwYsOCKIqinkaxnpDs2/83bzeAnnenvzt//O937xvmzXsz82a++frMCwnCCCE9XFiEevZxe4rPPnoEIXwBaiuG3Dm4yt3Y/wWEmBKoOzFk8kR7p9v7CQhxsVCnGlY1/M5lhaOXIqR5ACH128MHT6hCbtQM+mrgfdPwMdOG9X2/ObR1W4RQ3sMjhg6u1Dabfhe0PwHtWSOgQudJeBieK+A5acSdE6cyz7fMROieNISGZYwZO2Rwyk6PCaGoMQh5Y+8cPLUq/qKa4mKH/va7Bt851FjSCvAhPqgzVo2dMDGYhYbBvY+2V40fWtXZ+f04hBQwHjtmMsxnXBijgvb5dL7JMN8LuCwHoS8H0PkQBiqoIBkQh0xICAaRDupQ9DLyBtqHeiMeEaSHFQK2bKrQiBhoZZAEQS+d91cA3lfMaJyBkC7mJ/vVGdoHaM2NEL2M1iiHX4V1qXcEPr06Q50Zeu+XfRA/G9V49uoG6fJ/sKsVUstOsq4PLd/pYU79yd4I4ytgLqQETEPACI/hFbAeBbeW88KwyaGS2YjGkJ8UiKh5luFYlrCzEZo3gpXe0dNL9z52O/Ihe1Ap8EGehVUwCyoI2vDBW7D6UdxFSmFEkRBQP0oJVgn3lagkfI+RBhWF7wnSorzwPYMSUVT4nr2hDwe1KHzPS/W3o6FoPJqARqKx6C6YKwu1QpkoHXWHmiHQMhbaxgLVJ8LYdqgdCvXj0TSo6w33w9EkNAYNhpobW/4EPT0wRmuUK73zy5HsqAPcjUdV0nUw1IRmbwUt7WC8MVD2hrrhaAS0TZCehkJJMZ0M10roSYFIawEdkGSElizeDeUwoCiHUuC9ZtAzD3VGXVAxKoU3R8GckwDHjcwuu9GN3C3dQ92j3Pem+9MvpH/eA/VQlWj6Xilr3n/tAMOAcRWpQ6tGzJrITEqfXD15R3X67Pfntph3apFvxZ9XVT+outKiAQeVIL2UQ2nIBettB/N0A1wHA+ZjJFrQefTheUb+C/MogsHgxb+bhgRB+97d8+6Od/shdP5Pb++m6fCew4/ve6YueXf7HTk7Tm4f9advHzmyK2LViQeWr0xY/dXy8ntn1SxbMnz+X6cvmfzMxGxjS26ckPdLrfkbKAqXnf5Jv38GeprU67XrQd1SkBps3UWUgNZKV8RK1xCwo+B+FWj+h/Tp+lUcFPwh1EOccH1Y7itkIhnBL5lDIAso+OU/QkH0SzoMoAhnSS2r0Aa0Es2Cu6Vo+jVrMwUt+QdDAfXRgd+++GvwHDqEtofv9yM/egw9LN0fQXvRVpDVJngUcFoB5WPoIaDFcrQJrUY1gN1stOCG0db+6hwXsQFvJPPQ6+jU37StReA10EnAfSmMtwD0YyJo4Ua0U2p9BGb7BWBl+GYOUGT6teoHId8jPc8HnCZDv3tJJujZDFghbV0BrVNZO/nxt5Hl3wTtQEq7gd7fBpZzENiMkbC2CWgqqkZz0UJY8X1Ay3Ww2kevvXFj3QJ0P5Q7UB2804M2cl8iC1zXUgsaut4IIDtSTfCz0DW4OHQvNpPkdDXcHYKyBp1FH8LTA3A3BWhVio4BbcY17gh+gSIA5Wg8F7ymDg/BlXgo0uByPBAPgrIf7o8HQNkXl+IyKEvwbfh2qb7v7qgEXTs77osKIH8AmUEbcAnclYB91OHRKAGyGzKDx+LbUByKwGNwfxQD5UhciaxQDsOlu00R7nZ6PBZhPA1PRtHw1nQom0E5A8ogSghewHP2xMbnmg7juxGGp8m+kuS03A8uWKyxb7wJlxl3W2wz7o5+9TW4nzwFLndWwWXMWLiMvstiG33XrPExEyeZzLHDR8Fl2Ei4DB1hsg0dsWBcTPQEy/QO0Y5pkNvl4a64CCxqAu4SLotwIYqFsnO47BQuC3GOVPpwW6lfQbhsi9vA+hLwLeEyP1y2gf60zIMyBcpcKF1QZuOc3a4E1E4Nz2AB4aqHbIfM4CycuT82wfeDUplbF7yw52RsHC19xd1j4nIvfcq4PvuUuNavZVzrID+4lnWtXc24vq1lXd/Ucq7LtUrX4FriegjyfbWM637ItasYV+dVxPUw5DVwv3IV61oF7xwMHsXFu2223HZa3BP3AIFy4W74VuCmC/fA3ekz9Oi+O69N7kHcHd/q+5pxnT7FuRbXcK6a+Yzrq5lK15xZ2FU9k3PNhOdF87FrIeR75hPXAsjz5rMu+/zUtFxbtjkqy2zONBszzDqvWeMxK1ub+XQz4zajVuaUVG1aqq65S9vCpUt0apOcuvgErT1Bp9MbNEqVWsMLCg3DchqEiSaF8STwTDBB3Rxv0zXoSBvlYSVRMx0Z0pF5mSFq1B9tQ0wbMANL0GH0MmpAvA3HRUQJMRFmvTXCyJoiUD7OtOEW+c3z0/JT8pPyE/Pt+fH5tvyofHO+MV+Xr8zn85l8lF/sLcF+YzfUraS9PxJD2ae93+vqVsfYe/s9rm5+ZXH/0l0Y31sGtX6yqA6jEj+7qI5AYezQr39pHY6mzQtsB0HAkb9bxYJlZS5XnL+yW59S/+y4Mr+H3qyIK0Pd/J5efpuzveuXMGGCdJ0IKXR7DXalpRT6mxcO9rcorOh4YwP+m0FcLvQrdRQmTvqbKn+UvwAW+svqXUq64uLe7bv5Fb0hF/f3xzjh4QV4yIIHjbM9ck2UkA3hHca2DvctrMNzCyvg4uzo8t0+aGD5gP79ykp6d7+1W9cuRZ07dezQvp2voO0t+W3ycnOyszIzvJ7W6e5WLVu4mjdLS01JTnImOuwJ8XGxtpjoKKvFbIo0GvQ6bYRGrVIqBJ5jGYJRCxzlj+pQWjjKH92hApDp6NTb/Zoel7u7/choczgNdq+7rGW4l59z+VFkN7+puHQX8uWU+XnXL7v08DPJ+m8d8HJ3m73QzybDP2fXwZX+tN6lDqf+rO1aexm844/pUOpw2PwkGf51gSb413WwvdKvL4Z6hy1U08WPiktprgt+lAOVKMdRBtfepf74pseysl9D8iBY9aO/QLMHrtHv0kR36OhHpl1I85EfmWm3yzng0fP9aSCPyXq4k0ZDbj82fevHkX5s7g4o/3wK+tqFnF+hQWHlKGdh5UigaGXFdZpeDlHUYa+x1/QuNXjhVkIaRKFX6S61qoOzw1AVVCCpAu1SqaFGTStgiKpdWNMWSzdEU5i3iyBFBJDPSNEtpHmU37ekAm6cHYFu0BJ5vaUueHTpjU0IXmu6iwzdhZDw8x38QggJ+0i/b7AfLbHvanG0ZmmdHt1R4dJUOisHDyj1M4Ohwy7EJBeOKPHHdivuB1UwFeSKEXbK7o7ShTLPXjjCXgPPtG8FXJ0dKdN/Vl85YmgFFRNc4ewIbcoOpQsdR21gB0oXFvoNLn8EdIuY/rGNqSmMGmmnjzU1C+3+jYDuDa0OegUhiALUawqdMBsMVjiqPWWJ+xrbJGnsUikxx7dksN0/+45RIdkbvLRJ/h01er/mRwdwB/gDb0ovhklZWTGKojxqMF1m4Sh7zZKh0lKXSksDebUXjupIM30RpB/dBm/3Ky0c4Sy8PiEsHG6Y5F++63D4o130xZqaQori4ErAPoQyNFzHn+qEzYUBnw5+X4lUoBKJBzCjb3DHsnBVuEM/+hptqehYVuYI8R26+oXkhVwrp72Gjigk+00uveM4tB1t2aJb79LCjjZp9X7SofSW+ihbPdx3K75WjaOgT4273haiUbc+zm69QlIwoulSURJSYHKN89A13F8a9XSU7TTcd3J2qqip6eS0d6qpqBlcF5x9h9Oud9bs0mhqqgor7JLmY6g/tMTm77S0zK+vGIHzgMlU3jqBCY3s1Z+yp5N9xOCQsShwOnJsDkNZU5/iv9cc1jOQeJB7qmc1+i8BNw1YJJu9EzUvdWAVbH59DlVTwOS2UtCDIZLMShfQD/BCxEY1hSlLLhzZJ0wgkMawwFC71ytcC4M4HFSHltT50B3w4J/dqzT0bEd32HYjn9sFvKugLUebWsy30ZbZTS3XXq9wAq+iqBf8hzJ9ozzXGJxGe65bor9kbiv9R0tgjT/l+BU5YXZHdihlbCR8R2wMvVO5wHzl+60u6UVKE7CSNXqn/YzTr3f5uQ6lR235ZXa9Acwbhj5FLqo1YEXPOF/E1HYik96P8/3YQusR2FLJpDPWHGi8Jjz2wpqKsHTduKywA6gc8etrgz56JyzPFupvMDrpCk9JJi1sqZM7UV2yOUI9upb5tdQe+7VfShfA19ah1A7WB7S1l3RjL7SPoMz22ys6SmagzHZjNYSTFR2p2QOUaRdbWKzhGiLtz2Xtt0v4bJDwOUvLRoB0+33NYQX2TJhW0paS0jCVcmxhLaJzdaFL+Xn7NSo29YHG4l99+W/J3q3kZ083vCO15VyzCCWl/k6uGyaA584u242PRb9o7tLUDGaj2jadug+C2u9y4kW9dvnwoj79Sg/qEbIvKindTTDpUNG+bFcStJUetCPkk2oJraWV9MFOH1A3DKPtJgqpv+2gD6HZUisrVUjPQyCylOoUTXUYDYEwU6rTN9URqGNDdT6pLhRN2Kla1lQ4QVXBQJYiGy6j4kZZS5LtdcEgWLjTYBkdfj55AGQwgEpXmR0kriv060xzBVR39s8eMpgKLRUphtraLkPK/IprA0KXLn4ljKAMjwA9OknvUCsNLw0BwRrslG6hGgR5dpm/zEUnLR1JB7DbIV4pcub5+ZTQmFwKnchdVmN0eiRzzyf7VckLaaEE3KjRkmps8AiTlYU0StAA5kOc0DSkwg5UYdGQPqWgNSn0n8oWqhkKXpdNGSpllS3ciELSro5Q+ZWtqC8RpHt1KxgQ/gllZSHkpaeF4Q4wt96vBoxSbiBl+AWgDjR1objAv4WAKu36LB2mVx3q7ZwK+kKRlkYSoNkfkdxlMBiH0PtqqHHmNL0MYymkKjrG8VCtQFeukQLOkrrg485pjhugZQsneM9SKkAINiDIh8pqflnh7w9GTvHL2gipuqZGEfHrL4TopYi4VkIldEn61dQDTYG0AR1Ap9EFdAHbYZ99L/6COMlI8iy5xPRmHmNO3JhYhh3IPsy+yfFca64a0hZIp7hP+Vjex8/nn+KfEpBQKcwVdglvCKLC/TdpluI5RVDZXrkU0ocqo8qrGgWpWnVK1ajOVk+H9Iha1ORqRoXTkt+R3pGTnOQkJzn9ESkiVk5ykpOc5CSn/0FqFzFMTnKSk5zkJKffncQ/NmmH/U3a/zvS99rvddq/k+b8avrg50lf+TfpoZuXDDm/PRlHy+n3psie/zCd/m9PpgW/Kf31j03mjnL6v50sSX9Msrb6L04LQimq5nqKPiYnOf2npZgRcvrtydb1359i0+R0k9NxOclJTnKSk5zkJCc5yUlOcpKTnOQkJznJ6T8zxfVEhP6CGwHx9PcGCShhP9eVYbsi4SmcS38tFVwRcte76zG9tE53GByGZLhgeOHqbI7+AgN0FcENdH5cHESCfArSIpNPySNsE5D6FOuuP+5BBQWt07EzhRj02GvmoTBaSfDNUwfwvDdPfv3VC+Kgevw+jiYJ+LhqZ+AH8UPxQuCvu+iYC2DM801jqhCyKbHmFOcOXBszM8to0JPUTC+CAvd788X6r154E8/bJw5S7SECtuMEotylEvMDH4qfiUkw4jGUyG3jWKRGCT4to8LsMwoBqQT8NMe6Twdyc0+jUAGDOwxOgyPTYfAaHNy2wDtrA++Q1LUklXShNw+Q1MA7MF6NeC9pjg1APcMBspvxs2gXcdcj/Y9ALYydkaS5eOkePzYEqsk8uqIaUkCukk+hv34fJghx2G3MdcOkdMJMB7kaWEGqSMETtO/3cHlLGlu7j/gx2glcQBIbnAYvfuviRWgjaFrwQ3Y2j2FFVliTXrOWF4xrUbRysdkcrVvMuOth/HpUUF8AL3J2SnyHnRINJ9J7r4fek2rxx6sNWImFxqviX7etXbtt24NrEvDd+H5IM8U5YpU4RpzHLRS/EVeLa8XLWI9H4MHYDAhiYAvbgvsMaZDDp+fW80peTdZhjVJdwxHGfdoToDSt9xScpYhTejoys7Kygahsi8b3cZ54ou5h1b04o4bVTMfDq65upiuvhTHn8gRFoUxfjJGH0R7UCcT6ILZi42I+AhKIbYxEOmNurtutrzfkSpPUn4ZnaZ4sZMzMSHEmCiAjXg9rNmkJdrBzG/Ub8fLntiw9fUL10tsfY77DvSfE9UzesRp8F7YsmVEz91jF+SPDDvlPiK8CHmuAtncCHinoVl8ze4J6rU8TnaxZa0y3RD4YLWD2weRouzp2sd6iV6v1FgYlLhaENOQ2AMWNVsArhBhgBf9cKMod072eoped6bV4PVkUP2dm+CaMqMVs4gUzazAhZ+Ia/cvvbHz2iadKO26u27Ts5RfUL73zeXDrbNxFfO2riwUv3rNj3YpFa2uqR02Y9/ygY49NPxqjbyMefUX8kf4esLZAwUe4i0iFIlCGL0bDC0qsXsuyjMAzKIITlGoG17CsjqM0DFhzjZRLBVRUcnMNFEfslMQfew1ehwGzj5zfG3CR80+eF8cG/oR3iz3w7teYQY1DyLOBAsqxJ4FSk2G+aJTji1MrHzQao3QPanggUVS0VmvW16jVyAzUsYWpAxnKEGkoBieuU0XvSBQMDrPDkOW1A9+AEE/qj72++Zg4auJRZlYgc34rHIEt4uvffZn7wqyDW3BaGsNtFm+L+Oz9C+LHdO3TAZc1XBBZkJNiYxUS1yqV5ljAxSzErtVFYxytWZyQkCxELzaC0FzHpSBw3ECfPB5Yv9kJTEFCSHgACbAwyOHBvNlkbGIZK2hKqs6LP1me3nMOG8S33wuKn+AZuGJUoJo99MjqJzc/tYX7dFcz8dOr4767+JH4Hh6Ce+EN+OXG070NX4mBp7cuq6O0WwK8ugdoxyOnT4+YB3meMBgRwiKkYEMyTsUc+FPvkawKtRTsPYEBL5JXGrcwDZzx6ldcu81gJ0YH32eX8Rys3IFaoi4+F8KaCHsib4xZxwup64zR1hqlEmpYXdxihBOZ5gxj1i1u3tydtNgcYgqdyppbb7A2GQ14gjkzUzIzkiRKUOmU6JGUqceUCEAQizWLo0WILil47tfY9OZ5rFkwGTvF1y5+I15g2j22ZP7jZ96oE4tfP7rywb29H2ISNHNf2fb+a1vvejYrovrKc2Lwry9gDl8aUzNn5MRV7aY8P+Wd+/Y8tLh8XA/g6B3Bi5KNM8O6gKMW3r5WoTDFrNVSHTRFI6Q2LLbwVqszbrFaWoPXS68IGFpAeStx1Erlyx7JU9QzkNcjMTQRZ2eQ0CK8nu+AnfjPrV544mPxrzjtvQacIN4jbhhB5jJ7t67csfnwg/yuNGKdGnjvI5wkPi4+KlaIWUxm2feYO/LEioPgSzuD+DVnR0m+NNqnwX6i4/0cONKdHFUsMFHUCoNqeUG5vKT5RQCmDBsaVoEph3UawSH0A0kgoLdtfQkswgzmCI95LDAqXlCpNAJXSzBRMYKCEajCUj6lY7fBC/8MXmOufuHRozS3VjKMg3FiL2aOgtX+llxeFxi/7mnSqp60JF3Ip4HowAG8Q+zNXbwaR33/QfrbNWFmA4pBScjnS1Tban2RGEXWGtONtZiJrUVqlaLaakXaars9JTJ2JgqrDs1er7S0JhPXOh3MuyeeMZsEswUsGuvA8CzpDGNw2CUhcR7ETw1bvnpMxksPPim+LH4kbsURx9bfffVHrMMJBzve9yp3UdGibGr3F8Yo7KfXvHWFKxSzZs7rf1dgfeDpDQtLq4uo5pQHP+EcnAhWJ9FnUGpqedZirEWRSqvVpqsOuT4vSDEIwXHq/EIqzIFmOyR1BnnNhoCEZ1qJO8Q5eAHu/jVmtF+IDV+Jf8G2L2ZdWqw9+qYNr8ET8Bi8eeG558V94rvie+KBXpPf698KuESptgmopgTOxft0KiCUuhbx1TqdSU0JJLneENOBInbWaAYEGIM3hMlBPBq3xWNeF8eJln3P4aG4o1gnbuAuPiZu+0k8JXbkChvKcCuciqNwHl0tzMbeC7OpkccXo6z18QTzwB6QCAZmVrBqdQSvmolDfPk5S6hLlGyqlNl7G13Mm42fMELjFcbGXdwsdtkcOBSeoUpaTzOfidRynIBrQdAYkDWkJvxMITS2FLGEFEuKk+ig4CzYqgBDHg+UHWIOcO3EtpsDTvrrOimXLnLDgEsx4IlsUbXR0UStrVWwploSGRVl4dRopsUSa6jmJHqFTLBkeo4bpQmSWWeIXvbrnHN4smlsxg0Tn/qzuEYch1dBOMJhjfYH8bWfxIu4GWaeeVScRgqqlgH7puI78cOLz50U94ofi2+Ju4rw/M2A13RQuSMSPSFyUXL384yK3I8VatXMcORy2hMKKjxSRAE6m+kwU709Ejh84gQpfP75JezpJUsavCHKcR2kseJ8ETzDqYEnKELBzIRVefRnTxgk+01DNyxQ3TeAZnIdfgj4lxw6RE5/HBhGtiwPfMldbPyOiQjkNnG7EkYEa+5TEYatxUhgKXf1JyhnJY7SKKqy8bZD5BvQ4yPhtzgYBqKx1r4YwqnUrIJlwVhgQalSMzyaibGWnyWEjb0VkPIWhGy+FFaCb6HYYezlvjwkdh8mdt/+Fd6Gt17mtI1LmYlXvwUMH2KGNM2UKcmKzafhGJbHjCComVlsyIlcXy8VDWzwcplvB5TbMSGnt3OxVz/mLja0YN8AHSoPfsg9BTFWU/wKSizpcDWNX6t/Gb+GBIFecViF6ZXRiEfEWjwW+3A7PFa8Tzz6F7ERs3/5HLNiYwK43HG4Cm8SB4kroG0QNxf07Cykg7gzbo5b4E4opMvs/VLEFIlSfJEaiEGJupZhiFCt15s1eCYJG7wbRJ8uTYpRqFKHDByecAhvBDJaxVfEr84f+uTIoVMkN3CSu/jDK2+J3zCawH277r9/Tdh2LJY4ZQKfFqvhtTAZF1HLU5OvMVarNCoWI4uWDYnQ8x4QIQhUvJRj9aEYSiKvI4yEnsOGUPjELf5O1IunDwHjWmIG8NCfe2WvuIEMDGzmLn5UJ744i+wO7H5iE5b2beODn7Avg3amoGKfB1mwJbr2sVg8KXZB7MrYfbGsUq83FSn1sUksimQZHjhjsSTFAklIUrVSmUbcxp+Fc8epS3KVl9cfLwd2JSaDzw1Z/tTklFAMYZWUGByu1cLGE6AdWSiKn0dcwkl7T/cdI/oPP4tbfNPYqD0jXlp/5N2ZOHNBn2bic7aZF4/fP33g6PiOqacfOfTt2HPba6oOZ1kLu1VM73pcFGEdVuBfEOgpoCifmidATMQJMwlynwicCIdOdO9BbRVpFfic/SzwOQRNm0FtMHoCZLAlvKunVlzHgxFnIvUzdTqjMJO/LoBe4DiVPgPoXSjYAaluCXL0aeCZQ8+dOHbiELldPCi+RiYxyxrv+PbNV79htlAKU69eKcV3MT41CBSPWAZCO4aSjnptSVFoWAd6x1UGtj8Z2H4Sf4YvUd8MamJjP6GjDIR9+qOSvBj2g4FBSMuHDXHo5dD78E94VOz3uPiEuA2C4iO4G+68E8S8Kx2M/bgBfHxDZ/ZgQz57HMbMAMzSwhbQoADzoEAYrIUKIlASIQ0vbWOkOZREmkNCMi3wA1G9Iw4U+7xM9IHGt/FD+HHuYsAa4MmUwGLyDfk2cB8ZS7WqBGJxhl0AXLGjPF88XmM0aqItq2L1CiXiV2os0dE6+3yjEqFEdp7uZ6EbxGxuaT8X0jQWJAaEJ5OH+I0KUvLPNk0GpkRc8uaPj29ftn/g6hfA/L+11L/uGcXh7Q2fw2ahyDBvwsvzZg7LfmHt8ycjEyePKz7gPfx8YwPgtxXwWyCdMEShdF80g3ScdaWg1yPjqggLUc0zm2M4pJ9Pdf+a8ns8UgbPJFBLniXtoSEiZgxN+xfcX7fZ/+z+k/XiR68/unLV7McOiq9szs/nUwIvrBdPiF+L34p+Zmbgjg6fvYG3Ah/6Bi8xH7D3gAw391ndaqzWrlbo7VZsNa0mFjVC0YZ53LVo5nQ5zTA7H/KLIZVqimGzvcwHL68WG8QPcPPA44cUhzdvP3pkx+P7FYWDsAfbsBm3LT+++NKbb15YSPlTBuvPgPUrQ+u3IDNmVkXqVWqkWBlhiZpvhtlj+Hn6JtY08UVaPzZI0+odlC9Oep5AkQGSMPMfmPPYIdx624PP7nuhHse/dv8TfqwhD3X8/HXx9oXV63Ee1gNfepfhH668C1jA+tkebA34umiU5UtADxsMPLNGAyRIt/qsDJCBt1h18zG2IcM8ZcgOB46HaRGWEAcBq4LDFDGazY4QNcw8VpPVCvH1NU/h5eIl8UXc/McLf218+vyx555TfEO24l57Gzfg1tgKlOksfv/T4FPnFh6poJQRS9jWgFMUSkRtfAlWXYwldpVJH61xrNRyilUklmUNaL5FEx2dlDDP8HPRPe2+QUhAHlLDW9sbqAR8ukY9tnXgm+3bFDu3bX9i34kXP8bRZx5ZF7HFv3LOowdwiw2zA2+49xet2161BqdhuhcoLMttPE3GFb77sjiGWoatYPmKgYcG6rdUCPYIK7V6rERAr0iNYr7ymt9q4hs4ekl5DGHxtZjZYv/EBet3+f0nju18hkw9v/y+xu0grU8/fu4VKiUbYZrhPCPta2J9WjxkOWxCeB2H2PmYCxvYN8qlrU2ml6EBxPCTJ9V+P3frgSsB2A+RoF8sw1elEUwQW1rQkOUMZgxrTDpVxCohlo5jVOrdx08ch7GkXdv14UxAtCYC0hAMXz15kjn55J3DVUP6jBv2V7A8MMunT70Z+1jq1OeYbffR0wjAdwBQRDo5g+f50slZQfjkbIDfD20S3QQ1cNgO/LVzgtFq4/Qr46L1Zp0amWyCar5abbLPB9NkjZxvumG344Gw0OstKPDWWyWnQncziQIYIWf4ltLVDHS1ZnnBWfD9vSOLFx/i/d7hPZf7/f4X93za693jeBCZdmBG7uqMXoEcMu2pKTm1jTvYUYueOHhQvD1gb+IqYBfiqu73cdV8nasPwZQnnwOuTntveXgOYCrVuQ/ZkTC+GlmkuGs1rzeuRhYlmLwo3bxfxF03xlqJTVt9Pan4RvwMx3z9NY4RP728xe/fssVPf+mwCVJ78aj4F0jH2MhL77516dJb+CiVpK3iIHYBzBq2tyFry+gke0tskr3VcfgGe1sgqVKBtINPblra39jbfn4wty98CeZ204OrZj96CMxtOzGeV1c/JL4oXhZ/EHczEwNjOnzyKn48rDFMBcilVor8Ixj1Sk6HdUihZ7TzachPQ+yCgoDHc4Ju3EK8lGysYNjqf2NPgU/oc9vW7eyoHTtUdaYVjW/QMfsHP2GeBk+XhIp8Lp1eaypSSBedLZFF5qjVRr2dxSwPJDaZEm3zdTqSOE+hSPllACVZdxpDuSjZJbm30/CpFcnMyLrR1FutdGvN48/fOCS8dBJbu066Q1zy/anXNgg7j09b2q3q/OIa0VZ+apW/8FZbZP7qyauO9H5uTlnPTl1j0+NXT133LMU5PfgXUs/tBAlo4bNolMwagddFGgBFNQiBktfMZ2EfVJ+bG/I8gRMFp6XzSw6kGjSTbj8gmjJZwoaW6MTNc+buxEvFia0re3Qt46dY8BwydgUuFA+vCPywe2TrpI1xMOtmkLwioL4BpfpMep0CSE8iVrIWNJ/odJGq+aHdyTVfI4l2puT2w4FXtsHLFvlPP7XrKf+k+WC1Fj1+7hT5KLDg3XvvY3rTdSWAlA2HGQRkPMDqiA0hpXSQFvpqgJ2RNIphhwdGPvWamHsEj8Aj2VFXfsCvsbmNjzADqJxmgfZF861BSmNRJ19yzJDlNmxTGiJXR2Arw69R6jCn0zExJDpqPiHxViUzX+CbSBU4oT9OmUk1MzcXyKaXjBnoJ43VgXA/46TZkQ1VrNYvKv1z5rxwsHQsP6BwYRXZrn7+eeZ8o5N5d0WLF143bYqvvi/xowPXfDboUJPP1v3rPjuT+uwVC37FZ6/p8gufPbBtwyqgMVcRHCvM4fcjHRJ2wU7CfTydc6LQFx4BRo20WIU5z4uP4AHPPzJ8+vThj9yHNxOCRfyoas05sVF8X3xPbDi3hnJrQrCK3M/XSSMxGgjYIcymn3ayQc2ZFPpxh9wvPnI8NMxxPIAxBURxoGLNOdjxJ+FEzJ5boxb701OsuOCDwjlBS39bO0pGG3cl2etw8T6f0zE7PgbufKY4m83ARzARWq2ZYVKJkZjNqA739Dmioy2W1BRd0tgkoosfG0/ibUk9HYMgpiAF0T2jSbTl6eBl2BxlIjPS4k77zSgCR0QbD8LWEXYY9V53eW69uz7HXa4/W3767OnycqAzJb6+nm7bDKEzEy+UXi8ItifmfU8MbEgwLzgEXtAysEVPTUKRDh7RMpsTUlKzLYJ0ZXbEZTEvKZj0hP4PvAr29P6zbUg70r9745OTxS3PDMRKXNOJ/WRCh1tH9jw3vl3PO0v5HoPuWpK/feyFy2/sXNR8RRXphxufEx+9a+wTRPnRXe71U1tPf9Z7/6zWi4HybYL7BT9IuRnd6VNrlEqFguO0jCGyDvfwWZFWz5hMhGGsFr3BwCjgHvb52jqcC1JoV2qKEHOIrj94dK9SX0QUIO+ueq+LfvLIpeeRdMVhMuS6rbBq6ZZueFons1wqsBdFWgkSkpIJk42wkMJvD7zQ8EF06dzFeGifvePEfQuY4Tj3T98twCk4x586up/nYeC4wMzBKQ5xe+NLgfTWENIWdhUfCWxqM5BqxivBx4TW3Pf06xoq8akw/YapUqt1LPB4v1YLGzqDrg4X7kd62L/qVXW40x49UWNaNZuAR8bATNi7ArPq3eX16QYjznWHrLOX7r7drenJeyTsjlhYAGVYJv/lVS93ulDdfLt4SIwR98eRXNIr82oJN2KpaNx7Qnzou4XK+yLwavww/Vs6Q4J1wjp+GvjcHgeRAufu5ThGCQKY6zPpcE+8ATPNEMa5fnwUX8YMrgse9UUabUXYzqQzxMesYM4wFxjYPLrLx7ld4weWDyyv91LXkW4NfaeUDviGMNYt5ONALDOzaB7fNvDanMZx8+hpF9NemMucAdrEHASta+OLQNiOSRVegf0wFx2zPj0S9sfTBQXT/t57YWuIjgQ3CgW8HuyoGrQzEvYnC/YxjGBVg4Rk79EKJiBdji9KyyJ9ut6nZyhdq/R+/WU9l67HesB/j9tTRMv9OkuRXq+KgPd8KTq2gO3JzmKXsxtYfhZ7hA2Cn4G6sVLdTqh4hVWwFKPx9R6v2+WCG2CJ1+Om2etOT6bncNSYwoWh36PDmd9ydf9afvb6wPp1gX2kWzhfIpWB9ZoxfNWVFcyLsPd/jeZAAhkRWENGIBbtDt4j3MJ3lVYYjeJQ8R6LRWU6jLNRDIrD2XsHwUZMD4jvNqhgvXn7DdYYRk0UdCm6BPVY9Sz1ETVboF6uJmqJitIXFMAVRAguue50zpFKD0EkjMFf8hiojKUV0I/p/CTxHSNWpuVc3fQAv2RCQzRrbXx/NVMVSCXtA88MX5oexw25sos/fuVy+0Hs99OmNa4bRl4NrJyC50j76wXCE/zjwB83qvKZkzWa1JYsitHFa1qmGgqEngIRoimvYGNngHKv0WLk0qgtS8NelEr/5MMeXTyOpxyy2oriBSU5iHOA8/RMH0QscLY+Rzp38uTS9YAGG+gH1+OgIQZQbuk81JHpBbnDEJCEj1dotjg82YLT3oKk8kJqVpYxM9Or57+/GruCyd3EuK9um/1VZOA8ezbwJVkSmLQPd6/4NvEJ8aD4uviZ2Nhr4qWeNZs6r2GHfvo9rvrgA/GhgO1QD57ZMm2auHSKmODg5prarBj00dyhJV/jiC+c4lvUi+wNrhZcfClwMRc0HyuVHIKtEEO5FKnX2rVEq+WKNVgzi8PLOeqwQIfKQXnGgWHy0o+SwCi6d3WEMz3s3buBdN5Eem3YcPXkSG5uw3ju9FUvW3t17qRq+gdO4oPVwil+E/gaJ5CyFbrP57An+ZJIUkqSOtJlT0lP8aUwKYY0rVql4hRpkfbYaDBEOXs4exzV+QOcgSo9kdTcaKZqDkKcHumLJJHaKLOCqpbekKAdq52lPaJlC7TLYQ0U7fOgBfr3y0+UA4Ouq4XEGlAON0Qb0hm6uzydkz63UxkDJhizreBvrpkJmjl4imSyI3FqVqSVJ+RJcptoxl+Idd0qp/V9LOah+LY4agNBIsJnxHTS4sqy+ye1m9Qu8OKcXO09rLvnbNJiBj64Z1nBLLx+i3XhI3ilOHqG2HlG4I3ZGULsTx+zp3GkTfxGnGt7D/fmJoiL6Y+aeIKzhNdAYqmPzkJ5qC0qR5XY4MsaWFbWfzAym0lkvDKuV0ZaQceOA7qrlMr0Xhk9kmPAUsbdUpxbkVuVy+SmFUTgQRFjI0hE+zqcsRv84SEQ6f4468CAAUNJ38El3Z/GWagHckCtA3t22wU37eDGXp8pPftomzNtLrRh2nj0mfqWmR6mefLTOAPBbhG6MDhjPyFRPVL0VvqGFWfts6dHRUTGUTnSglGbpcdufYF+uZ7RU16Mo6FVbq6kJSBGEALUe62enJyz5cfhITdU4ZFcX32O/izo0DjvWYk/BhoO5BpCYQG86naHtMsQek7HBFxMJGGus87sJAxEVSmMMRJ2q+BBk7IdTXaf1qeCeeFxaraVg4x5eD07JTUxMyM7CyJMR1Z4DF6Q+mZlg1BYeMVJ8e3OuPXuP2WlpUzovy5+bfwtpNOd1pc3vzr8zeWbOXGpMr2Bz6zA1nJxLD5Qix8WRy/e0XnoA7UfkaUTBsxs/KDXtBLMfyIei8f83vODrKyn8C84tpWh1phGxtyd65/Qtk/nVY+1FMf1jO2Om4s/bBx+CBtwBlYVt+n8AD64M3Lj1kliW9DwJ8c9jz+BveNtjFXckzgwbXffEbhIrBsxtneldzzsMm378Im4C7b3X0169erqZQkjUwaNjE4ShLKV40a1trbsO+6LLdmOcS3fXvb8oy1iwH7FgpR9IelmMspH7VEX9JbPGWs0Wq3ROp+vvdAsJzXPbDJFC+1vuaWTkGy3qxKdToWqYzslcL0jmP4OKBW3AaFog7P25HXWd67DmXs6ZWe46uC5BezGn4Y+ChQNvaNx9v6YGNIhxQ3eId+nV7TolMemp5PZBEDldUuSMysdF6dvTL+czpxJx+kgOeNBcsDElktf2yU5CIlKKOfQn7eiRSj0kGTk+kXS9JCoeCHqTvV6Mg3XJMFssUqsNloFxFBnQ6NIK2h4trRnC3/Dgkx7XWtMtvIs+8z3hmduD7xN0h4mnQMH3ZOWLZ1S/dqR90aLW+pG4FN395wwdMRPDc471r766jnS/a29e1cN1Q/DRe675y1IEXt3+Qnn5LcVV8xZ0YGtmIYnizXTxm47NXNvWa1f/OjYNNwLbw3oO/Tmjj3Wp/PoOQ2WGksLkjkJPz9lithmUuCKO3lSDvYufj83WBGYM2Xid2NzrlAbmwp8fIxfCf7NQL/yort8cZo4e1x6nC+OsejSdT5dha5Kx8YZIbaLYwTgwC0+dTrxkSrCECLESEbUViCMFWYJTLGwQtgoMAKNS2wJRVJpiS4SEA0xyqU4rzz8gzvl+uPletiIOFJD5/yUkIjJNmIupI2ESU3CVh6xLFMlfmS4kpi1YSozQjw349552PTTd+PnH7Fvaf7+xuZsPB61aqh4STwTaMCbHmhpZyMb9nUagovxDNzbQ7/3Brv8CZ88Yn1PjG1cNXMnqW27U/zyzFG69tzgYqGWXyLtQe0gw6t9KkaDIRbXqr0OcCB7E2H3YqUCqdVi9WGweAkoHmf6VNG8T6Mv4nlFLDT6jGxBNI6OTmATE1g2IZHJ8OLD9IMyak0bdRl4bMasjCMZwQy2IGN5BskIxV0ghwaJElTWxumlcEBfr5e+PEHW14cCfBDddCuVrVAU4DBQm5NtMVITwzIQ92AQSZzqaUsyM0hqChgjY6YUBgEJhXhitZq0pH9izF341ofwrYFhOOZEL8+K3G2uWluOuHgjQbBhlPxPkCyyje7fIWlOkYpsEtduJPus2sccKfPdBBfMmHrnUtbMrXzmmcaDgTN5mY8UF5SKG6tyOkwZy875UVz3U2BxDZc5bcAozHRVGwUeb3Nd2cM/F18ods1Kf/qhotiZ225TQSyVGdwg7OEXIQvQ+05fpDUqKi6m2FZhIymw97cJGp2CugQFztotCOgpuEVgAzA4b1WsvQizetZk0FB5M7gl13REhwt0g3SzdIyOkvRsOXUEObBHypH8BCVfebmk3OnJQhJiCArvKcKKbESwD0yGfeCeO8XvxLyqHqJR3JqPO+GPmjdeYrzbGF/juyX4afGBu/uLV+88ETNtJbFhn7gs8P2E8ZNIJh4yCzy5eZZ4MXD8oWEj3qvcSHfIl4LrBRO/AkWAPplR54PIDEGhz6A30uhw39T0iPaMEdawFzOCSh9aDATmNCD/gOVYn9ZQBHG5C5Zywn2+Xv+x9OMF9eF4PORhQlG5gQYdExr0D5GSwZZd7n5Mm00NevZyg143gXvi+9KEGbuvljMD8EtiVuBefIX+uUE3aHolfwhiKRfEsl6UjdogH+qMnvZ5TSgSqyN5hUpn4JSRSkbTsV3b/Py27TqyiEgMskXp4hPiSQQTb2GZqERMog7BVt0OO1O1tshOY0Bw6hrUxp0NCrHX52md4YGb/UvTUaorJ5kaaJU+ww6yH6Fp1RoeDxSkLU97JY1JA8bVe0543OMC3rOe4+EfpvCG3Pl5V33IFOeeGDSwXH8aomNJYdxSiGz1ugeWg3U2gDPOyk7B2SGrLBlnwmRJWkKVhBcMf283gxnowoVCM7xCfDbyoU5dIsQP70ivKl9Utaxv7orcpcfeOTU2Onq6u+PdSmPryezjgSG1zLEHxB9XiAHMhPP9WCX+GOAzqs1pgf4ze5sXaTvNYcptM4TyETqc2rfVQ/uznt1b2vaNiXniW+JXGnWXDknVpx3xmby6ceXcO/mdV3oxF8iAwCM0B1gar0N+Ck/U3vvBJts3GGlmi08hHkUGFwlvgMdNRs0hFu6KBqIh6G2ft/j2fj0Gdet+R8uWrjSOZXsrEIonLldaCsFJzijOolA3SzGxZmWXLh1zdb4IfZEOQq2c/fG35Ofn3tHvMLCxP1LC3kuhsFALZ0Ze0L+OxrTDELJpUB+c4VP37t1D09HcP57zdacK2h0EWdcD99Dlgs/2Ke2+oz5yxod90t7M6x4PsZpVitXouQ1cPNJFip3r3a6Qa4UOUpbcrPua8w373tz0ZIMAHiArUqCmzxsW/GwzMNPEO50hnyEYIoGhWdlMtjXZJH22TMk0OM16eMcAOm7yej3ZGRCohcSARmupKSQV/DNYRojOLPi1autzI9fHzolMnPyZMXN1ehrOLI7JKu3yF+2JWNf69eLUFckDhldwt7TsMs1X7gs+M2ARSWrrKVQqJoir//RO6VuHXxc/ScfsLq7Tn5LuYAZo59bvc4h5mZ/iRl3gQ/GdDj/ggG4G0ZC5Hr91Skngz+pxnCKgyO8xs0U0edIc+IE8gN8PfKefjHFisDQxPymiqxs/1k3cVNftYew4Lto7dNNuNjSsG9NrSsmC9Z1HFC1kczA+NO6YeLFV3SffUw/WIXhAOMCvCVubaNSVnjxk+2K1Roua1WE3xHtMfujk4wP8NeYKMKa7of10MxQtbVj3KfkCBtMTjxNeGmq7yscPLLd66YmH95rF8ZqTb1CbDk+SjqO8j2ZMYG558soZnCm+jP+M24jP4zO4h7i7yzT20kt1cdO/aIiZNo0d23BfKNPTjlXBucJKvjdEGSmSDJeh73yqdHdJny5xWZmZdL+/R9mrr5f6VIOuAA8qWF6woeCVgg8KuIJbcqkRMfvzcEHezjxSkNczb1De8rwNeVyeE3YoPlNxS+xrWdyyouWFlqy/5dGWZ1oyLetC9qllC9pD5UvF9lR/KkltDo97kuI6d6HmNym1ZV6BkuuaFJ/Q1d2VFHTt2XV51w1dWX1XnN51dtejXZmuXW1UzvWwjR8bPyv+SDxTEL88nsSH3LiX7lHGG7zSkYR0JjEOhFxy8OXjwLbRZ1pPpV9/FkxdOraYzVRcQYrp55WsJr8Ne3hn2HFzINf0JIyTfHtStpPuUegew+ygWwwT0RJnYqqkBRmpTmkf4+QRMW9pO/7OZvEWnaJdu5ZDsxicNuC7e0mS3jgf25lTjS+TjYGKUG4s6oGLnjjZ7c7uj815nV3T+HpiAdMrsfVtvQdltItePb0DHrVO3NUXpy0+0l/czOZceZ2f+miXqTi23/hJWNeW1SjZO3B82pX1/Jno7uK86aQ8sAUPeeDHBxsGdv8kcHtZ5+UfTJnStm+3t8Sf+maZcPVXz1ijxS2Xu3yBo9eLe0ES1ME5wtf8blQAUdetqBiV4Apfc1sLVwvS0ALbOBdHGjicnpmZ3apzTOfC1BirN8mT4SnxVHpYj6dVfh32+CIy+jzQh0zsg9v0wX3CgYMXAodm9LYZ7FQzmndsTpo3712HW/sMGd1xUveS7pXdJ3Znu7fguhTTIXQdC0sKKwuZ9EJMCjuoU6nJS0IdsHffbM0KDdHQcwOVRlekaa9v77Tr6mB3q6LHcMStx/psOk82ztybk8PeQqgoNddrCrv34Uw6JoFxM8xyZgOzk3mF+YD5muE/AB3zQUjMMNaE2KhISWR1pgJTTxMz1jTLdMQUNLFnTNgUFiov3bpIp3IgVl6vtHcpb4pvwMgGjh53D6IV0AQCRsPqnOOhTuPoUVK5N2RPQ5sYEMRx6RwLjtIAgiRtajMhcpSu2VZHtlWg25pwstDDcYPD0uROhaSkVIc5KRtnZQogfDQKTUltEk52rvhdoIcuuOKjLDxMDHzLFAY8HHm98XP8XvHSwfjrgWsG4Dca3yZ/DniY3oHv6vHs7kceFk33v3py1KRR+07uLxDPB15aIm7HexeIH5Pm/Z/A4+/F1csqA3OZIfTn4GjOcqTN0JA/dy8dVv38XXdXzho5K2nLlpTqkbMq775r77RJXW8TM/q1nzO2eMDoDGtV3Adzr0bpmDMYp/UaOXp0vwqxcv6FOfS8GrznZv5R8J70L3Sv8UU3R4i05FQqRmvQ64U4HxiKuLhmLRO1dOOZghShSHSfIDApZkJ5TXCeT6cDPhZYsc+KrVZHdDNqlOJ0ZpxgDppJgbmneZZ5uXmn+Yj5FbNg9sUnFZlRyBgAQ4E3km+8doxBXaLr2vlE+FCC5YQkenqflEx9FYGdozEzFPtbJSMA9tdKJEucFOkwsvXYhCffKvYRvxHfEyfk4744av05x1OM+G7lzMnklU0M48qfdI+ja+Bh4kyZ1TCIZAVeIq/i6KEBZgRWP9LznuF7TpZP6nNoLs6tCWwWN3TZjs9+RioDgdSHn7e1rRMfTBCr8WY8vLH1F5gVP6I+pzS4VHiEX4cikQ32Q21Ro89iLcjHJN/OE53VxpMohW6WGqsdh6TDofTddntYV+jhUA7OufUWfIv+1jycp8/Iu4VpnRxShhRMj/MqUqpSNqb4U/iUtHRqp/e6XK30reDmQHpL7G6JWyZQ7xBhj8JROYqetkEQmpppjSklSlkRWxVL3LEFsSRWjVhDhII2WOzKdOVRJXNGeUF5Wcm4lQXK5UpGiSRNAT2T+AIRR+DP9KyyPHAWtIruHzyS5aZHTeU55e7y8J6iPHQ6QA+T9CcGlbvp/2Kg+32qSpRHNJuZcLhJfWYkPUTioJEqXjKwENo5CwtaJR0mcU+uCrzxgEiw+ABpsQr/9NnVRbX8+tqri7ipVxfV5E3E3lvFfvjPLz9uIMk4qmD+5/hVsXsvHPNAZ/HL55a+wx3o16+iYsI4gAlX47twc6/OrGP7N7r7Zl6owKOf1JAhXMehNtP+kXjQy3nDJr8tTsJz3qCe2AT2dye/HcWgFigdZaESdMin7qRWqbLzOqUqtD0O4xywzAi2wBUQMcAuN3OvvTVu3fYZiBCzUR5c26AMWgkcoWTea0iIj0+lRrCloWWb7Na4vZBYkNYzbRCE+RvSdkKo/0Ha12nKNF9zT5E+DaenzU4jaWnadMmx6hOLEysSGXvi0URyJhEnNtlAKFzjQkf93qbDfqmQ7gxN57HpOJX+wEJGqoNcP8kDF8k4Ma0x0qjfFI4ZGa/BSbPZxIUPbg0m+vOTYOvMJngjsRWTyY0x7B+ThwPjJ82qHPonx6roNNKgSyno12ZJ43hRdNRW1hLrpp2RNfGuhoYGEmgga/Dd4g78oXhvJUZX+2qZe5x5vkMrpj07oNCJ75qLU/DOZv3ETzZ2rcWrdpjGjb30jHjqaq8kFnOBK1+0w8nEx9xy5cX7Zybb2NtxUeNneOilQgdOHBdoDPzYJrl19RLtN807uCJVSrW7UyuJdzXCMX6n9DUlBWyZB9272xFPP0KAXsSkx5CYGEaXaDUnUyYmIRPO259uxmaz20MDLJdBraUbMJ1L52ZaNU+Tju/d7gJ3Tzfjtsemg/JwepVApD2bmylgBoEjk76IUe9z9gToQuC0R9qBURaFjnTeCG/UpE7pmHGGtMHsBFVwZOJIR+S14zHv9aOxG9SE+eTuhwm/gSRsXolHX30JT5+EC++58mXC5PvPnVv7yisP92Hns+MCsevZmLWBWOnb2zv4nurXX68Wp0+diu8Rp+N7Gu5aakkkZ6vxYbGwOlCcZpuRKy7rwkQ0fvcMPktl3hCsFs6CB4hCaZLUZ6DhPlV0tAUjxFuUhrrgZZ/L0NvoTPjSbrLq9LrWX7q1ar670KpHM2MLS2qSrXszwa2zc57YWGWLk57QFxzJP3voIUN96GDRnXPaI215ctyhs0UQUDACsEUNnTvA6s1NZ8kEGyQnnBl2vVLMR89zaPx354Ch46tSxfM4ec1TT00a27NnpzXjmIbAeeIUW7P9RR1JD5wRe5MXAjmh3LiJ+Qb37Lnox8sP3Y1ni7Pvfv2Byik972gcyuwRGwJj8X3TgpMmBaeJY7nddeKFugnkUKATPRbA1/6iPKn7x3/enpmPHoe8gN7zd6Fj5GVUA881UH4v/UX6n9A09iesgrIW8hrIbSE/CXk65CWQR0O+g6mi/4/n14Ebg4zcHeggNxiVcwF0kP0Gci08v47KJRzy6P8qgH5doH4iOgj8PMh9BWU0KmeP05/5hrbJUGdC4zkLsnJvoifg2ahg0ECuP/153H8M7COohH0fbWW1qC+UZezDqK9Ufw7uv0VbiQJtJJuCfoleCvSksB36Qj17VOq/VcKxB9rKNKL+jAKlQ9vmn42/EHzmHwDsIfoTNTLIIIMMMsgggwwyyPCfATTWvtk4yCCDDDLIIIMMMsgggwz/HaBAXIUCoQk3Gw8ZZJBBBhlkkEEGGWSQ4f8+wN4j7mbj8K8A4N/mN/R55Q+ae0i4nP473zvyO/ru/iftJb9hjL2/db7/S0D/R9ofNK7njxhXBhluBJCz2H/h3dR/Jy4y/OcByEDuv3GszH/XWDcDAP9LNxsHGWSQ4X8OoMPum43D7wHAN/Jm4yDD/z4A3zv84nnV3+mn/t/BSAYZZJDhvxfA1upvNg4y/N8EkK3Sm43DbwHA03SzcZBBhpsJsg7IIIMMMsgggwwyyCCDDDLIIIMMMsgggwwyyCCDDDLIIIMMMsgggwwyyCCDDDL874ICIcONfzNG8c/7xzb9/1l4b7kCkWcUiHkS8pRw+2Wo10AZhPw13GvD99+E778M37/89+eg/aS+312/l56/bWr/eb9r7V//vK3pfTr/9X7/nCZ4B7xzHkp/uNwRXtsnkOshi5Bd4Tp4xofDeRs8/yU8xsuh93EcbfsFDa/+Mxz+JwDjfvpHjCuDDDLIIIMMMsgggwx/BND4+WbjIIMMMsgggwwyyCCDDDL8d4ACodt/y+/9lUEGGWSQQQYZZJBBBhlk+FdBgYLizcbhXwHYO537531w1B809/2hksn/ne81/o6+z/2T9qG/YYz/1r8ZM/oPGvef0lwGGf5V+FfkF96d8u/ERYb/PAAZmPNvHGv+v2usmwGA/903GwcZZJDhfw6gw71vNg6/B/6o+FOG/78B+D7xF8+H/k6/fv87GMkggwwy/PcC2NrhNxsHGf5vAsjWuJuNw28BwHPQzcZBBhluJoAOlN9sHGSQQQYZZJBBBhlkkEEGGWSQQQYZZJBBBhlkkEEGGWSQQQYZZJBBBhlkkEEGGf6bgP787v8DhhnT0gplbmRzdHJlYW0KZW5kb2JqCjIxMCAwIG9iago8PC9UeXBlIC9Gb250RGVzY3JpcHRvcgovRm9udE5hbWUgL0JBQUFBQStNZWlyeW8KL0ZsYWdzIDQKL0FzY2VudCAxMDYwLjA1ODU5Ci9EZXNjZW50IDQzOS45NDE0MQovU3RlbVYgNTMuMjIyNjU2Ci9DYXBIZWlnaHQgNzM1LjgzOTg0Ci9JdGFsaWNBbmdsZSAwCi9Gb250QkJveCBbLTk4NC4zNzUgLTQzOS45NDE0MSAxODIyLjI2NTYgMTA2MC4wNTg1OV0KL0ZvbnRGaWxlMiAyMDkgMCBSPj4KZW5kb2JqCjIxMSAwIG9iago8PC9UeXBlIC9Gb250Ci9Gb250RGVzY3JpcHRvciAyMTAgMCBSCi9CYXNlRm9udCAvQkFBQUFBK01laXJ5bwovU3VidHlwZSAvQ0lERm9udFR5cGUyCi9DSURUb0dJRE1hcCAvSWRlbnRpdHkKL0NJRFN5c3RlbUluZm8gPDwvUmVnaXN0cnkgKEFkb2JlKQovT3JkZXJpbmcgKElkZW50aXR5KQovU3VwcGxlbWVudCAwPj4KL1cgWzAgWzEwMDAgMCAwIDMzOS44NDM3NV0gMTEgMTIgNDM5LjQ1MzEzIDE0IFs4MDMuNzEwOTQgMzQ5LjEyMTA5IDQzOS40NTMxMyAzNDkuMTIxMDldIDE5IDI4IDYyMS4wOTM3NSAyOSBbNDI5LjY4NzVdIDM2IFs2NzcuNzM0MzggNjcyLjg1MTU2IDY3Mi4zNjMyOCA3NDguNTM1MTYgNjE3LjY3NTc4IDU3MS4yODkwNiA3MjguMDI3MzQgMCA0MDMuMzIwMzEgMCA2NjAuNjQ0NTMgNTU2LjY0MDYzIDgzMC41NjY0MSA3NDEuMjEwOTQgNzYyLjIwNzAzIDU5NS43MDMxMyAwIDY4Mi42MTcxOSA2MzQuNzY1NjMgNjM1Ljc0MjE5IDcyOS4wMDM5MSA2ODIuNjE3MTkgMTAwMS40NjQ4NCA2NjkuNDMzNTldIDY4IFs1ODAuMDc4MTMgNjA4LjM5ODQ0IDUwNi44MzU5NCA2MDguMzk4NDQgNTc3LjE0ODQ0IDAgNjA2LjkzMzU5IDYxOC4xNjQwNiAyNTMuOTA2MjUgMzI4LjYxMzI4IDAgMjUzLjkwNjI1IDk1OS40NzI2NiA2MTguMTY0MDYgNTkzLjc1IDYwOC4zOTg0NCAwIDQxMy4wODU5NCA0OTguMDQ2ODggMzc4LjkwNjI1IDYxOC4xNjQwNiAwIDAgMCA1NjUuOTE3OTddIDExNCBbNTkwLjgyMDMxXSA4MDIgWzYwOC4zOTg0NF0gMTYwMiA2NTQwIDEwMDBdCi9EVyAwPj4KZW5kb2JqCjIxMiAwIG9iago8PC9GaWx0ZXIgL0ZsYXRlRGVjb2RlCi9MZW5ndGggNTE0Pj4gc3RyZWFtCnicXZPLrpswEIb3PIWXp4sjfMNgCUXCBqQselFz+gAEnBSpAUTIIm9fzwzNkYpE0GfP/88440n9sT5O48bSH+vcn8LGLuM0rOE+P9Y+sHO4jlMiJBvGftsJf/tbtyRpFJ+e9y3cjtNlTsqSsfRn3L1v65O9VcN8Dl+S9Ps6hHWcruztlz9FPj2W5U+4hWljPDkc2BAu0elrt3zrboGlKHs/DnF/3J7vUfMZ8fFcApPIgqrp5yHcl64PazddQ1Ly+BxY2cbnkIRp+G9f7bLzpf/drRiuYjjnkh+ApEfSFikjyolyCcaOCyAlgbhySNYAKe7QxVqiZidHhC42ClipG14RQXbZcop0LZLJkHwVKdPcI9XgmTlLutphpKyBKmEjGS5zJAkuJsvRs/Kwl+t4TKC6ABcvsGqXwZ7lvkEycNrMSszgrKdasGpf1OBSK/T0DnSFlFhZrXKMLBoiqMyaHCurNZzWWjpt888TqVVw9kJ5dGkzyFDwGlwEFw3UkreQXdgCdKbIqaV778SrlZ+td9gvTm2TBbaNN0hC0KLDRUFdFzV+1N58TSEV3QFBiyRXJNAkVxktUr5M4qImuS7wY0iudzNKZHJabElHnsbTZSPPjOQ5ehqNt8xohXeaF/sfQCeG6w1j+Jqd/rGucWxwVnFeYFLGKbzGeZkXUMH7F+ZR/OYKZW5kc3RyZWFtCmVuZG9iago1IDAgb2JqCjw8L1R5cGUgL0ZvbnQKL1N1YnR5cGUgL1R5cGUwCi9CYXNlRm9udCAvQkFBQUFBK01laXJ5bwovRW5jb2RpbmcgL0lkZW50aXR5LUgKL0Rlc2NlbmRhbnRGb250cyBbMjExIDAgUl0KL1RvVW5pY29kZSAyMTIgMCBSPj4KZW5kb2JqCnhyZWYKMCAyMTMKMDAwMDAwMDAwMCA2NTUzNSBmIAowMDAwMDAwMDE1IDAwMDAwIG4gCjAwMDAwMDQ1ODYgMDAwMDAgbiAKMDAwMDAwMDI2MiAwMDAwMCBuIAowMDAwMDQ3NjQxIDAwMDAwIG4gCjAwMDAwNjYyMTUgMDAwMDAgbiAKMDAwMDAwMDI5OSAwMDAwMCBuIAowMDAwMDA0ODE2IDAwMDAwIG4gCjAwMDAwMzc0OTEgMDAwMDAgbiAKMDAwMDAzMjE0NSAwMDAwMCBuIAowMDAwMDA1NTIxIDAwMDAwIG4gCjAwMDAwMDQ5OTAgMDAwMDAgbiAKMDAwMDAwNDg3MSAwMDAwMCBuIAowMDAwMDA1MDc3IDAwMDAwIG4gCjAwMDAwMDUzMTUgMDAwMDAgbiAKMDAwMDAwNTE5NiAwMDAwMCBuIAowMDAwMDA1NDAyIDAwMDAwIG4gCjAwMDAwMDgxNjUgMDAwMDAgbiAKMDAwMDAwNjE2MSAwMDAwMCBuIAowMDAwMDA1NzQ2IDAwMDAwIG4gCjAwMDAwMDU2MjcgMDAwMDAgbiAKMDAwMDAwNjAxMyAwMDAwMCBuIAowMDAwMDA1ODk0IDAwMDAwIG4gCjAwMDAwMDY3OTUgMDAwMDAgbiAKMDAwMDAwNjM4MCAwMDAwMCBuIAowMDAwMDA2MjYxIDAwMDAwIG4gCjAwMDAwMDY2NDcgMDAwMDAgbiAKMDAwMDAwNjUyOCAwMDAwMCBuIAowMDAwMDA3NDI5IDAwMDAwIG4gCjAwMDAwMDcwMTQgMDAwMDAgbiAKMDAwMDAwNjg5NSAwMDAwMCBuIAowMDAwMDA3MjgxIDAwMDAwIG4gCjAwMDAwMDcxNjIgMDAwMDAgbiAKMDAwMDAwODA2NSAwMDAwMCBuIAowMDAwMDA3NjQ5IDAwMDAwIG4gCjAwMDAwMDc1MjkgMDAwMDAgbiAKMDAwMDAwNzkxNyAwMDAwMCBuIAowMDAwMDA3Nzk3IDAwMDAwIG4gCjAwMDAwMDgzOTggMDAwMDAgbiAKMDAwMDAwODI3OCAwMDAwMCBuIAowMDAwMDMxODcyIDAwMDAwIG4gCjAwMDAwMTEwOTIgMDAwMDAgbiAKMDAwMDAwODYwMiAwMDAwMCBuIAowMDAwMDA4NDgyIDAwMDAwIG4gCjAwMDAwMDg4OTIgMDAwMDAgbiAKMDAwMDAwODc3MiAwMDAwMCBuIAowMDAwMDA5MTgyIDAwMDAwIG4gCjAwMDAwMDkwNjIgMDAwMDAgbiAKMDAwMDAwOTQ3MiAwMDAwMCBuIAowMDAwMDA5MzUyIDAwMDAwIG4gCjAwMDAwMDk3NjIgMDAwMDAgbiAKMDAwMDAwOTY0MiAwMDAwMCBuIAowMDAwMDEwMDUyIDAwMDAwIG4gCjAwMDAwMDk5MzIgMDAwMDAgbiAKMDAwMDAxMDM0MiAwMDAwMCBuIAowMDAwMDEwMjIyIDAwMDAwIG4gCjAwMDAwMTA2MzIgMDAwMDAgbiAKMDAwMDAxMDUxMiAwMDAwMCBuIAowMDAwMDEwOTIyIDAwMDAwIG4gCjAwMDAwMTA4MDIgMDAwMDAgbiAKMDAwMDAxMjE3MSAwMDAwMCBuIAowMDAwMDExMzg4IDAwMDAwIG4gCjAwMDAwMTEyMzQgMDAwMDAgbiAKMDAwMDAxMTY4OSAwMDAwMCBuIAowMDAwMDExNTY5IDAwMDAwIG4gCjAwMDAwMTE5OTAgMDAwMDAgbiAKMDAwMDAxMTg3MCAwMDAwMCBuIAowMDAwMDEyODczIDAwMDAwIG4gCjAwMDAwMTIzOTEgMDAwMDAgbiAKMDAwMDAxMjI3MSAwMDAwMCBuIAowMDAwMDEyNjkyIDAwMDAwIG4gCjAwMDAwMTI1NzIgMDAwMDAgbiAKMDAwMDAxMzYzNiAwMDAwMCBuIAowMDAwMDEzMTU0IDAwMDAwIG4gCjAwMDAwMTI5NjYgMDAwMDAgbiAKMDAwMDAxMzQ1NSAwMDAwMCBuIAowMDAwMDEzMzM1IDAwMDAwIG4gCjAwMDAwMTQzOTkgMDAwMDAgbiAKMDAwMDAxMzkxNyAwMDAwMCBuIAowMDAwMDEzNzI5IDAwMDAwIG4gCjAwMDAwMTQyMTggMDAwMDAgbiAKMDAwMDAxNDA5OCAwMDAwMCBuIAowMDAwMDE2MTAxIDAwMDAwIG4gCjAwMDAwMTQ2NDYgMDAwMDAgbiAKMDAwMDAxNDQ5MiAwMDAwMCBuIAowMDAwMDE1MDE2IDAwMDAwIG4gCjAwMDAwMTQ4MjggMDAwMDAgbiAKMDAwMDAxNTMxOCAwMDAwMCBuIAowMDAwMDE1MTk4IDAwMDAwIG4gCjAwMDAwMTU2MTkgMDAwMDAgbiAKMDAwMDAxNTQ5OSAwMDAwMCBuIAowMDAwMDE1OTIwIDAwMDAwIG4gCjAwMDAwMTU4MDAgMDAwMDAgbiAKMDAwMDAxNjg1MSAwMDAwMCBuIAowMDAwMDE2MzY5IDAwMDAwIG4gCjAwMDAwMTYyMTUgMDAwMDAgbiAKMDAwMDAxNjY3MCAwMDAwMCBuIAowMDAwMDE2NTUwIDAwMDAwIG4gCjAwMDAwMTc1ODYgMDAwMDAgbiAKMDAwMDAxNzA5OSAwMDAwMCBuIAowMDAwMDE2OTQ0IDAwMDAwIG4gCjAwMDAwMTc0MDMgMDAwMDAgbiAKMDAwMDAxNzI4MSAwMDAwMCBuIAowMDAwMDE4MzI2IDAwMDAwIG4gCjAwMDAwMTc4MzYgMDAwMDAgbiAKMDAwMDAxNzY4MCAwMDAwMCBuIAowMDAwMDE4MTQyIDAwMDAwIG4gCjAwMDAwMTgwMjAgMDAwMDAgbiAKMDAwMDAyMDA1NCAwMDAwMCBuIAowMDAwMDE4NTc4IDAwMDAwIG4gCjAwMDAwMTg0MjIgMDAwMDAgbiAKMDAwMDAxODkxOCAwMDAwMCBuIAowMDAwMDE4NzYyIDAwMDAwIG4gCjAwMDAwMTkyNTggMDAwMDAgbiAKMDAwMDAxOTEwMiAwMDAwMCBuIAowMDAwMDE5NTY0IDAwMDAwIG4gCjAwMDAwMTk0NDIgMDAwMDAgbiAKMDAwMDAxOTg3MCAwMDAwMCBuIAowMDAwMDE5NzQ4IDAwMDAwIG4gCjAwMDAwMjA3ODYgMDAwMDAgbiAKMDAwMDAyMDI5NiAwMDAwMCBuIAowMDAwMDIwMTc0IDAwMDAwIG4gCjAwMDAwMjA2MDIgMDAwMDAgbiAKMDAwMDAyMDQ4MCAwMDAwMCBuIAowMDAwMDIxNDk0IDAwMDAwIG4gCjAwMDAwMjEwMDQgMDAwMDAgbiAKMDAwMDAyMDg4MiAwMDAwMCBuIAowMDAwMDIxMzEwIDAwMDAwIG4gCjAwMDAwMjExODggMDAwMDAgbiAKMDAwMDAyMjIwMiAwMDAwMCBuIAowMDAwMDIxNzEyIDAwMDAwIG4gCjAwMDAwMjE1OTAgMDAwMDAgbiAKMDAwMDAyMjAxOCAwMDAwMCBuIAowMDAwMDIxODk2IDAwMDAwIG4gCjAwMDAwMjI5MTAgMDAwMDAgbiAKMDAwMDAyMjQyMCAwMDAwMCBuIAowMDAwMDIyMjk4IDAwMDAwIG4gCjAwMDAwMjI3MjYgMDAwMDAgbiAKMDAwMDAyMjYwNCAwMDAwMCBuIAowMDAwMDIzNjE4IDAwMDAwIG4gCjAwMDAwMjMxMjggMDAwMDAgbiAKMDAwMDAyMzAwNiAwMDAwMCBuIAowMDAwMDIzNDM0IDAwMDAwIG4gCjAwMDAwMjMzMTIgMDAwMDAgbiAKMDAwMDAyNDMyNiAwMDAwMCBuIAowMDAwMDIzODM2IDAwMDAwIG4gCjAwMDAwMjM3MTQgMDAwMDAgbiAKMDAwMDAyNDE0MiAwMDAwMCBuIAowMDAwMDI0MDIwIDAwMDAwIG4gCjAwMDAwMjYwNTQgMDAwMDAgbiAKMDAwMDAyNDU3OCAwMDAwMCBuIAowMDAwMDI0NDIyIDAwMDAwIG4gCjAwMDAwMjQ5MTggMDAwMDAgbiAKMDAwMDAyNDc2MiAwMDAwMCBuIAowMDAwMDI1MjU4IDAwMDAwIG4gCjAwMDAwMjUxMDIgMDAwMDAgbiAKMDAwMDAyNTU2NCAwMDAwMCBuIAowMDAwMDI1NDQyIDAwMDAwIG4gCjAwMDAwMjU4NzAgMDAwMDAgbiAKMDAwMDAyNTc0OCAwMDAwMCBuIAowMDAwMDI2Nzg2IDAwMDAwIG4gCjAwMDAwMjYyOTYgMDAwMDAgbiAKMDAwMDAyNjE3NCAwMDAwMCBuIAowMDAwMDI2NjAyIDAwMDAwIG4gCjAwMDAwMjY0ODAgMDAwMDAgbiAKMDAwMDAyNzQ5NCAwMDAwMCBuIAowMDAwMDI3MDA0IDAwMDAwIG4gCjAwMDAwMjY4ODIgMDAwMDAgbiAKMDAwMDAyNzMxMCAwMDAwMCBuIAowMDAwMDI3MTg4IDAwMDAwIG4gCjAwMDAwMjgyMDIgMDAwMDAgbiAKMDAwMDAyNzcxMiAwMDAwMCBuIAowMDAwMDI3NTkwIDAwMDAwIG4gCjAwMDAwMjgwMTggMDAwMDAgbiAKMDAwMDAyNzg5NiAwMDAwMCBuIAowMDAwMDI4OTQ0IDAwMDAwIG4gCjAwMDAwMjg0NTQgMDAwMDAgbiAKMDAwMDAyODI5OCAwMDAwMCBuIAowMDAwMDI4NzYwIDAwMDAwIG4gCjAwMDAwMjg2MzggMDAwMDAgbiAKMDAwMDAyOTY1MiAwMDAwMCBuIAowMDAwMDI5MTYyIDAwMDAwIG4gCjAwMDAwMjkwNDAgMDAwMDAgbiAKMDAwMDAyOTQ2OCAwMDAwMCBuIAowMDAwMDI5MzQ2IDAwMDAwIG4gCjAwMDAwMzAzNjAgMDAwMDAgbiAKMDAwMDAyOTg3MCAwMDAwMCBuIAowMDAwMDI5NzQ4IDAwMDAwIG4gCjAwMDAwMzAxNzYgMDAwMDAgbiAKMDAwMDAzMDA1NCAwMDAwMCBuIAowMDAwMDMxMDY4IDAwMDAwIG4gCjAwMDAwMzA1NzggMDAwMDAgbiAKMDAwMDAzMDQ1NiAwMDAwMCBuIAowMDAwMDMwODg0IDAwMDAwIG4gCjAwMDAwMzA3NjIgMDAwMDAgbiAKMDAwMDAzMTc3NiAwMDAwMCBuIAowMDAwMDMxMjg2IDAwMDAwIG4gCjAwMDAwMzExNjQgMDAwMDAgbiAKMDAwMDAzMTU5MiAwMDAwMCBuIAowMDAwMDMxNDcwIDAwMDAwIG4gCjAwMDAwMzIyNzAgMDAwMDAgbiAKMDAwMDAzMzAyNiAwMDAwMCBuIAowMDAwMDMzMDgzIDAwMDAwIG4gCjAwMDAwMzc0NTQgMDAwMDAgbiAKMDAwMDAzNzU5OCAwMDAwMCBuIAowMDAwMDM3NzEyIDAwMDAwIG4gCjAwMDAwNDY0MzkgMDAwMDAgbiAKMDAwMDA0NjY4NCAwMDAwMCBuIAowMDAwMDQ3MjE5IDAwMDAwIG4gCjAwMDAwNDc3ODYgMDAwMDAgbiAKMDAwMDA2NDU5MSAwMDAwMCBuIAowMDAwMDY0ODMxIDAwMDAwIG4gCjAwMDAwNjU2MjkgMDAwMDAgbiAKdHJhaWxlcgo8PC9TaXplIDIxMwovUm9vdCAyMDQgMCBSCi9JbmZvIDEgMCBSPj4Kc3RhcnR4cmVmCjY2MzU1CiUlRU9GCg==",
      "title" : "検査結果PDFレポート"
    }
  ]
}

```
